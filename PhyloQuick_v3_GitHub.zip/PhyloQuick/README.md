# PhyloQuick

PhyloQuick is a desktop application for nucleotide sequence analysis. It takes a
FASTA file through quality control, multiple alignment, substitution-model
selection, distance- or likelihood-based tree inference, branch support,
intraspecific summary statistics and haplotype networks in a single run. All
computation is done locally; the application makes no network connections.

The same analysis engine is available as a command-line tool, and every run
writes a manifest (software version, SHA-256 of the input, all parameters, the
random seed and per-stage timings) from which the analysis can be repeated.

## Features

- **Alignment**: k-mer guide tree, profile-profile alignment with affine gaps
  (Gotoh), tree-dependent iterative refinement; optional gap-based trimming
- **Models**: JC69, F81, K80, HKY85, TN93, GTR, each with +I, +G or +I+G
  (24 candidates); selection by AIC, AICc or BIC with Akaike weights
- **Distances**: p-distance, JC69, K80, TN93 (with optional gamma correction)
  and ML distances under any supported model
- **Trees**: Neighbor-Joining, BIONJ, UPGMA and maximum likelihood with NNI
  search and perturbation restarts
- **Support**: nonparametric bootstrap and SH-aLRT
- **Population genetics**: S, eta, h, Hd, pi, k, Watterson's theta, Tajima's D,
  Fu and Li's D\* and F\*, Fu's Fs, R2, mismatch distribution and raggedness
- **Haplotype networks**: minimum spanning, median-joining and statistical
  parsimony
- **Validation tools**: Robinson-Foulds comparison with an imported tree,
  simulation-based accuracy tests and runtime scaling measurements
- **Export**: Newick, FASTA, PHYLIP, NEXUS, distance matrices, TSV tables,
  SVG/PNG figures and the run manifest (JSON)

## Installation

A Windows installer is available on the Releases page.

To run from source you need Node.js 18 or later:

```
git clone https://github.com/<user>/PhyloQuick.git
cd PhyloQuick
npm install
npm start
```

`npm run selftest` starts the application without a window, checks that the
interface and the analysis worker load, and exits with a non-zero status on
failure.

To build an installer: `npm run dist` (Windows), `npm run dist:mac` or
`npm run dist:linux`.

## Command-line use

The command-line tool needs only Node.js; Electron is not required.

```
node cli/phyloquick.js -i data/chicken_dloop.fasta -o results --method ML
node cli/phyloquick.js --replay results/phyloquick-run-manifest.json -i data/chicken_dloop.fasta -o results2
node cli/phyloquick.js --compare treeA.nwk treeB.nwk
node cli/phyloquick.js --help
```

## Example data

| File | Description |
|---|---|
| `data/chicken_dloop.fasta` | 20 *Gallus gallus* mitochondrial control-region sequences (GenBank PZ411613-PZ411632) |
| `data/bird_coi.fasta` | COI barcodes of 10 bird species from different orders |
| `data/dloop_22.fasta` | 71 chicken mitochondrial D-loop sequences |

## Scope

Alignment, model selection and tree inference are valid at any level of
divergence. Haplotype and nucleotide diversity, neutrality tests and haplotype
networks assume a sample from a single interbreeding population; the
application warns when divergence in the data exceeds the range expected
within a species. The divergence check cannot detect structure among closely
related populations, so sample provenance should be confirmed separately.

Only nucleotide data are supported. Amino-acid and codon models, partitioned
analyses, Bayesian inference and divergence-time estimation are not included.
For very large or highly divergent datasets a dedicated ML program and a
consistency-based aligner are recommended.

## Authors

Kemal Eskioğlu, Berkant İsmail Yıldız, Demir Özdemir
Department of Agricultural Biotechnology, Faculty of Agriculture,
Akdeniz University, Antalya, Türkiye

## License

MIT. See [LICENSE](LICENSE).
