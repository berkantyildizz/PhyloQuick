#!/usr/bin/env node
/**
 * PhyloQuick command-line interface.
 *
 * Runs the same engine as the desktop application, takes parameters from
 * flags or a JSON config file, and writes a run manifest next to the results
 * so that an analysis can be repeated with one command.
 *
 * Usage:
 *   phyloquick -i input.fasta -o outdir [options]
 *   phyloquick --config run.json
 *   phyloquick --replay outdir/run-manifest.json -i input.fasta -o outdir2
 */

import fs from 'node:fs';
import path from 'node:path';
import process from 'node:process';
import { fileURLToPath } from 'node:url';

import { runAnalysis, DEFAULTS, VERSION } from '../src/engine/pipeline.js';
import { toFasta, toPhylip, toNexus } from '../src/engine/seq.js';
import { toPhylipMatrix, toTsvMatrix } from '../src/engine/distance.js';
import { toTsv as modelTsv } from '../src/engine/modelselect.js';
import { writeNewick } from '../src/engine/tree.js';
import { robinsonFoulds, branchScoreDistance, splitAccuracy } from '../src/engine/treecmp.js';
import { parseNewick, unroot, relink } from '../src/engine/tree.js';

const HELP = `
PhyloQuick ${VERSION} — reproducible phylogenetic and population-genetic analysis

USAGE
  phyloquick -i <input.fasta> -o <output-dir> [options]
  phyloquick --config <run.json>
  phyloquick --replay <run-manifest.json> -i <input.fasta> -o <output-dir>
  phyloquick --compare <treeA.nwk> <treeB.nwk>

INPUT / OUTPUT
  -i, --input <file>        input sequences in FASTA format (required)
  -o, --outdir <dir>        output directory (default: phyloquick-out)
      --prefix <name>       basename for output files (default: phyloquick)
      --config <file>       read all options from a JSON file
      --replay <manifest>   re-run using the parameters recorded in a manifest
      --json                also write the complete result as JSON

ALIGNMENT
      --realign             realign even if the input is already aligned
      --gap-open <n>        gap opening penalty (default ${DEFAULTS.alignment.gapOpen})
      --gap-extend <n>      gap extension penalty (default ${DEFAULTS.alignment.gapExtend})
      --refine <n>          iterative refinement rounds (default ${DEFAULTS.alignment.refineRounds})
      --gap-threshold <f>   drop columns with a gap fraction above f (default ${DEFAULTS.gapThreshold})
      --range <from-to>     keep only these 1-based alignment columns

MODEL
      --model <name>        JC69|F81|K80|HKY85|TN93|GTR (default ${DEFAULTS.substitutionModel})
      --gamma <alpha>       fix the gamma shape instead of estimating it
      --invariable <p>      fix the proportion of invariable sites
      --categories <k>      discrete gamma categories (default ${DEFAULTS.gammaCategories})
      --no-model-selection  skip model selection and use --model as given
      --criterion <name>    AIC|AICc|BIC for model selection (default ${DEFAULTS.modelSelectionCriterion})

TREE
      --method <name>       NJ|BIONJ|UPGMA|ML (default ${DEFAULTS.treeMethod})
      --no-ml-search        with --method ML, optimise the NJ topology without NNI search
      --distance <name>     p-distance|JC69|K80|TN93|ML (default ${DEFAULTS.distanceModel})
      --complete-deletion   exclude all columns containing a gap or N
      --root <mode>         midpoint|outgroup|none (default ${DEFAULTS.rooting})
      --outgroup <a,b,...>  outgroup taxa for --root outgroup

SUPPORT
      --support <mode>      bootstrap|shalrt|both|none (default ${DEFAULTS.support})
  -b, --bootstrap <n>       bootstrap replicates (default ${DEFAULTS.bootstrapReplicates})
      --shalrt <n>          SH-aLRT replicates (default ${DEFAULTS.shalrtReplicates})
  -s, --seed <n>            random seed (default ${DEFAULTS.seed})

NETWORK
      --network <type>      MSN|MJ|PARSIMONY (default ${DEFAULTS.networkType})
      --network-epsilon <n> epsilon parameter for MSN/MJ
      --parsimony-limit <n> fixed connection limit for the parsimony network

OTHER
  -q, --quiet               suppress progress output
  -h, --help                show this message
  -v, --version             print the version

EXAMPLES
  phyloquick -i dloop.fasta -o results --method ML --support both -b 200 -s 42
  phyloquick -i coi.fasta -o results --model GTR --gamma 0.2 --no-model-selection
  phyloquick --compare results/phyloquick.nwk reference.nwk
`;

async function main(argv) {
  const args = parseArgs(argv);

  if (args.help || (!args.input && !args.config && !args.replay && !args.compare)) {
    process.stdout.write(HELP);
    process.exit(args.help ? 0 : 1);
  }
  if (args.version) {
    process.stdout.write(`PhyloQuick ${VERSION}\n`);
    process.exit(0);
  }

  if (args.compare) {
    return compareTrees(args.compare);
  }

  let options = {};
  if (args.config) {
    options = JSON.parse(fs.readFileSync(args.config, 'utf8'));
    if (options.input && !args.input) args.input = options.input;
    if (options.outdir && !args.outdir) args.outdir = options.outdir;
    delete options.input; delete options.outdir;
  }
  if (args.replay) {
    options = { ...options, ...optionsFromManifest(JSON.parse(fs.readFileSync(args.replay, 'utf8'))) };
  }
  options = { ...options, ...args.options };

  const input = args.input;
  if (!input) fail('no input file given (-i)');
  if (!fs.existsSync(input)) fail(`input file not found: ${input}`);

  const outdir = args.outdir || 'phyloquick-out';
  const prefix = args.prefix || 'phyloquick';
  fs.mkdirSync(outdir, { recursive: true });

  const text = fs.readFileSync(input, 'utf8');
  const quiet = args.quiet;
  let lastStage = '';

  const result = await runAnalysis(text, options, (fraction, stage, detail) => {
    if (quiet) return;
    if (stage !== lastStage || fraction >= 1) {
      lastStage = stage;
      process.stderr.write(`\r[${String(Math.round(fraction * 100)).padStart(3)}%] ${stage.padEnd(10)} ${(detail || '').padEnd(40)}`);
    }
  });
  if (!quiet) process.stderr.write('\n');

  const out = (name, content) => {
    const p = path.join(outdir, `${prefix}${name}`);
    fs.writeFileSync(p, content);
    return p;
  };

  const written = [];
  written.push(out('.nwk', result.newick + '\n'));
  written.push(out('.unrooted.nwk', result.unrootedNewick + '\n'));
  written.push(out('.aln.fasta', toFasta(result.alignment.names, result.alignment.seqs)));
  written.push(out('.aln.phy', toPhylip(result.alignment.names, result.alignment.seqs)));
  written.push(out('.aln.nex', toNexus(result.alignment.names, result.alignment.seqs)));
  written.push(out('.dist.phy', toPhylipMatrix(result.distances)));
  written.push(out('.dist.tsv', toTsvMatrix(result.distances)));
  written.push(out('.popgen.tsv', popgenTsv(result.popgen)));
  written.push(out('.haplotypes.tsv', haplotypeTsv(result.network)));
  written.push(out('.summary.txt', summaryText(result)));
  written.push(out('-run-manifest.json', JSON.stringify(result.manifest, null, 2) + '\n'));
  if (result.modelSelection) written.push(out('.models.tsv', modelTsv(result.modelSelection)));
  if (result.support && result.support.consensusNewick) {
    written.push(out('.bootstrap-consensus.nwk', result.support.consensusNewick + '\n'));
  }
  if (args.options.json) {
    written.push(out('.result.json', JSON.stringify(serialisable(result), null, 2) + '\n'));
  }

  if (!quiet) {
    process.stderr.write(`\nWrote ${written.length} file(s) to ${path.resolve(outdir)}:\n`);
    for (const p of written) process.stderr.write(`  ${path.basename(p)}\n`);
    if (result.warnings.length) {
      process.stderr.write('\nWarnings:\n');
      for (const w of result.warnings) process.stderr.write(`  - ${w}\n`);
    }
  }
  process.stdout.write(result.newick + '\n');
}

// ---------------------------------------------------------------------------
// Tree comparison mode
// ---------------------------------------------------------------------------

function compareTrees(files) {
  if (files.length < 2) fail('--compare needs two Newick files');
  const [a, b] = files.map((f) => unroot(relink(parseNewick(fs.readFileSync(f, 'utf8')))));
  const rf = robinsonFoulds(a, b);
  const acc = splitAccuracy(a, b);
  const bsd = branchScoreDistance(a, b);
  process.stdout.write([
    `taxa                      ${rf.taxa}`,
    `Robinson-Foulds distance  ${rf.rf}`,
    `normalised RF             ${rf.normalised.toFixed(6)}  (0 = identical, 1 = maximally different)`,
    `shared splits             ${rf.sharedSplits} of ${rf.splitsA} (first) and ${rf.splitsB} (second)`,
    `split recall              ${acc.recall.toFixed(6)}  (fraction of first tree's splits found in second)`,
    `branch-score distance     ${bsd.toFixed(6)}`,
    `both fully resolved       ${rf.fullyResolved}`,
    '',
  ].join('\n'));
}

// ---------------------------------------------------------------------------
// Output formatting
// ---------------------------------------------------------------------------

function popgenTsv(p) {
  const rows = [
    ['sequences', p.n],
    ['analysed_sites', p.sites],
    ['segregating_sites_S', p.S],
    ['total_mutations_eta', p.eta],
    ['singleton_mutations', p.singletonMutations],
    ['haplotypes_h', p.h],
    ['haplotype_diversity_Hd', fixed(p.Hd, 6)],
    ['haplotype_diversity_SD', fixed(p.HdSD, 6)],
    ['nucleotide_diversity_pi', fixed(p.pi, 8)],
    ['nucleotide_diversity_SD', fixed(p.piSD, 8)],
    ['mean_pairwise_differences_k', fixed(p.k, 6)],
    ['wattersons_theta', fixed(p.thetaW, 6)],
    ['wattersons_theta_per_site', fixed(p.thetaWPerSite, 8)],
    ['tajimas_D', fixed(p.tajimaD, 6)],
    ['tajimas_D_p_approx', fixed(p.tajimaP, 4)],
    ['fu_li_D_star', fixed(p.fuLiDStar, 6)],
    ['fu_li_F_star', fixed(p.fuLiFStar, 6)],
    ['fu_Fs', fixed(p.fuFs, 6)],
    ['ramos_onsins_rozas_R2', fixed(p.r2, 6)],
    ['mismatch_raggedness', fixed(p.mismatch && p.mismatch.raggedness, 6)],
  ];
  return 'statistic\tvalue\n' + rows.map(([k, v]) => `${k}\t${v}`).join('\n') + '\n';
}

function haplotypeTsv(network) {
  const lines = ['haplotype\tcount\tfrequency\tsequences'];
  const total = network.haplotypes.reduce((a, h) => a + h.count, 0);
  for (const h of network.haplotypes) {
    lines.push(`${h.id}\t${h.count}\t${(h.count / total).toFixed(6)}\t${h.names.join(',')}`);
  }
  return lines.join('\n') + '\n';
}

function summaryText(r) {
  const m = r.manifest;
  const p = r.popgen;
  const lines = [
    `PhyloQuick ${VERSION} — analysis summary`,
    `Generated ${m.run.finishedAt}`,
    '',
    'INPUT',
    `  SHA-256 of input          ${m.input.sha256}`,
    `  records read              ${m.input.recordsRead}`,
    `  records removed by QC     ${m.input.recordsRemoved.length}`,
    `  characters masked as N    ${m.input.charactersMasked}`,
    `  taxon labels              ${m.input.taxonNaming}`,
    '',
    'ALIGNMENT',
    `  realigned                 ${m.alignment.performed ? 'yes' : `no (${m.alignment.reason})`}`,
    ...(m.alignment.performed ? [
      `  sum-of-pairs score        ${Math.round(m.alignment.spScore)}`,
      `  refinements accepted      ${m.alignment.refinementsAccepted}`,
    ] : []),
    `  aligned length            ${r.summary.alignedLength}`,
    `  columns removed by trim   ${m.trimming.columnsRemoved}`,
    `  variable sites            ${r.summary.variableSites}`,
    `  parsimony-informative     ${r.summary.parsimonyInformativeSites}`,
    `  distinct site patterns    ${r.summary.distinctPatterns}`,
    `  base frequencies A/C/G/T  ${r.summary.baseFrequencies.map((x) => x.toFixed(4)).join(' / ')}`,
    '',
    'MODEL',
    `  selection                 ${m.model.selectionPerformed ? `yes (${m.model.criterion})` : 'no'}`,
    `  model                     ${m.model.chosen.label}`,
    ...Object.entries(m.model.chosen)
      .filter(([k]) => !['model', 'label'].includes(k))
      .map(([k, v]) => `  ${k.padEnd(25)} ${Array.isArray(v) ? v.join(', ') : v}`),
    '',
    'TREE',
    `  method                    ${m.tree.method}`,
    ...(m.tree.lnL != null ? [
      `  log-likelihood            ${m.tree.lnL.toFixed(4)}`,
      `  NNI sweeps / moves        ${m.tree.nniSweeps} / ${m.tree.nniMovesApplied}`,
    ] : []),
    `  distance model            ${m.distances.model}`,
    `  rooting                   ${m.rooting.method}`,
    '',
    'SUPPORT',
    ...(m.support ? [
      `  method                    ${m.support.method || 'SH-aLRT'}`,
      ...(m.support.replicates != null ? [`  bootstrap replicates      ${m.support.effectiveReplicates ?? m.support.replicates}`] : []),
      ...(m.support.meanSupport != null ? [`  mean bootstrap support    ${m.support.meanSupport.toFixed(1)}%`] : []),
      ...(m.support.shalrt ? [`  SH-aLRT replicates        ${m.support.shalrt.replicates}`] : []),
      `  random seed               ${m.support.seed ?? m.run.randomSeed}`,
    ] : ['  none']),
    '',
    'POPULATION GENETICS',
    `  segregating sites (S)     ${p.S}`,
    `  haplotypes (h)            ${p.h}`,
    `  haplotype diversity (Hd)  ${fixed(p.Hd, 4)} +/- ${fixed(p.HdSD, 4)}`,
    `  nucleotide diversity (pi) ${fixed(p.pi, 6)} +/- ${fixed(p.piSD, 6)}`,
    `  mean pairwise diffs (k)   ${fixed(p.k, 4)}`,
    `  Watterson's theta         ${fixed(p.thetaW, 4)}`,
    `  Tajima's D                ${fixed(p.tajimaD, 4)}  (p ~ ${fixed(p.tajimaP, 3)})`,
    `  Fu & Li's D*              ${fixed(p.fuLiDStar, 4)}`,
    `  Fu & Li's F*              ${fixed(p.fuLiFStar, 4)}`,
    `  Fu's Fs                   ${fixed(p.fuFs, 4)}`,
    `  R2                        ${fixed(p.r2, 4)}`,
    `  mismatch raggedness       ${fixed(p.mismatch && p.mismatch.raggedness, 4)}`,
    '',
    'NETWORK',
    `  type                      ${r.network.type}`,
    `  haplotype nodes           ${r.network.haplotypes.length}`,
    `  edges                     ${r.network.edges.length}`,
    ...Object.entries(r.network.meta).map(([k, v]) => `  ${k.padEnd(25)} ${v}`),
    '',
    'REPRODUCIBILITY',
    `  random seed               ${m.run.randomSeed}`,
    `  generator                 ${m.run.generator}`,
    `  parameter set SHA-256     ${m.parametersSha256}`,
    `  runtime                   ${m.environment.runtime} ${m.environment.node || m.environment.electron || ''} (${m.environment.platform || ''} ${m.environment.arch || ''})`,
    `  elapsed                   ${(m.run.elapsedMs / 1000).toFixed(2)} s`,
    '',
    ...(r.warnings.length ? ['WARNINGS', ...r.warnings.map((w) => `  - ${w}`), ''] : []),
    'TREE (Newick)',
    r.newick,
    '',
  ];
  return lines.join('\n');
}

function fixed(x, d) {
  return (x == null || !Number.isFinite(x)) ? 'NA' : x.toFixed(d);
}

function serialisable(r) {
  return {
    manifest: r.manifest,
    summary: r.summary,
    newick: r.newick,
    unrootedNewick: r.unrootedNewick,
    taxa: r.taxa,
    model: r.model.describe(),
    modelSelection: r.modelSelection ? r.modelSelection.results.map((m) => ({
      label: m.label, lnL: m.lnL, freeParameters: m.freeParameters,
      AIC: m.AIC, AICc: m.AICc, BIC: m.BIC, akaikeWeight: m.akaikeWeight,
      parameters: m.parameters,
    })) : null,
    distances: { names: r.distances.names, matrix: r.distances.matrix.map((row) => Array.from(row)) },
    popgen: { ...r.popgen, siteStates: undefined },
    haplotypes: r.network.haplotypes.map((h) => ({ id: h.id, count: h.count, names: h.names })),
    networkEdges: r.network.edges,
    alignment: { names: r.alignment.names, seqs: r.alignment.seqs },
    warnings: r.warnings,
  };
}

// ---------------------------------------------------------------------------
// Argument handling
// ---------------------------------------------------------------------------

function parseArgs(argv) {
  const out = { options: {}, help: false, version: false, quiet: false, compare: null };
  const alignment = {};
  let i = 0;
  const next = () => argv[++i];

  for (; i < argv.length; i++) {
    const a = argv[i];
    switch (a) {
      case '-h': case '--help': out.help = true; break;
      case '-v': case '--version': out.version = true; break;
      case '-q': case '--quiet': out.quiet = true; break;
      case '-i': case '--input': out.input = next(); break;
      case '-o': case '--outdir': out.outdir = next(); break;
      case '--prefix': out.prefix = next(); break;
      case '--config': out.config = next(); break;
      case '--replay': out.replay = next(); break;
      case '--json': out.options.json = true; break;
      case '--compare': out.compare = [next(), next()]; break;

      case '--realign': out.options.forceRealign = true; break;
      case '--gap-open': alignment.gapOpen = Number(next()); break;
      case '--gap-extend': alignment.gapExtend = Number(next()); break;
      case '--refine': alignment.refineRounds = Number(next()); break;
      case '--gap-threshold': out.options.gapThreshold = Number(next()); break;
      case '--range': {
        const [from, to] = String(next()).split('-').map(Number);
        out.options.trimFrom = from; out.options.trimTo = to;
        break;
      }

      case '--model': out.options.substitutionModel = next(); break;
      case '--gamma': out.options.gammaAlpha = Number(next()); break;
      case '--invariable': out.options.proportionInvariable = Number(next()); break;
      case '--categories': out.options.gammaCategories = Number(next()); break;
      case '--no-model-selection': out.options.runModelSelection = false; break;
      case '--criterion': out.options.modelSelectionCriterion = next(); break;

      case '--method': out.options.treeMethod = String(next()).toUpperCase(); break;
      case '--no-ml-search': out.options.mlSearch = false; break;
      case '--distance': out.options.distanceModel = next(); break;
      case '--complete-deletion': out.options.completeDeletion = true; break;
      case '--root': out.options.rooting = next(); break;
      case '--outgroup': out.options.outgroup = String(next()).split(',').map((s) => s.trim()); break;

      case '--support': out.options.support = next(); break;
      case '-b': case '--bootstrap': out.options.bootstrapReplicates = Number(next()); break;
      case '--shalrt': out.options.shalrtReplicates = Number(next()); break;
      case '-s': case '--seed': out.options.seed = Number(next()); break;

      case '--network': out.options.networkType = String(next()).toUpperCase(); break;
      case '--network-epsilon': out.options.networkEpsilon = Number(next()); break;
      case '--parsimony-limit': out.options.parsimonyLimit = Number(next()); break;

      default:
        if (a.startsWith('-')) fail(`unknown option: ${a}`);
        else if (!out.input) out.input = a;
    }
  }
  if (Object.keys(alignment).length) out.options.alignment = alignment;
  return out;
}

/** Extract a re-runnable option set from a previously written manifest. */
function optionsFromManifest(manifest) {
  const o = {};
  if (manifest.run) o.seed = manifest.run.randomSeed;
  if (manifest.alignment && manifest.alignment.options) o.alignment = manifest.alignment.options;
  if (manifest.trimming) {
    o.gapThreshold = manifest.trimming.gapThreshold;
    if (Array.isArray(manifest.trimming.range)) {
      o.trimFrom = manifest.trimming.range[0];
      o.trimTo = manifest.trimming.range[1];
    }
  }
  if (manifest.model) {
    o.runModelSelection = manifest.model.selectionPerformed;
    if (manifest.model.criterion) o.modelSelectionCriterion = manifest.model.criterion;
    if (manifest.model.chosen) {
      o.substitutionModel = manifest.model.chosen.model;
      if (manifest.model.chosen.alpha != null) o.gammaAlpha = manifest.model.chosen.alpha;
      if (manifest.model.chosen.pinv != null) o.proportionInvariable = manifest.model.chosen.pinv;
      if (manifest.model.chosen.gammaCategories) o.gammaCategories = manifest.model.chosen.gammaCategories;
    }
  }
  if (manifest.distances) {
    o.distanceModel = manifest.distances.model;
    o.completeDeletion = manifest.distances.completeDeletion;
  }
  if (manifest.tree) {
    o.treeMethod = manifest.tree.method;
    if (manifest.tree.mlSearch != null) o.mlSearch = manifest.tree.mlSearch;
  }
  if (manifest.support) {
    o.bootstrapReplicates = manifest.support.replicates ?? DEFAULTS.bootstrapReplicates;
    if (manifest.support.shalrt) o.shalrtReplicates = manifest.support.shalrt.replicates;
  }
  if (manifest.rooting) o.rooting = manifest.rooting.method;
  if (manifest.network) {
    o.networkType = manifest.network.type;
    if (manifest.network.epsilon != null) o.networkEpsilon = manifest.network.epsilon;
    if (manifest.network.connectionLimit != null) o.parsimonyLimit = manifest.network.connectionLimit;
  }
  return o;
}

function fail(message) {
  process.stderr.write(`phyloquick: ${message}\n`);
  process.exit(2);
}

const isMain = process.argv[1] && fileURLToPath(import.meta.url) === path.resolve(process.argv[1]);
if (isMain) {
  main(process.argv.slice(2)).catch((err) => {
    process.stderr.write(`\nphyloquick: ${err.message}\n`);
    if (process.env.PHYLOQUICK_DEBUG) process.stderr.write(err.stack + '\n');
    process.exit(1);
  });
}

export { main };
