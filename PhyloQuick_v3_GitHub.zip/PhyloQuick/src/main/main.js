/**
 * Electron main process.
 *
 * Creates the window, the menu and the native file dialogs. All analysis runs
 * in the renderer's worker; this process opens no network connections.
 */

import { app, BrowserWindow, dialog, ipcMain, Menu, protocol, shell } from 'electron';
import { fileURLToPath } from 'node:url';
import path from 'node:path';
import fs from 'node:fs/promises';

const here = path.dirname(fileURLToPath(import.meta.url));
const srcDir = path.join(here, '..');

let mainWindow = null;

/**
 * The interface is served from a custom `app://` scheme rather than from
 * `file://`.
 *
 * Chromium refuses to start a module Worker from a file:// document, and the
 * analysis engine runs in exactly such a worker. Registering a privileged
 * scheme also gives the renderer a real origin, so the Content-Security-Policy
 * in index.html is enforced properly instead of being ignored for opaque
 * origins. Requests are resolved against the packaged source directory and
 * anything that tries to escape it is refused.
 *
 * Files are read with fs.readFile rather than fetched over file://, because in
 * a packaged build the sources live inside app.asar: Electron's fs layer knows
 * how to read from the archive, the network stack does not.
 */
const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'text/javascript; charset=utf-8',
  '.mjs': 'text/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.svg': 'image/svg+xml',
  '.png': 'image/png',
  '.woff2': 'font/woff2',
  '.fasta': 'text/plain; charset=utf-8',
  '.txt': 'text/plain; charset=utf-8',
};
protocol.registerSchemesAsPrivileged([{
  scheme: 'app',
  privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true },
}]);

function registerAppProtocol() {
  protocol.handle('app', async (request) => {
    const url = new URL(request.url);
    const relative = decodeURIComponent(url.pathname).replace(/^\/+/, '');
    const target = path.join(srcDir, relative);
    const normalised = path.normalize(target);
    if (!normalised.startsWith(srcDir)) {
      return new Response('Forbidden', { status: 403 });
    }
    try {
      const body = await fs.readFile(normalised);
      const mime = MIME_TYPES[path.extname(normalised).toLowerCase()] || 'application/octet-stream';
      return new Response(body, { status: 200, headers: { 'content-type': mime } });
    } catch {
      return new Response('Not found', { status: 404 });
    }
  });
}

function createWindow() {
  mainWindow = new BrowserWindow({
    width: 1440,
    height: 940,
    minWidth: 960,
    minHeight: 640,
    title: 'PhyloQuick',
    backgroundColor: '#0d1420',
    show: false,
    webPreferences: {
      preload: path.join(here, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
      spellcheck: false,
    },
  });

  mainWindow.once('ready-to-show', () => mainWindow.show());
  mainWindow.loadURL('app://phyloquick/renderer/index.html');

  // Nothing in this application should navigate away or open a browser window;
  // any attempt to do so is a bug or an injection, so both are refused.
  mainWindow.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:/.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  mainWindow.webContents.on('will-navigate', (event) => event.preventDefault());
}

function buildMenu() {
  const isMac = process.platform === 'darwin';
  const template = [
    ...(isMac ? [{ role: 'appMenu' }] : []),
    {
      label: 'File',
      submenu: [
        {
          label: 'Open sequences…',
          accelerator: 'CmdOrCtrl+O',
          click: () => mainWindow?.webContents.send('menu', 'open'),
        },
        {
          label: 'Run analysis',
          accelerator: 'CmdOrCtrl+R',
          click: () => mainWindow?.webContents.send('menu', 'run'),
        },
        { type: 'separator' },
        isMac ? { role: 'close' } : { role: 'quit' },
      ],
    },
    { role: 'editMenu' },
    {
      label: 'View',
      submenu: [
        { role: 'reload' }, { role: 'toggleDevTools' }, { type: 'separator' },
        { role: 'resetZoom' }, { role: 'zoomIn' }, { role: 'zoomOut' },
        { type: 'separator' }, { role: 'togglefullscreen' },
      ],
    },
    { role: 'windowMenu' },
    {
      role: 'help',
      submenu: [
        {
          label: 'About PhyloQuick',
          click: () => dialog.showMessageBox(mainWindow, {
            type: 'info',
            title: 'About PhyloQuick',
            message: `PhyloQuick ${app.getVersion()}`,
            detail: 'Reproducible sequence alignment, model selection, phylogenetic inference '
              + 'and intraspecific population genetics.\n\n'
              + 'All computation runs on this computer. No data leaves the machine.\n\n'
              + `Electron ${process.versions.electron} · Node ${process.versions.node} · Chromium ${process.versions.chrome}`,
            buttons: ['OK'],
          }),
        },
      ],
    },
  ];
  Menu.setApplicationMenu(Menu.buildFromTemplate(template));
}

// ---------------------------------------------------------------------------
// File dialogs
// ---------------------------------------------------------------------------

ipcMain.handle('open-file', async (_event, filters) => {
  const result = await dialog.showOpenDialog(mainWindow, {
    properties: ['openFile'],
    filters: filters && filters.length ? filters : [
      { name: 'Sequence files', extensions: ['fasta', 'fas', 'fa', 'fna', 'txt'] },
      { name: 'All files', extensions: ['*'] },
    ],
  });
  if (result.canceled || !result.filePaths.length) return null;
  const filePath = result.filePaths[0];
  const content = await fs.readFile(filePath, 'utf8');
  return { name: path.basename(filePath), path: filePath, content };
});

ipcMain.handle('save-file', async (_event, defaultName, content) => {
  const result = await dialog.showSaveDialog(mainWindow, { defaultPath: defaultName });
  if (result.canceled || !result.filePath) return false;
  await fs.writeFile(result.filePath, content, 'utf8');
  return true;
});

ipcMain.handle('app-info', () => ({
  version: app.getVersion(),
  electron: process.versions.electron,
  node: process.versions.node,
  chrome: process.versions.chrome,
  platform: process.platform,
  arch: process.arch,
}));

// ---------------------------------------------------------------------------

/**
 * `--selftest` opens the window without showing it, checks that the interface
 * rendered and that the analysis worker started, prints the result and exits
 * with a non-zero status on failure.
 */
async function runSelfTest() {
  const window = new BrowserWindow({
    show: false,
    width: 1280,
    height: 900,
    webPreferences: {
      preload: path.join(here, 'preload.cjs'),
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: false,
    },
  });
  const errors = [];
  window.webContents.on('console-message', (_e, level, message) => {
    if (level >= 2) errors.push(message);
  });
  window.webContents.on('did-fail-load', (_e, code, description, url) => {
    errors.push(`did-fail-load ${code} ${description} ${url}`);
  });

  await window.loadURL('app://phyloquick/renderer/index.html');
  await new Promise((resolve) => setTimeout(resolve, 2500));

  const report = await window.webContents.executeJavaScript(`(() => ({
    title: document.title,
    tabs: document.querySelectorAll('#tabs .tab').length,
    sidebarGroups: document.querySelectorAll('.panel-group').length,
    helpRendered: document.querySelector('#helpBody h2') !== null,
    examples: document.querySelectorAll('[data-example]').length,
    workerStarted: typeof Worker !== 'undefined',
  }))()`);

  // Exercise the engine end to end through the worker, on the bundled example.
  const analysis = await window.webContents.executeJavaScript(`new Promise((resolve) => {
    const done = (v) => resolve(v);
    const timer = setTimeout(() => done({ ok: false, reason: 'timed out' }), 180000);
    document.querySelector('[data-example="birds"]').click();
    document.getElementById('runModelSelection').checked = false;
    document.getElementById('runModelSelection').dispatchEvent(new Event('change'));
    document.getElementById('bootstrapReplicates').value = '20';
    document.getElementById('btnRun').click();
    const poll = setInterval(() => {
      const chip = document.getElementById('statusChip').textContent;
      if (/^Done/.test(chip)) {
        clearInterval(poll); clearTimeout(timer);
        done({
          ok: true, chip,
          treeDrawn: !!document.querySelector('#treeView svg'),
          networkDrawn: !!document.querySelector('#netView svg'),
          haplotypeRows: document.querySelectorAll('#hapTable tbody tr').length,
          manifestBytes: document.getElementById('manifestView').textContent.length,
        });
      } else if (chip === 'Failed') {
        clearInterval(poll); clearTimeout(timer);
        done({ ok: false, reason: document.getElementById('errBox').textContent });
      }
    }, 400);
  })`);

  const passed = report.tabs >= 10 && report.helpRendered && report.examples === 2
    && analysis.ok && analysis.treeDrawn && analysis.networkDrawn
    && analysis.manifestBytes > 500 && errors.length === 0;

  process.stdout.write(`${JSON.stringify({ report, analysis, errors, passed }, null, 2)}\n`);
  process.stdout.write(passed ? 'SELFTEST PASSED\n' : 'SELFTEST FAILED\n');
  app.exit(passed ? 0 : 1);
}

app.whenReady().then(() => {
  registerAppProtocol();
  if (process.argv.includes('--selftest')) {
    runSelfTest().catch((err) => {
      process.stderr.write(`selftest crashed: ${err.stack}\n`);
      app.exit(1);
    });
    return;
  }
  buildMenu();
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
