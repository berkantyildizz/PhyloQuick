/**
 * Preload bridge.
 *
 * Exposes three operations to the renderer: open a file, save a file and
 * report version information. The renderer runs with context isolation and
 * without Node integration.
 */

const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('phyloquick', {
  /** Ask the user for a file and return { name, path, content }, or null. */
  openFile: (filters) => ipcRenderer.invoke('open-file', filters),

  /** Ask the user where to write `content`. Resolves true when written. */
  saveFile: (defaultName, content) => ipcRenderer.invoke('save-file', defaultName, content),

  /** Version strings for the About box and the run manifest. */
  appInfo: () => ipcRenderer.invoke('app-info'),

  /** Menu actions forwarded from the main process. */
  onMenu: (handler) => {
    ipcRenderer.on('menu', (_event, action) => handler(action));
  },
});
