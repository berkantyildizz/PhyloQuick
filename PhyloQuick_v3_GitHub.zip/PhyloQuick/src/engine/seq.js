/**
 * Sequence import, quality control and alignment bookkeeping.
 *
 * Everything downstream works on the `Alignment` shape produced here:
 *   { names: string[], seqs: string[], length: number }
 * with sequences stored as uppercase strings over {A,C,G,T,-} plus IUPAC
 * ambiguity codes, all of equal length once aligned.
 */

export const NUCS = ['A', 'C', 'G', 'T'];

/** IUPAC ambiguity codes expanded to the states they are compatible with. */
export const IUPAC = {
  A: [1, 0, 0, 0], C: [0, 1, 0, 0], G: [0, 0, 1, 0], T: [0, 0, 0, 1], U: [0, 0, 0, 1],
  R: [1, 0, 1, 0], Y: [0, 1, 0, 1], S: [0, 1, 1, 0], W: [1, 0, 0, 1],
  K: [0, 0, 1, 1], M: [1, 1, 0, 0], B: [0, 1, 1, 1], D: [1, 0, 1, 1],
  H: [1, 1, 0, 1], V: [1, 1, 1, 0], N: [1, 1, 1, 1], '-': [1, 1, 1, 1],
  '?': [1, 1, 1, 1], '.': [1, 1, 1, 1],
};

/**
 * Parse FASTA. Tolerates CRLF, blank lines, wrapped sequences and leading
 * junk before the first '>'. Returns records in file order with duplicated
 * names disambiguated (a silent name collision would otherwise corrupt the
 * taxon-to-tip mapping).
 */
export function parseFasta(text) {
  const records = [];
  const seen = new Map();
  let name = null;
  let chunks = [];

  const push = () => {
    if (name === null) return;
    let unique = name;
    if (seen.has(name)) {
      const k = seen.get(name) + 1;
      seen.set(name, k);
      unique = `${name}_${k}`;
    } else {
      seen.set(name, 1);
    }
    records.push({ name: unique, seq: chunks.join('').replace(/\s+/g, '').toUpperCase() });
    chunks = [];
  };

  for (const rawLine of String(text).split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line) continue;
    if (line[0] === '>' || line[0] === ';') {
      push();
      name = line.slice(1).trim() || `seq_${records.length + 1}`;
    } else if (name !== null) {
      chunks.push(line);
    }
  }
  push();
  return records;
}

export function toFasta(names, seqs, wrap = 60) {
  const out = [];
  for (let i = 0; i < names.length; i++) {
    out.push('>' + names[i]);
    const s = seqs[i];
    if (wrap > 0) {
      for (let j = 0; j < s.length; j += wrap) out.push(s.slice(j, j + wrap));
    } else {
      out.push(s);
    }
  }
  return out.join('\n') + '\n';
}

/** Relaxed sequential PHYLIP, for interoperability with PhyML/RAxML/IQ-TREE. */
export function toPhylip(names, seqs) {
  const lines = [`${names.length} ${seqs[0] ? seqs[0].length : 0}`];
  for (let i = 0; i < names.length; i++) {
    lines.push(`${sanitizeName(names[i])}  ${seqs[i]}`);
  }
  return lines.join('\n') + '\n';
}

export function toNexus(names, seqs, extra = '') {
  const n = names.length;
  const len = seqs[0] ? seqs[0].length : 0;
  const body = names.map((nm, i) => `  ${sanitizeName(nm)}  ${seqs[i]}`).join('\n');
  return `#NEXUS\n\nBEGIN DATA;\n  DIMENSIONS NTAX=${n} NCHAR=${len};\n` +
    `  FORMAT DATATYPE=DNA MISSING=N GAP=- INTERLEAVE=NO;\n  MATRIX\n${body}\n  ;\nEND;\n${extra}`;
}

export function sanitizeName(name) {
  return String(name).replace(/[\s(),:;'"\[\]]+/g, '_').slice(0, 90) || 'seq';
}

/**
 * Quality control before analysis.
 *
 * Non-IUPAC characters are masked to N rather than silently dropped, because
 * dropping them would shift downstream site coordinates. Sequences that carry
 * no resolved nucleotide at all are removed; every action is reported so it
 * can be reproduced from the log.
 */
export function qualityControl(records, opts = {}) {
  const minLength = opts.minLength ?? 1;
  const maxAmbiguous = opts.maxAmbiguous ?? 1.0; // fraction of N/gap tolerated
  const kept = [];
  const removed = [];
  const log = [];
  let maskedChars = 0;

  for (const rec of records) {
    let masked = '';
    for (const ch of rec.seq) {
      if (IUPAC[ch] !== undefined) {
        masked += ch === 'U' ? 'T' : ch;
      } else {
        masked += 'N';
        maskedChars++;
      }
    }
    const resolved = masked.replace(/[^ACGT]/g, '').length;
    const ambiguousFrac = masked.length ? 1 - resolved / masked.length : 1;
    if (resolved < minLength) {
      removed.push({ name: rec.name, reason: 'no resolved nucleotides' });
      continue;
    }
    if (ambiguousFrac > maxAmbiguous) {
      removed.push({ name: rec.name, reason: `ambiguous fraction ${ambiguousFrac.toFixed(3)} exceeds ${maxAmbiguous}` });
      continue;
    }
    kept.push({ name: rec.name, seq: masked });
  }

  if (maskedChars) log.push(`${maskedChars} non-IUPAC character(s) masked as N`);
  for (const r of removed) log.push(`removed ${r.name}: ${r.reason}`);

  return { records: kept, removed, log, maskedChars };
}

/** True when every sequence already has the same length. */
export function isAligned(records) {
  if (records.length < 2) return true;
  const len = records[0].seq.length;
  return records.every((r) => r.seq.length === len);
}

export function toAlignment(records) {
  return {
    names: records.map((r) => r.name),
    seqs: records.map((r) => r.seq),
    length: records.length ? records[0].seq.length : 0,
  };
}

// ---------------------------------------------------------------------------
// Column statistics and trimming
// ---------------------------------------------------------------------------

/** Per-column gap/ambiguity fraction. */
export function columnGapFraction(aln) {
  const { seqs, length } = aln;
  const n = seqs.length;
  const out = new Float64Array(length);
  for (let c = 0; c < length; c++) {
    let gaps = 0;
    for (let r = 0; r < n; r++) {
      const ch = seqs[r][c];
      if (ch === '-' || ch === 'N' || ch === '?') gaps++;
    }
    out[c] = n ? gaps / n : 1;
  }
  return out;
}

/**
 * Remove columns whose gap/ambiguity fraction exceeds `threshold`, optionally
 * restricted to a 1-based [from,to] window. Returns the trimmed alignment plus
 * the mapping back to original coordinates so that reported SNP positions stay
 * interpretable.
 */
export function trimAlignment(aln, { gapThreshold = 1.0, from = 1, to = null } = {}) {
  const end = to ?? aln.length;
  const gapFrac = columnGapFraction(aln);
  const keep = [];
  for (let c = 0; c < aln.length; c++) {
    if (c + 1 < from || c + 1 > end) continue;
    if (gapFrac[c] > gapThreshold) continue;
    keep.push(c);
  }
  const seqs = aln.seqs.map((s) => {
    let out = '';
    for (const c of keep) out += s[c];
    return out;
  });
  return {
    names: aln.names.slice(),
    seqs,
    length: keep.length,
    originalColumns: keep.map((c) => c + 1),
    removedCount: aln.length - keep.length,
  };
}

/** Variable (polymorphic) column indices, 0-based, ignoring gaps and N. */
export function variableSites(aln) {
  const out = [];
  for (let c = 0; c < aln.length; c++) {
    const seen = new Set();
    for (let r = 0; r < aln.seqs.length; r++) {
      const ch = aln.seqs[r][c];
      if (ch === 'A' || ch === 'C' || ch === 'G' || ch === 'T') seen.add(ch);
      if (seen.size > 1) break;
    }
    if (seen.size > 1) out.push(c);
  }
  return out;
}

/** Parsimony-informative columns: at least two states each seen twice or more. */
export function parsimonyInformativeSites(aln) {
  const out = [];
  for (let c = 0; c < aln.length; c++) {
    const counts = { A: 0, C: 0, G: 0, T: 0 };
    for (let r = 0; r < aln.seqs.length; r++) {
      const ch = aln.seqs[r][c];
      if (counts[ch] !== undefined) counts[ch]++;
    }
    let multi = 0;
    for (const k of NUCS) if (counts[k] >= 2) multi++;
    if (multi >= 2) out.push(c);
  }
  return out;
}

/** Empirical base frequencies over resolved nucleotides. */
export function baseFrequencies(aln) {
  const counts = [0, 0, 0, 0];
  let total = 0;
  for (const s of aln.seqs) {
    for (let i = 0; i < s.length; i++) {
      const k = NUCS.indexOf(s[i]);
      if (k >= 0) { counts[k]++; total++; }
    }
  }
  if (!total) return [0.25, 0.25, 0.25, 0.25];
  // Guard against a zero frequency, which would make log-likelihoods infinite.
  return counts.map((c) => Math.max(c / total, 1e-6));
}

/** Majority-rule consensus; lowercase marks sites below the identity cutoff. */
export function consensus(aln, cutoff = 1.0) {
  let out = '';
  for (let c = 0; c < aln.length; c++) {
    const counts = { A: 0, C: 0, G: 0, T: 0 };
    let total = 0;
    for (let r = 0; r < aln.seqs.length; r++) {
      const ch = aln.seqs[r][c];
      if (counts[ch] !== undefined) { counts[ch]++; total++; }
    }
    if (!total) { out += 'N'; continue; }
    let best = 'N'; let bestCount = -1;
    for (const k of NUCS) if (counts[k] > bestCount) { bestCount = counts[k]; best = k; }
    out += bestCount / total >= cutoff ? best : best.toLowerCase();
  }
  return out;
}

// ---------------------------------------------------------------------------
// Site-pattern compression
// ---------------------------------------------------------------------------

/**
 * Collapse identical alignment columns into weighted site patterns.
 *
 * Likelihood evaluation dominates the runtime of model selection, ML search
 * and bootstrapping, and it is linear in the number of distinct columns.
 * Low-divergence alignments collapse to a small number of patterns.
 *
 * `siteToPattern` keeps the original column order so that bootstrap resampling
 * can still resample *sites*, not patterns.
 */
export function compressPatterns(aln) {
  const n = aln.seqs.length;
  const map = new Map();
  const patterns = [];
  const weights = [];
  const siteToPattern = new Int32Array(aln.length);

  for (let c = 0; c < aln.length; c++) {
    let key = '';
    for (let r = 0; r < n; r++) key += aln.seqs[r][c];
    let idx = map.get(key);
    if (idx === undefined) {
      idx = patterns.length;
      map.set(key, idx);
      patterns.push(key);
      weights.push(0);
    }
    weights[idx]++;
    siteToPattern[c] = idx;
  }

  // Tip partial-likelihood vectors: [taxon][pattern*4]
  const tipStates = [];
  for (let r = 0; r < n; r++) {
    const arr = new Float64Array(patterns.length * 4);
    for (let p = 0; p < patterns.length; p++) {
      const code = IUPAC[patterns[p][r]] || IUPAC.N;
      arr[p * 4] = code[0];
      arr[p * 4 + 1] = code[1];
      arr[p * 4 + 2] = code[2];
      arr[p * 4 + 3] = code[3];
    }
    tipStates.push(arr);
  }

  return {
    nTaxa: n,
    nPatterns: patterns.length,
    nSites: aln.length,
    patterns,
    weights: Float64Array.from(weights),
    siteToPattern,
    tipStates,
    names: aln.names.slice(),
  };
}
