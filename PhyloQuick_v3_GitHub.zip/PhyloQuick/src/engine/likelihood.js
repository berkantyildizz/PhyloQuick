/**
 * Maximum-likelihood phylogenetics: Felsenstein pruning, branch-length and
 * model-parameter optimisation, NNI topology search and SH-aLRT support.
 * All computations work on compressed site patterns.
 *
 * Conventions
 * -----------
 * Trees are the node objects from tree.js. The root has three children, so the
 * tree is effectively unrooted; the likelihood of a reversible model does not
 * depend on root placement, and branch lengths and lnL can be compared
 * directly with PhyML/IQ-TREE output.
 *
 * Numerical scaling
 * -----------------
 * Each internal node keeps a per-pattern log-scale accumulator. When the
 * largest conditional likelihood for a pattern drops below 1e-150 the vector
 * is renormalised and log(factor) is added to the accumulator, so lnL stays
 * accurate on deep trees.
 */

import { postorder, preorder, isLeaf, cloneTree, relink } from './tree.js';
import { brentMax, coordinateAscent } from './optimise.js';
import { MODEL_SPEC } from './models.js';

// Bounds used when optimising a branch. The upper bound is generous:
// saturated pairs in divergent datasets legitimately produce branches well past
// 1 substitution/site, and a tight ceiling silently truncates them.
const MIN_BRANCH = 1e-8;
const MAX_BRANCH = 100;
// Ceiling used when merely *evaluating* a user-supplied tree. Evaluation must
// never alter the tree it was handed, so this only guards against infinities.
const EVAL_BRANCH_CEILING = 1e6;
const SCALE_THRESHOLD = 1e-150;
const SCALE_FACTOR = 1e150;
const LOG_SCALE_FACTOR = Math.log(SCALE_FACTOR);

export class LikelihoodEngine {
  /**
   * @param {object} data  output of seq.compressPatterns
   * @param {SubstitutionModel} model
   */
  constructor(data, model) {
    this.data = data;
    this.model = model;
    this.nPat = data.nPatterns;
    this.weights = data.weights;
    this.tipIndex = new Map(data.names.map((n, i) => [n, i]));
    this._constLik = null;
    this._buffers = new Map();
    this.evaluations = 0;
  }

  /** Replace the model (e.g. after a parameter step) and drop stale caches. */
  setModel(model) {
    this.model = model;
    this._constLik = null;
    return this;
  }

  /** Attach a tree; nodes are indexed and buffers allocated. */
  setTree(root) {
    this.root = root;
    this.nodes = postorder(root);
    this.index = new Map();
    this.nodes.forEach((n, i) => this.index.set(n, i));
    this.nCat = this.model.usesGamma ? this.model.nCat : 1;
    const stride = this.nPat * this.nCat * 4;
    this.down = [];
    this.up = [];
    this.other = []; // conditional likelihood of everything on the far side of the branch above a node
    this.downScale = [];
    this.upScale = [];
    this.otherScale = [];
    for (let i = 0; i < this.nodes.length; i++) {
      const node = this.nodes[i];
      this.down.push(isLeaf(node) ? null : new Float64Array(stride));
      this.up.push(new Float64Array(stride));
      this.other.push(new Float64Array(stride));
      this.downScale.push(new Float64Array(this.nPat));
      this.upScale.push(new Float64Array(this.nPat));
      this.otherScale.push(new Float64Array(this.nPat));
    }
    this._dirty = true;
    return this;
  }

  /** Tip conditional likelihoods, identical across rate categories. */
  _tipVector(node) {
    const idx = this.tipIndex.get(node.name);
    if (idx === undefined) throw new Error(`taxon "${node.name}" is not in the alignment`);
    return this.data.tipStates[idx];
  }

  /**
   * Likelihood of a site under the invariable class: the probability that all
   * observed states at that site are compatible with a single unchanged
   * nucleotide. Computed once because it does not depend on the tree.
   */
  _constantLikelihood() {
    if (this._constLik) return this._constLik;
    const out = new Float64Array(this.nPat);
    const pi = this.model.freqs;
    const tips = this.data.tipStates;
    for (let p = 0; p < this.nPat; p++) {
      let total = 0;
      for (let s = 0; s < 4; s++) {
        let prod = 1;
        for (let t = 0; t < tips.length; t++) {
          prod *= tips[t][p * 4 + s];
          if (prod === 0) break;
        }
        total += pi[s] * prod;
      }
      out[p] = total;
    }
    this._constLik = out;
    return out;
  }

  // -------------------------------------------------------------------------
  // Postorder: conditional likelihoods below each node
  // -------------------------------------------------------------------------

  computeDown() {
    const { nPat } = this;
    const nCat = this.nCat;
    const rates = this.model.rates;

    for (let i = 0; i < this.nodes.length; i++) {
      const node = this.nodes[i];
      if (isLeaf(node)) continue;
      const buf = this.down[i];
      const scale = this.downScale[i];
      buf.fill(1);
      scale.fill(0);

      for (const child of node.children) {
        const ci = this.index.get(child);
        const childBuf = isLeaf(child) ? this._tipVector(child) : this.down[ci];
        const childIsTip = isLeaf(child);
        const childScale = childIsTip ? null : this.downScale[ci];
        const len = clampBranch(child.length);

        for (let r = 0; r < nCat; r++) {
          const P = this.model.P(len * rates[r]);
          const catOffset = r * nPat * 4;
          for (let p = 0; p < nPat; p++) {
            const dst = catOffset + p * 4;
            const src = childIsTip ? p * 4 : catOffset + p * 4;
            const c0 = childBuf[src];
            const c1 = childBuf[src + 1];
            const c2 = childBuf[src + 2];
            const c3 = childBuf[src + 3];
            buf[dst] *= P[0] * c0 + P[1] * c1 + P[2] * c2 + P[3] * c3;
            buf[dst + 1] *= P[4] * c0 + P[5] * c1 + P[6] * c2 + P[7] * c3;
            buf[dst + 2] *= P[8] * c0 + P[9] * c1 + P[10] * c2 + P[11] * c3;
            buf[dst + 3] *= P[12] * c0 + P[13] * c1 + P[14] * c2 + P[15] * c3;
          }
        }
        if (childScale) for (let p = 0; p < nPat; p++) scale[p] += childScale[p];
      }
      rescale(buf, scale, nPat, nCat);
    }
    this._dirty = false;
    return this;
  }

  // -------------------------------------------------------------------------
  // Preorder: conditional likelihood of everything *outside* each clade
  // -------------------------------------------------------------------------

  /**
   * For every non-root node c this computes `other[c]`: the conditional
   * likelihood, seen from the parent end of the branch above c, of all data
   * except the clade below c. Optimising the length of that branch then costs
   * O(patterns x categories) per evaluation instead of a full tree traversal.
   */
  computeUp() {
    if (this._dirty) this.computeDown();
    const { nPat } = this;
    const nCat = this.nCat;
    const rates = this.model.rates;
    const stride = nPat * nCat * 4;

    const rootIdx = this.index.get(this.root);
    this.up[rootIdx].fill(1);
    this.upScale[rootIdx].fill(0);

    for (const node of preorder(this.root)) {
      if (isLeaf(node)) continue;
      const ni = this.index.get(node);
      const upNode = this.up[ni];
      const upNodeScale = this.upScale[ni];

      // Pre-compute each child's contribution seen from `node`.
      const kids = node.children;
      const contrib = kids.map((child) => {
        const ci = this.index.get(child);
        const childIsTip = isLeaf(child);
        const childBuf = childIsTip ? this._tipVector(child) : this.down[ci];
        const len = clampBranch(child.length);
        const out = new Float64Array(stride);
        for (let r = 0; r < nCat; r++) {
          const P = this.model.P(len * rates[r]);
          const catOffset = r * nPat * 4;
          for (let p = 0; p < nPat; p++) {
            const dst = catOffset + p * 4;
            const src = childIsTip ? p * 4 : catOffset + p * 4;
            const c0 = childBuf[src]; const c1 = childBuf[src + 1];
            const c2 = childBuf[src + 2]; const c3 = childBuf[src + 3];
            out[dst] = P[0] * c0 + P[1] * c1 + P[2] * c2 + P[3] * c3;
            out[dst + 1] = P[4] * c0 + P[5] * c1 + P[6] * c2 + P[7] * c3;
            out[dst + 2] = P[8] * c0 + P[9] * c1 + P[10] * c2 + P[11] * c3;
            out[dst + 3] = P[12] * c0 + P[13] * c1 + P[14] * c2 + P[15] * c3;
          }
        }
        return { out, scale: childIsTip ? null : this.downScale[ci] };
      });

      for (let k = 0; k < kids.length; k++) {
        const child = kids[k];
        const ci = this.index.get(child);
        const dst = this.other[ci];
        const dstScale = this.otherScale[ci];
        dst.set(upNode);
        dstScale.set(upNodeScale);
        for (let j = 0; j < kids.length; j++) {
          if (j === k) continue;
          const c = contrib[j];
          for (let t = 0; t < stride; t++) dst[t] *= c.out[t];
          if (c.scale) for (let p = 0; p < nPat; p++) dstScale[p] += c.scale[p];
        }
        rescale(dst, dstScale, nPat, nCat);

        // up[child] = P(branch) applied to `other`, i.e. the outside likelihood
        // expressed in terms of the state at the child.
        if (!isLeaf(child)) {
          const upChild = this.up[ci];
          const upChildScale = this.upScale[ci];
          const len = clampBranch(child.length);
          for (let r = 0; r < nCat; r++) {
            const P = this.model.P(len * rates[r]);
            const catOffset = r * nPat * 4;
            for (let p = 0; p < nPat; p++) {
              const o = catOffset + p * 4;
              const a0 = dst[o]; const a1 = dst[o + 1]; const a2 = dst[o + 2]; const a3 = dst[o + 3];
              upChild[o] = P[0] * a0 + P[1] * a1 + P[2] * a2 + P[3] * a3;
              upChild[o + 1] = P[4] * a0 + P[5] * a1 + P[6] * a2 + P[7] * a3;
              upChild[o + 2] = P[8] * a0 + P[9] * a1 + P[10] * a2 + P[11] * a3;
              upChild[o + 3] = P[12] * a0 + P[13] * a1 + P[14] * a2 + P[15] * a3;
            }
          }
          upChildScale.set(dstScale);
          rescale(upChild, upChildScale, nPat, nCat);
        }
      }
    }
    return this;
  }

  // -------------------------------------------------------------------------
  // Likelihood
  // -------------------------------------------------------------------------

  /** Per-pattern log-likelihoods (not weighted by pattern count). */
  patternLogLikelihoods() {
    if (this._dirty) this.computeDown();
    this.evaluations++;
    const { nPat } = this;
    const nCat = this.nCat;
    const pi = this.model.freqs;
    const catProbs = this.model.catProbs;
    const pinv = this.model.invProb;
    const constLik = pinv > 0 ? this._constantLikelihood() : null;
    const rootIdx = this.index.get(this.root);
    const buf = this.down[rootIdx];
    const scale = this.downScale[rootIdx];
    const out = new Float64Array(nPat);

    for (let p = 0; p < nPat; p++) {
      let varLik = 0;
      for (let r = 0; r < nCat; r++) {
        const o = r * nPat * 4 + p * 4;
        varLik += catProbs[r] * (pi[0] * buf[o] + pi[1] * buf[o + 1] + pi[2] * buf[o + 2] + pi[3] * buf[o + 3]);
      }
      const logVar = varLik > 0 ? Math.log(varLik) + scale[p] : -Infinity;
      if (pinv > 0) {
        const invPart = pinv * constLik[p];
        out[p] = invPart > 0 ? logSumExp(Math.log(invPart), logVar) : logVar;
      } else {
        out[p] = logVar;
      }
      if (!Number.isFinite(out[p])) out[p] = -1e12;
    }
    return out;
  }

  /** Total log-likelihood of the alignment. */
  lnL() {
    const pat = this.patternLogLikelihoods();
    let total = 0;
    for (let p = 0; p < this.nPat; p++) total += this.weights[p] * pat[p];
    return total;
  }

  /** Per-*site* log-likelihoods, expanded from patterns. Needed for RELL/SH tests. */
  siteLogLikelihoods() {
    const pat = this.patternLogLikelihoods();
    const map = this.data.siteToPattern;
    const out = new Float64Array(this.data.nSites);
    for (let i = 0; i < out.length; i++) out[i] = pat[map[i]];
    return out;
  }

  // -------------------------------------------------------------------------
  // Branch-length optimisation
  // -------------------------------------------------------------------------

  /**
   * Log-likelihood as a function of the length of the branch above `node`,
   * evaluated from the cached `other` and `down` vectors. O(patterns x cats).
   */
  _branchObjective(node) {
    const ni = this.index.get(node);
    const nPat = this.nPat;
    const nCat = this.nCat;
    const pi = this.model.freqs;
    const catProbs = this.model.catProbs;
    const rates = this.model.rates;
    const pinv = this.model.invProb;
    const constLik = pinv > 0 ? this._constantLikelihood() : null;
    const isTip = isLeaf(node);
    const dBuf = isTip ? this._tipVector(node) : this.down[ni];
    const dScale = isTip ? null : this.downScale[ni];
    const oBuf = this.other[ni];
    const oScale = this.otherScale[ni];
    const weights = this.weights;

    return (len) => {
      this.evaluations++;
      const t = clampBranch(len);
      let total = 0;
      for (let p = 0; p < nPat; p++) {
        let varLik = 0;
        for (let r = 0; r < nCat; r++) {
          const P = this.model.P(t * rates[r]);
          const catOffset = r * nPat * 4;
          const oi = catOffset + p * 4;
          const di = isTip ? p * 4 : catOffset + p * 4;
          const d0 = dBuf[di]; const d1 = dBuf[di + 1]; const d2 = dBuf[di + 2]; const d3 = dBuf[di + 3];
          let acc = 0;
          for (let s = 0; s < 4; s++) {
            const ps = s * 4;
            const trans = P[ps] * d0 + P[ps + 1] * d1 + P[ps + 2] * d2 + P[ps + 3] * d3;
            acc += pi[s] * oBuf[oi + s] * trans;
          }
          varLik += catProbs[r] * acc;
        }
        const sc = oScale[p] + (dScale ? dScale[p] : 0);
        const logVar = varLik > 0 ? Math.log(varLik) + sc : -1e12;
        let lp = logVar;
        if (pinv > 0) {
          const invPart = pinv * constLik[p];
          if (invPart > 0) lp = logSumExp(Math.log(invPart), logVar);
        }
        total += weights[p] * (Number.isFinite(lp) ? lp : -1e12);
      }
      return total;
    };
  }

  /**
   * Optimise every branch length by coordinate ascent.
   * Each round recomputes the up/down sweep, then visits all branches; the
   * loop stops when a full round gains less than `tol` log-likelihood units.
   */
  optimiseBranchLengths({ rounds = 8, tol = 1e-4 } = {}) {
    let last = -Infinity;
    let lnl = -Infinity;
    for (let round = 0; round < rounds; round++) {
      this.computeDown();
      this.computeUp();
      for (const node of this.nodes) {
        if (node === this.root) continue;
        const r = optimiseOneBranch(this._branchObjective(node), 1e-5, 40);
        node.length = r.x;
        lnl = r.fx;
      }
      this._dirty = true;
      lnl = this.lnL();
      if (lnl - last < tol) { last = lnl; break; }
      last = lnl;
    }
    return last;
  }

  // -------------------------------------------------------------------------
  // Model-parameter optimisation
  // -------------------------------------------------------------------------

  /**
   * Jointly optimise the free parameters of the substitution model (kappa,
   * TN93's two transition rates, GTR exchangeabilities, gamma shape, invariable
   * proportion) together with branch lengths, alternating between the two
   * blocks until the likelihood stops improving.
   *
   * Base frequencies are held at their empirical values, which is the standard
   * "+F" treatment and is what MEGA, PhyML and IQ-TREE do by default; the ML
   * estimate differs negligibly and costs three more optimised parameters.
   */
  optimiseModel({ rounds = 4, tol = 1e-3, optimiseBranches = true } = {}) {
    const spec = MODEL_SPEC[this.model.model].rates;
    const params = [];
    if (spec === 'kappa') params.push({ name: 'kappa', min: 0.02, max: 100, value: this.model.kappa });
    if (spec === 'tn93') {
      params.push({ name: 'kappa', min: 0.02, max: 100, value: this.model.kappa });
      params.push({ name: 'kappa2', min: 0.02, max: 100, value: this.model.kappa2 });
    }
    if (spec === 'gtr') {
      for (let i = 0; i < 5; i++) params.push({ name: `gtr${i}`, min: 1e-4, max: 100, value: this.model.gtrRates[i] });
    }
    if (this.model.usesGamma) params.push({ name: 'alpha', min: 0.02, max: 50, value: Number.isFinite(this.model.alpha) ? this.model.alpha : 1 });
    if (this.model.usesInvariable) params.push({ name: 'pinv', min: 0, max: 0.99, value: this.model.pinv || 0.1 });

    let best = optimiseBranches ? this.optimiseBranchLengths() : this.lnL();
    if (!params.length) return { lnL: best, model: this.model };

    const evaluate = (values) => {
      this.setModel(this._modelWith(params, values));
      this._dirty = true;
      return this.lnL();
    };

    for (let round = 0; round < rounds; round++) {
      const before = best;
      const result = coordinateAscent(params, evaluate, { tol, maxRounds: 6 });
      params.forEach((p, i) => { p.value = result.values[i]; });
      this._jointAlphaPinv(params, evaluate);
      this.setModel(this._modelWith(params, params.map((p) => p.value)));
      this._dirty = true;
      best = optimiseBranches ? this.optimiseBranchLengths() : this.lnL();
      if (best - before < tol) break;
    }
    this.setModel(this._modelWith(params, params.map((p) => p.value)));
    this._dirty = true;
    return { lnL: this.lnL(), model: this.model };
  }

  /**
   * The gamma shape and the invariable proportion trade off against each other
   * along a long, flat ridge: coordinate ascent started from a poor pinv walks
   * to the boundary pinv = 0 and stops. When both are free the pair is therefore
   * searched jointly: a coarse sweep over pinv with alpha re-optimised at each
   * point, then a Brent refinement of pinv around the best value.
   */
  _jointAlphaPinv(params, evaluate) {
    const ai = params.findIndex((p) => p.name === 'alpha');
    const pi = params.findIndex((p) => p.name === 'pinv');
    if (ai < 0 || pi < 0) return;

    const values = params.map((p) => p.value);
    const constantFraction = this._constantSiteFraction();
    const grid = [0, 0.05, 0.1, 0.2, 0.3, 0.45, 0.6, constantFraction * 0.5, constantFraction * 0.9]
      .filter((v) => v >= 0 && v < 0.99)
      .sort((a, b) => a - b);

    let bestValue = -Infinity;
    let bestAlpha = values[ai];
    let bestPinv = values[pi];
    for (const pinv of grid) {
      const trial = values.slice();
      trial[pi] = pinv;
      const r = brentMax((alpha) => { const t2 = trial.slice(); t2[ai] = alpha; return evaluate(t2); },
        params[ai].min, params[ai].max, 1e-4, 30);
      if (r.fx > bestValue) { bestValue = r.fx; bestAlpha = r.x; bestPinv = pinv; }
    }

    const refine = brentMax((pinv) => {
      const t2 = values.slice(); t2[ai] = bestAlpha; t2[pi] = pinv; return evaluate(t2);
    }, Math.max(0, bestPinv - 0.15), Math.min(0.98, bestPinv + 0.15), 1e-5, 30);
    if (refine.fx > bestValue) { bestValue = refine.fx; bestPinv = refine.x; }

    const polish = brentMax((alpha) => {
      const t2 = values.slice(); t2[ai] = alpha; t2[pi] = bestPinv; return evaluate(t2);
    }, params[ai].min, params[ai].max, 1e-5, 30);
    if (polish.fx > bestValue) bestAlpha = polish.x;

    params[ai].value = bestAlpha;
    params[pi].value = bestPinv;
  }

  /** Fraction of sites compatible with a single unchanged nucleotide. */
  _constantSiteFraction() {
    const constLik = this._constantLikelihood();
    let total = 0;
    let constant = 0;
    for (let p = 0; p < this.nPat; p++) {
      total += this.weights[p];
      if (constLik[p] > 0) constant += this.weights[p];
    }
    return total ? constant / total : 0;
  }

  _modelWith(params, values) {
    const overrides = {};
    const gtr = this.model.gtrRates.slice();
    params.forEach((p, i) => {
      const v = values[i];
      if (p.name === 'kappa') overrides.kappa = v;
      else if (p.name === 'kappa2') overrides.kappa2 = v;
      else if (p.name === 'alpha') overrides.alpha = v;
      else if (p.name === 'pinv') overrides.pinv = v;
      else if (p.name.startsWith('gtr')) gtr[Number(p.name.slice(3))] = v;
    });
    overrides.gtrRates = gtr;
    return this.model.clone(overrides);
  }

  // -------------------------------------------------------------------------
  // NNI topology search
  // -------------------------------------------------------------------------

  /**
   * Hill-climbing search over nearest-neighbour interchanges.
   *
   * Each internal branch defines four surrounding subtrees and therefore three
   * possible local topologies. Every sweep evaluates the two alternatives for
   * every internal branch, applying the single best improvement found and then
   * re-optimising; the search stops when no interchange improves the likelihood.
   * The affected branch is re-optimised before each evaluation, which is the
   * "lazy" NNI strategy used by PhyML and RAxML.
   *
   * @param {object} opts
   * @param {number} opts.maxSweeps  safety bound on the number of sweeps
   * @param {function} opts.onProgress  called with (sweep, lnL)
   */
  nniSearch({ maxSweeps = 200, tol = 1e-4, onProgress = null } = {}) {
    let best = this.optimiseBranchLengths();
    let sweeps = 0;
    let applied = 0;

    for (let sweep = 0; sweep < maxSweeps; sweep++) {
      sweeps++;
      const candidates = this._internalBranches();
      let bestGain = tol;
      let bestMove = null;

      for (const branch of candidates) {
        for (const move of nniMoves(branch, this.root)) {
          applyMove(move);
          this.setTree(this.root);
          this._dirty = true;
          this.computeDown();
          this.computeUp();
          const r = optimiseOneBranch(this._branchObjective(branch.child), 1e-4, 25);
          const gain = r.fx - best;
          if (gain > bestGain) {
            bestGain = gain;
            bestMove = { move, length: r.x };
          }
          applyMove(move); // the same swap is its own inverse
          this.setTree(this.root);
        }
      }

      if (!bestMove) break;
      applyMove(bestMove.move);
      bestMove.move.branchNode.length = clampBranch(bestMove.length);
      this.setTree(this.root);
      this._dirty = true;
      best = this.optimiseBranchLengths({ rounds: 3 });
      applied++;
      if (onProgress) onProgress(sweep + 1, best);
    }
    return { lnL: best, sweeps, moves: applied };
  }

  /** Internal branches: parent-child pairs where both ends have children. */
  _internalBranches() {
    const out = [];
    for (const node of this.nodes) {
      if (node === this.root || isLeaf(node)) continue;
      const parent = node.parent;
      if (!parent) continue;
      // The branch is internal if the parent side also has at least two other subtrees.
      const otherCount = parent.children.length - 1 + (parent.parent ? 1 : 0);
      if (otherCount >= 2) out.push({ child: node, parent });
    }
    return out;
  }

  // -------------------------------------------------------------------------
  // SH-aLRT branch support
  // -------------------------------------------------------------------------

  /**
   * Shimodaira–Hasegawa-like approximate likelihood-ratio test
   * (Guindon et al. 2010, Syst Biol 59:307).
   *
   * For each internal branch the two NNI alternatives are evaluated, giving
   * per-site log-likelihood vectors for the three local topologies. The test
   * statistic is 2(l1 - l2) where l2 is the better alternative. Its null
   * distribution is obtained by RELL resampling of the centred per-site
   * differences, with the Shimodaira–Hasegawa correction for having taken a
   * maximum over the two alternatives.
   *
   * Support is reported as (1 - p) x 100, so values are on the same 0–100 scale
   * as bootstrap percentages. Values >= 80 are conventionally treated as strong.
   */
  shALRT({ replicates = 1000, rng = null, onProgress = null } = {}) {
    const support = new Map();
    const branches = this._internalBranches();
    const nSites = this.data.nSites;
    const draw = rng ? () => rng.int(nSites) : () => Math.floor(Math.random() * nSites);

    this._dirty = true;
    const baseSites = this.siteLogLikelihoods();

    branches.forEach((branch, bi) => {
      const alternatives = [];
      for (const move of nniMoves(branch, this.root)) {
        applyMove(move);
        this.setTree(this.root);
        this._dirty = true;
        this.computeDown();
        this.computeUp();
        const r = optimiseOneBranch(this._branchObjective(branch.child), 1e-4, 25);
        const saved = branch.child.length;
        branch.child.length = r.x;
        this._dirty = true;
        alternatives.push(Float64Array.from(this.siteLogLikelihoods()));
        branch.child.length = saved;
        applyMove(move);
        this.setTree(this.root);
      }
      this._dirty = true;

      if (alternatives.length < 2) { support.set(branch.child, null); return; }

      // Observed statistic.
      const diffs = alternatives.map((alt) => {
        const d = new Float64Array(nSites);
        for (let i = 0; i < nSites; i++) d[i] = baseSites[i] - alt[i];
        return d;
      });
      const sums = diffs.map((d) => { let s = 0; for (let i = 0; i < nSites; i++) s += d[i]; return s; });
      const observed = 2 * Math.min(...sums);

      // RELL null distribution of the centred maximum.
      let exceed = 0;
      for (let b = 0; b < replicates; b++) {
        const acc = new Float64Array(diffs.length);
        for (let i = 0; i < nSites; i++) {
          const k = draw();
          for (let d = 0; d < diffs.length; d++) acc[d] += diffs[d][k];
        }
        let maxCentred = -Infinity;
        for (let d = 0; d < diffs.length; d++) {
          const centred = sums[d] - acc[d]; // positive when the alternative gains
          if (centred > maxCentred) maxCentred = centred;
        }
        if (2 * maxCentred >= observed) exceed++;
      }
      const p = exceed / replicates;
      support.set(branch.child, Math.max(0, Math.min(100, (1 - p) * 100)));
      if (onProgress) onProgress((bi + 1) / branches.length);
    });

    for (const [node, value] of support) { if (value != null) node.shalrt = value; }
    return support;
  }
}

// ---------------------------------------------------------------------------
// NNI machinery
// ---------------------------------------------------------------------------

/**
 * The two nearest-neighbour interchanges around an internal branch.
 * A move is a pair of nodes to exchange between their parents' child lists;
 * applying the same move twice restores the original topology.
 */
function nniMoves(branch, root) {
  const { child, parent } = branch;
  if (child.children.length < 2) return [];
  const near = child.children;
  const far = parent.children.filter((c) => c !== child);

  if (parent === root) {
    // Root is trifurcating: the far side is the two remaining root children.
    if (far.length < 2) return [];
    return [
      { a: near[1], b: far[0], branchNode: child },
      { a: near[1], b: far[1], branchNode: child },
    ];
  }
  // Non-root parent: the far side is its other child plus the direction to the
  // grandparent. Swapping with the grandparent direction is equivalent to
  // swapping with the sibling in the unrooted sense, so one sibling suffices.
  if (!far.length) return [];
  return [
    { a: near[0], b: far[0], branchNode: child },
    { a: near[1], b: far[0], branchNode: child },
  ];
}

function applyMove(move) {
  const { a, b } = move;
  const pa = a.parent;
  const pb = b.parent;
  const ia = pa.children.indexOf(a);
  const ib = pb.children.indexOf(b);
  pa.children[ia] = b;
  pb.children[ib] = a;
  a.parent = pb;
  b.parent = pa;
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Sanitise a branch length for likelihood evaluation.
 *
 * This must not impose the optimiser's upper bound: an imported tree may carry
 * branches longer than anything the optimiser would propose, and silently
 * shortening them corrupts the likelihood of exactly the long-branch taxa that
 * matter most. Only non-finite and negative values are corrected.
 */
/**
 * Maximise a branch-length objective on a logarithmic scale.
 *
 * Branch lengths span seven orders of magnitude (1e-8 to 1e2) and the
 * likelihood surface is close to quadratic in log(t), not in t. Searching t
 * directly makes Brent start its bracket around t = 38 and crawl back down;
 * searching log(t) converges in a handful of evaluations across the whole range.
 */
function optimiseOneBranch(objective, tol, maxIter) {
  const r = brentMax((u) => objective(Math.exp(u)),
    Math.log(MIN_BRANCH), Math.log(MAX_BRANCH), tol, maxIter);
  return { x: clampBranch(Math.exp(r.x)), fx: r.fx };
}

function clampBranch(x) {
  if (!Number.isFinite(x) || x < MIN_BRANCH) return MIN_BRANCH;
  return Math.min(EVAL_BRANCH_CEILING, x);
}

function rescale(buf, scale, nPat, nCat) {
  for (let p = 0; p < nPat; p++) {
    let max = 0;
    for (let r = 0; r < nCat; r++) {
      const o = r * nPat * 4 + p * 4;
      for (let s = 0; s < 4; s++) { const v = buf[o + s]; if (v > max) max = v; }
    }
    if (max > 0 && max < SCALE_THRESHOLD) {
      for (let r = 0; r < nCat; r++) {
        const o = r * nPat * 4 + p * 4;
        for (let s = 0; s < 4; s++) buf[o + s] *= SCALE_FACTOR;
      }
      scale[p] -= LOG_SCALE_FACTOR;
    }
  }
}

function logSumExp(a, b) {
  if (a === -Infinity) return b;
  if (b === -Infinity) return a;
  const m = Math.max(a, b);
  return m + Math.log(Math.exp(a - m) + Math.exp(b - m));
}

/**
 * Build a starting tree, optimise it under the given model, and optionally run
 * an NNI search. Convenience wrapper used by the pipeline and the CLI.
 */
export function maximumLikelihoodTree(data, model, startTree, {
  search = true, optimiseModelParams = true, onProgress = null,
} = {}) {
  const engine = new LikelihoodEngine(data, model);
  const tree = cloneTree(startTree);
  relink(tree);
  engine.setTree(tree);

  const t0 = now();
  if (optimiseModelParams) {
    if (onProgress) onProgress(0.1, 'Optimising model parameters');
    engine.optimiseModel();
  } else {
    engine.optimiseBranchLengths();
  }

  let searchInfo = { sweeps: 0, moves: 0 };
  if (search) {
    if (onProgress) onProgress(0.4, 'NNI topology search');
    searchInfo = engine.nniSearch({
      onProgress: (sweep) => onProgress && onProgress(Math.min(0.85, 0.4 + sweep * 0.05), `NNI sweep ${sweep}`),
    });
  }

  if (optimiseModelParams) {
    if (onProgress) onProgress(0.9, 'Final parameter polish');
    engine.optimiseModel({ rounds: 2 });
  }

  const lnL = engine.lnL();
  return {
    tree: engine.root,
    engine,
    model: engine.model,
    lnL,
    sweeps: searchInfo.sweeps,
    moves: searchInfo.moves,
    evaluations: engine.evaluations,
    elapsedMs: now() - t0,
  };
}

function now() {
  return typeof performance !== 'undefined' ? performance.now() : Date.now();
}
