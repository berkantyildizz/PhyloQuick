/**
 * Substitution-model selection by information criteria.
 *
 * Every candidate model is fitted by maximum likelihood on a fixed starting
 * topology (the distance tree), with branch lengths and all free parameters
 * re-optimised for that model. Models are then ranked by AIC, corrected AIC
 * and BIC, exactly as jModelTest/ModelFinder do.
 *
 * Fixing the topology during selection is the standard compromise: re-searching
 * the tree for each of 24 candidates would cost roughly 24 times more for a
 * choice that is almost never affected, and it is what ModelFinder does by
 * default too.
 *
 * Free-parameter counts include branch lengths, because AIC and BIC are only
 * comparable across models if the same quantities are counted every time.
 */

import { SubstitutionModel, MODEL_NAMES } from './models.js';
import { LikelihoodEngine } from './likelihood.js';
import { cloneTree, relink, postorder } from './tree.js';

export const RATE_VARIANTS = ['', '+I', '+G', '+I+G'];

/**
 * Build the candidate list. The default set is the 24 models formed by the six
 * base models crossed with the four rate-heterogeneity variants.
 */
export function candidateModels({ base = MODEL_NAMES, variants = RATE_VARIANTS } = {}) {
  const out = [];
  for (const b of base) {
    for (const v of variants) {
      out.push({
        base: b,
        invariable: v.includes('+I'),
        gamma: v.includes('+G'),
        label: b + v.replace('+G', '+G4'),
      });
    }
  }
  return out;
}

/**
 * Fit and rank candidate models.
 *
 * @param {object} data      compressed patterns from seq.compressPatterns
 * @param {object} startTree tree used for every candidate
 * @param {object} opts
 * @param {number[]} opts.freqs   empirical base frequencies
 * @param {number} opts.nCat      discrete-gamma categories
 * @param {string[]} opts.base    restrict the base-model set
 * @param {function} opts.onProgress  (fraction, label) => void
 */
export function selectModel(data, startTree, opts = {}) {
  const freqs = opts.freqs || [0.25, 0.25, 0.25, 0.25];
  const nCat = opts.nCat ?? 4;
  const candidates = candidateModels({ base: opts.base, variants: opts.variants });
  const nSites = data.nSites;
  const branchCount = postorder(startTree).filter((n) => n.parent).length;

  const results = [];
  const t0 = now();

  candidates.forEach((candidate, i) => {
    if (opts.onProgress) opts.onProgress(i / candidates.length, candidate.label);
    const model = new SubstitutionModel({
      model: candidate.base,
      freqs,
      kappa: 2,
      kappa2: 2,
      gtrRates: [1, 1, 1, 1, 1],
      alpha: candidate.gamma ? 0.5 : Infinity,
      pinv: candidate.invariable ? 0.1 : 0,
      nCat,
    });
    const tree = relink(cloneTree(startTree));
    const engine = new LikelihoodEngine(data, model).setTree(tree);
    const fit = engine.optimiseModel({ rounds: 4, tol: 1e-4 });

    // Branch lengths are estimated parameters and must be counted.
    const k = fit.model.freeParams + branchCount;
    const lnL = fit.lnL;
    const aic = -2 * lnL + 2 * k;
    const aicc = nSites - k - 1 > 0
      ? aic + (2 * k * (k + 1)) / (nSites - k - 1)
      : Infinity;
    const bic = -2 * lnL + k * Math.log(nSites);

    // The label is the *requested* model, not the fitted one: an +I model whose
    // invariable proportion collapses to zero must still appear as "+I" in the
    // ranking, otherwise two rows carry the same name and the table cannot be
    // read. Boundary collapses are flagged instead.
    const collapsed = [];
    if (candidate.invariable && fit.model.pinv <= 1e-6) collapsed.push('pinv->0');
    if (candidate.gamma && fit.model.alpha > 45) collapsed.push('alpha->inf');

    results.push({
      label: candidate.label,
      fittedLabel: fit.model.label,
      collapsed,
      base: candidate.base,
      lnL,
      freeParameters: k,
      modelParameters: fit.model.freeParams,
      branches: branchCount,
      AIC: aic,
      AICc: aicc,
      BIC: bic,
      parameters: fit.model.describe(),
      tree,
      model: fit.model,
    });
  });

  const rank = (key) => {
    const sorted = [...results].sort((a, b) => a[key] - b[key]);
    const best = sorted[0][key];
    sorted.forEach((r, i) => {
      r[`${key}rank`] = i + 1;
      r[`d${key}`] = r[key] - best;
    });
    return sorted[0];
  };

  const bestAIC = rank('AIC');
  const bestAICc = rank('AICc');
  const bestBIC = rank('BIC');

  // Akaike weights over the AIC surface.
  const minAIC = bestAIC.AIC;
  let weightSum = 0;
  for (const r of results) { r._w = Math.exp(-0.5 * (r.AIC - minAIC)); weightSum += r._w; }
  for (const r of results) { r.akaikeWeight = r._w / weightSum; delete r._w; }

  results.sort((a, b) => a.BIC - b.BIC);

  if (opts.onProgress) opts.onProgress(1, 'done');
  return {
    results,
    bestAIC: bestAIC.label,
    bestAICc: bestAICc.label,
    bestBIC: bestBIC.label,
    best: bestBIC,
    criterion: 'BIC',
    nSites,
    elapsedMs: now() - t0,
  };
}

/** Tab-separated table for export, ordered as ranked. */
export function toTsv(selection) {
  const header = ['Model', 'lnL', 'FreeParams', 'AIC', 'dAIC', 'AICc', 'dAICc', 'BIC', 'dBIC', 'AkaikeWeight', 'Parameters'];
  const lines = [header.join('\t')];
  for (const r of selection.results) {
    const params = Object.entries(r.parameters)
      .filter(([k]) => !['model', 'label', 'freeParameters'].includes(k))
      .map(([k, v]) => `${k}=${Array.isArray(v) ? v.join('/') : v}`)
      .join('; ');
    lines.push([
      r.label + (r.collapsed && r.collapsed.length ? ` (${r.collapsed.join(',')})` : ''),
      r.lnL.toFixed(4), r.freeParameters,
      r.AIC.toFixed(4), r.dAIC.toFixed(4),
      Number.isFinite(r.AICc) ? r.AICc.toFixed(4) : 'NA',
      Number.isFinite(r.dAICc) ? r.dAICc.toFixed(4) : 'NA',
      r.BIC.toFixed(4), r.dBIC.toFixed(4),
      r.akaikeWeight.toExponential(4), params,
    ].join('\t'));
  }
  return lines.join('\n') + '\n';
}

function now() {
  return typeof performance !== 'undefined' ? performance.now() : Date.now();
}
