/**
 * Tree comparison metrics, used by the simulation-based validation and by the
 * "compare with an imported tree" panel.
 */

import { bipartitions, leafNames, postorder, isLeaf } from './tree.js';

/**
 * Robinson–Foulds distance (Robinson & Foulds 1981): the number of
 * bipartitions present in exactly one of the two trees.
 *
 * Returns the raw distance, the normalised distance (RF divided by its maximum
 * 2(n-3) for two fully resolved unrooted trees) and the number of shared
 * splits, plus a note when the trees are not fully resolved (a polytomy lowers
 * RF for reasons unrelated to agreement).
 */
export function robinsonFoulds(treeA, treeB) {
  const namesA = leafNames(treeA).slice().sort();
  const namesB = leafNames(treeB).slice().sort();
  if (namesA.length !== namesB.length || namesA.some((n, i) => n !== namesB[i])) {
    const onlyA = namesA.filter((n) => !namesB.includes(n));
    const onlyB = namesB.filter((n) => !namesA.includes(n));
    throw new Error(
      `trees have different taxon sets (only in first: ${onlyA.slice(0, 5).join(', ') || 'none'}; `
      + `only in second: ${onlyB.slice(0, 5).join(', ') || 'none'})`,
    );
  }

  const order = namesA;
  const splitsA = new Set(bipartitions(treeA, order).keys());
  const splitsB = new Set(bipartitions(treeB, order).keys());

  let shared = 0;
  for (const s of splitsA) if (splitsB.has(s)) shared++;
  const rf = (splitsA.size - shared) + (splitsB.size - shared);
  const n = order.length;
  const maxRF = Math.max(2 * (n - 3), 1);

  return {
    rf,
    normalised: rf / maxRF,
    maxRF,
    sharedSplits: shared,
    splitsA: splitsA.size,
    splitsB: splitsB.size,
    taxa: n,
    fullyResolved: splitsA.size === n - 3 && splitsB.size === n - 3,
  };
}

/**
 * Split-recovery rates against a reference (true) tree.
 * Precision = fraction of the estimate's splits that are correct;
 * recall     = fraction of the reference's splits that were recovered.
 * Reported alongside RF because RF alone hides which direction the error runs.
 */
export function splitAccuracy(trueTree, estimatedTree) {
  const order = leafNames(trueTree).slice().sort();
  const truth = new Set(bipartitions(trueTree, order).keys());
  const est = new Set(bipartitions(estimatedTree, order).keys());
  let correct = 0;
  for (const s of est) if (truth.has(s)) correct++;
  return {
    precision: est.size ? correct / est.size : 0,
    recall: truth.size ? correct / truth.size : 0,
    correctSplits: correct,
    trueSplits: truth.size,
    estimatedSplits: est.size,
  };
}

/**
 * Branch-score distance (Kuhner & Felsenstein 1994): the Euclidean distance
 * between the two trees' branch-length vectors, indexed by bipartition, with a
 * length of zero for splits absent from a tree. Unlike RF this is sensitive to
 * how wrong a branch length is, not only to whether the split exists.
 */
export function branchScoreDistance(treeA, treeB) {
  const order = leafNames(treeA).slice().sort();
  const a = splitLengths(treeA, order);
  const b = splitLengths(treeB, order);
  const keys = new Set([...a.keys(), ...b.keys()]);
  let sum = 0;
  for (const k of keys) {
    const d = (a.get(k) || 0) - (b.get(k) || 0);
    sum += d * d;
  }
  return Math.sqrt(sum);
}

function splitLengths(tree, order) {
  const map = new Map();
  const splits = bipartitions(tree, order);
  for (const [key, node] of splits) map.set(key, node.length);
  // Terminal branches, keyed by taxon name.
  for (const node of postorder(tree)) {
    if (isLeaf(node)) map.set('leaf:' + node.name, node.length);
  }
  return map;
}

/**
 * Quartet distance approximated by sampling. The exact algorithm is O(n^2)
 * but intricate; for the sample sizes PhyloQuick targets a Monte-Carlo estimate
 * with a reported standard error is more useful than an exact number, and it
 * degrades gracefully on large trees.
 */
export function quartetDistance(treeA, treeB, { samples = 20000, rng = null } = {}) {
  const order = leafNames(treeA).slice().sort();
  const n = order.length;
  if (n < 4) return { distance: 0, samples: 0, standardError: 0 };
  const topoA = quartetResolver(treeA, order);
  const topoB = quartetResolver(treeB, order);
  const draw = rng ? () => rng.int(n) : () => Math.floor(Math.random() * n);

  let differ = 0;
  let taken = 0;
  for (let s = 0; s < samples; s++) {
    const idx = new Set();
    while (idx.size < 4) idx.add(draw());
    const q = [...idx];
    const ra = topoA(q);
    const rb = topoB(q);
    if (ra === null || rb === null) continue;
    taken++;
    if (ra !== rb) differ++;
  }
  const p = taken ? differ / taken : 0;
  return {
    distance: p,
    samples: taken,
    standardError: taken ? Math.sqrt(p * (1 - p) / taken) : 0,
  };
}

/** Returns a function that resolves a quartet of taxon indices to 0, 1 or 2. */
function quartetResolver(tree, order) {
  const index = new Map(order.map((name, i) => [name, i]));
  const splits = [...bipartitions(tree, order).keys()];
  return (q) => {
    // For each split, check whether it separates the quartet 2-2.
    for (const key of splits) {
      const sides = q.map((i) => key[i] === '1');
      const ones = sides.filter(Boolean).length;
      if (ones !== 2) continue;
      const a = sides[0] === sides[1];
      const b = sides[0] === sides[2];
      if (a) return 0;      // (q0,q1 | q2,q3)
      if (b) return 1;      // (q0,q2 | q1,q3)
      return 2;             // (q0,q3 | q1,q2)
    }
    return null;            // unresolved in this tree
  };
  void index;
}
