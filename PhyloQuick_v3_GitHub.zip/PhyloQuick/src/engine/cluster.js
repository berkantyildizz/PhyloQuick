/**
 * Distance-based tree construction: Neighbor-Joining, BIONJ and UPGMA.
 *
 * All three take a symmetric distance matrix and a list of taxon names and
 * return a tree in the shared node representation from tree.js. NJ and BIONJ
 * produce unrooted trees (root with three children); UPGMA produces a rooted
 * ultrametric tree.
 */

import { makeNode, relink } from './tree.js';

/**
 * Neighbor-Joining (Saitou & Nei 1987, Studier & Keppler 1988 formulation).
 *
 * The Q-criterion is evaluated with the O(n^2) update of Studier & Keppler,
 * giving overall O(n^3) time and O(n^2) memory.
 */
export function neighborJoining(names, matrix) {
  return joinGeneric(names, matrix, false);
}

/**
 * BIONJ (Gascuel 1997): identical agglomeration order to NJ, but the reduced
 * distances are a variance-weighted combination rather than a plain average.
 * On data with unequal substitution rates this recovers branch lengths more
 * accurately than NJ at the same computational cost.
 */
export function bionj(names, matrix) {
  return joinGeneric(names, matrix, true);
}

function joinGeneric(names, matrix, useVariance) {
  const n = names.length;
  if (n === 0) throw new Error('no taxa');
  if (n === 1) return makeLeafOnly(names);
  if (n === 2) {
    const root = makeNode();
    const a = makeNode(names[0], matrix[0][1] / 2);
    const b = makeNode(names[1], matrix[0][1] / 2);
    root.children = [a, b];
    return relink(root);
  }

  // Pre-allocate for the 2n-1 nodes an agglomerative join can create, so the
  // reduction step never has to reallocate.
  const cap = 2 * n;
  const D = Array.from({ length: cap }, () => new Float64Array(cap));
  const V = useVariance ? Array.from({ length: cap }, () => new Float64Array(cap)) : null;
  for (let i = 0; i < n; i++) {
    for (let j = 0; j < n; j++) {
      D[i][j] = matrix[i][j];
      if (useVariance) V[i][j] = matrix[i][j];
    }
  }
  const active = [];
  const nodes = [];
  for (let i = 0; i < n; i++) {
    active.push(i);
    nodes.push(makeNode(names[i], 0));
  }

  const rowSum = new Float64Array(cap);

  while (active.length > 2) {
    const m = active.length;
    for (const i of active) {
      let s = 0;
      for (const j of active) if (j !== i) s += D[i][j];
      rowSum[i] = s;
    }
    let bestQ = Infinity; let bi = -1; let bj = -1;
    for (let a = 0; a < m; a++) {
      const i = active[a];
      for (let b = a + 1; b < m; b++) {
        const j = active[b];
        const q = (m - 2) * D[i][j] - rowSum[i] - rowSum[j];
        if (q < bestQ) { bestQ = q; bi = i; bj = j; }
      }
    }

    const dij = D[bi][bj];
    const delta = (rowSum[bi] - rowSum[bj]) / (m - 2);
    let li = 0.5 * (dij + delta);
    let lj = 0.5 * (dij - delta);
    // Negative branch lengths are an artefact of NJ on non-additive data; the
    // standard fix (Kuhner & Felsenstein 1994) transfers the deficit to the
    // sibling so the pairwise distance is preserved.
    if (li < 0) { lj += -li; li = 0; }
    if (lj < 0) { li += -lj; lj = 0; }

    const parent = makeNode();
    nodes[bi].length = li;
    nodes[bj].length = lj;
    parent.children = [nodes[bi], nodes[bj]];

    // BIONJ weighting: lambda minimises the variance of the reduced distances
    // (Gascuel 1997, eq. 9). lambda = 1/2 recovers plain NJ.
    let lambda = 0.5;
    if (useVariance) {
      let acc = 0;
      for (const k of active) {
        if (k === bi || k === bj) continue;
        acc += V[bj][k] - V[bi][k];
      }
      const denom = 2 * (m - 2) * V[bi][bj];
      lambda = denom > 0 ? 0.5 + acc / denom : 0.5;
      if (!Number.isFinite(lambda)) lambda = 0.5;
      lambda = Math.min(1, Math.max(0, lambda));
    }

    const u = nodes.length;
    nodes.push(parent);
    for (const k of active) {
      if (k === bi || k === bj) continue;
      const dk = useVariance
        ? lambda * (D[bi][k] - li) + (1 - lambda) * (D[bj][k] - lj)
        : 0.5 * (D[bi][k] + D[bj][k] - dij);
      D[u][k] = Math.max(dk, 0);
      D[k][u] = D[u][k];
      if (useVariance) {
        const vk = lambda * V[bi][k] + (1 - lambda) * V[bj][k] - lambda * (1 - lambda) * V[bi][bj];
        V[u][k] = Math.max(vk, 0);
        V[k][u] = V[u][k];
      }
    }

    active.splice(active.indexOf(bi), 1);
    active.splice(active.indexOf(bj), 1);
    active.push(u);
  }

  // Three-way join of the final two clusters into an unrooted trifurcating root.
  const [x, y] = active;
  const root = makeNode();
  const last = D[x][y];
  const cx = nodes[x];
  const cy = nodes[y];
  // Merge so that the root has three children whenever possible.
  if (cx.children.length && cy.children.length) {
    cx.length = last;
    root.children = [...cy.children, cx];
  } else if (cy.children.length) {
    cx.length = last;
    root.children = [...cy.children, cx];
  } else if (cx.children.length) {
    cy.length = last;
    root.children = [...cx.children, cy];
  } else {
    cx.length = last / 2;
    cy.length = last / 2;
    root.children = [cx, cy];
  }
  return relink(root);
}

/**
 * UPGMA (Sokal & Michener 1958). Produces a rooted, ultrametric tree: node
 * heights are half the average distance between the merged clusters, so the
 * tree implies a strict molecular clock. Reported here for comparison, not as
 * the default, because the clock assumption is rarely met.
 */
export function upgma(names, matrix) {
  const n = names.length;
  if (n === 1) return makeLeafOnly(names);
  const cap = 2 * n;
  const D = Array.from({ length: cap }, () => new Float64Array(cap));
  for (let i = 0; i < n; i++) for (let j = 0; j < n; j++) D[i][j] = matrix[i][j];
  const size = new Array(cap).fill(1);
  const height = new Array(cap).fill(0);
  const nodes = names.map((nm) => makeNode(nm, 0));
  const active = [...Array(n).keys()];

  while (active.length > 1) {
    let best = Infinity; let bi = -1; let bj = -1;
    for (let a = 0; a < active.length; a++) {
      for (let b = a + 1; b < active.length; b++) {
        const i = active[a]; const j = active[b];
        if (D[i][j] < best) { best = D[i][j]; bi = i; bj = j; }
      }
    }
    const h = best / 2;
    const parent = makeNode();
    nodes[bi].length = Math.max(h - height[bi], 0);
    nodes[bj].length = Math.max(h - height[bj], 0);
    parent.children = [nodes[bi], nodes[bj]];

    const u = nodes.length;
    nodes.push(parent);
    size[u] = size[bi] + size[bj];
    height[u] = h;
    for (const k of active) {
      if (k === bi || k === bj) continue;
      const d = (size[bi] * D[bi][k] + size[bj] * D[bj][k]) / (size[bi] + size[bj]);
      D[u][k] = d;
      D[k][u] = d;
    }
    active.splice(active.indexOf(bi), 1);
    active.splice(active.indexOf(bj), 1);
    active.push(u);
  }
  return relink(nodes[active[0]]);
}

function makeLeafOnly(names) {
  const root = makeNode();
  root.children = [makeNode(names[0], 0)];
  return relink(root);
}

/** Dispatch by method name. */
export function buildTree(method, names, matrix) {
  switch (String(method).toUpperCase()) {
    case 'UPGMA': return upgma(names, matrix);
    case 'BIONJ': return bionj(names, matrix);
    case 'NJ':
    default: return neighborJoining(names, matrix);
  }
}
