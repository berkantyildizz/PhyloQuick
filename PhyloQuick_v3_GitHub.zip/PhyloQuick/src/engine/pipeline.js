/**
 * The analysis pipeline.
 *
 * One entry point, `runAnalysis`, drives every stage in a fixed order and
 * records what it did in a run manifest. The manifest is the reproducibility
 * contract: it carries the software version, the SHA-256 of the input, every
 * parameter actually used (including defaults the user never touched), the
 * random seed, and per-stage timings. Re-running with the same manifest on the
 * same input reproduces the same numbers on any platform, because every
 * stochastic step draws from the seeded generator in rng.js.
 *
 * The same function backs the desktop interface, the Web Worker and the CLI,
 * so all three necessarily agree.
 */

import { sha256 } from './hash.js';
import { RNG } from './rng.js';
import {
  parseFasta, qualityControl, toAlignment, isAligned, trimAlignment,
  variableSites, parsimonyInformativeSites, baseFrequencies, compressPatterns,
  consensus, columnGapFraction,
} from './seq.js';
import { align } from './align.js';
import { distanceMatrix } from './distance.js';
import { buildTree } from './cluster.js';
import { SubstitutionModel } from './models.js';
import { selectModel } from './modelselect.js';
import { maximumLikelihoodTree, LikelihoodEngine } from './likelihood.js';
import { bootstrap, consensusTree } from './support.js';
import { populationStatistics } from './popgen.js';
import { buildNetwork } from './network.js';
import { writeNewick, midpointRoot, outgroupRoot, cloneTree, relink, leafNames } from './tree.js';

export const VERSION = '3.0.0';

export const DEFAULTS = {
  // Input handling
  minResolvedLength: 1,
  maxAmbiguousFraction: 1.0,
  forceRealign: false,
  // 'auto' shortens FASTA headers to their first whitespace-delimited token
  // (typically the accession) when that keeps every name unique; 'full' keeps
  // the header verbatim; 'accession' always truncates.
  taxonNaming: 'auto',

  // Alignment
  alignment: { match: 5, mismatch: -4, transitionBonus: 1, gapOpen: -12, gapExtend: -1, kmer: 4, refineRounds: 2 },

  // Trimming
  gapThreshold: 1.0,
  trimFrom: 1,
  trimTo: null,

  // Model
  runModelSelection: true,
  modelSelectionCriterion: 'BIC',
  substitutionModel: 'TN93',
  gammaCategories: 4,
  gammaAlpha: null,      // null = estimate
  proportionInvariable: null,

  // Distances
  distanceModel: 'TN93',
  completeDeletion: false,

  // Tree
  treeMethod: 'NJ',      // NJ | BIONJ | UPGMA | ML
  mlSearch: true,

  // Support
  // 'auto' resolves to SH-aLRT for ML trees and to the bootstrap for distance
  // trees. A full ML bootstrap re-searches the topology on every replicate and
  // costs roughly (replicates x one ML search); SH-aLRT costs about two extra
  // likelihood evaluations per branch, so it is the sensible default there.
  support: 'auto',       // auto | bootstrap | shalrt | both | none
  bootstrapReplicates: 500,
  shalrtReplicates: 1000,
  seed: 42,

  // Rooting
  rooting: 'midpoint',   // midpoint | outgroup | none
  outgroup: [],

  // Downstream
  networkType: 'MJ',
  networkEpsilon: 0,
  parsimonyLimit: null,
  groupSeparator: '_',
};

/**
 * Run the full analysis.
 *
 * @param {string} fastaText  raw FASTA
 * @param {object} userOptions overrides of DEFAULTS
 * @param {function} onProgress (fraction, stage, detail) => void
 */
export async function runAnalysis(fastaText, userOptions = {}, onProgress = null) {
  const options = mergeOptions(DEFAULTS, userOptions);
  const timings = {};
  const warnings = [];
  const started = new Date();
  const rng = new RNG(options.seed);
  const progress = makeProgress(onProgress);

  const inputHash = sha256(fastaText);

  // ---- 1. Parse and quality control -------------------------------------
  progress(0.02, 'input', 'Parsing FASTA');
  let t = now();
  const records = parseFasta(fastaText);
  if (!records.length) throw new Error('No FASTA records found. Sequences must start with ">".');
  const qc = qualityControl(records, {
    minLength: options.minResolvedLength,
    maxAmbiguous: options.maxAmbiguousFraction,
  });
  if (qc.records.length < 3) {
    throw new Error(`Only ${qc.records.length} usable sequence(s) after quality control; at least 3 are needed to build a tree.`);
  }
  warnings.push(...qc.log);

  const naming = shortenNames(qc.records.map((r) => r.name), options.taxonNaming);
  qc.records.forEach((r, i) => { r.originalName = r.name; r.name = naming.names[i]; });
  if (naming.note) warnings.push(naming.note);
  timings.qualityControl = now() - t;

  // ---- 2. Alignment ------------------------------------------------------
  const alreadyAligned = isAligned(qc.records);
  let alignment;
  let alignmentInfo;
  t = now();
  if (alreadyAligned && !options.forceRealign) {
    alignment = toAlignment(qc.records);
    alignmentInfo = { performed: false, reason: 'input sequences were already of equal length' };
    progress(0.10, 'alignment', 'Input already aligned');
  } else {
    progress(0.05, 'alignment', 'Progressive alignment');
    const result = align(
      qc.records.map((r) => r.name),
      qc.records.map((r) => r.seq),
      options.alignment,
      (f, msg) => progress(0.05 + 0.15 * f, 'alignment', msg),
    );
    alignment = { names: result.names, seqs: result.seqs, length: result.length };
    alignmentInfo = {
      performed: true,
      spScore: result.spScore,
      refinementsAccepted: result.refinements,
      options: result.options,
    };
  }
  timings.alignment = now() - t;

  // ---- 3. Trimming -------------------------------------------------------
  t = now();
  const trimmed = (options.gapThreshold < 1 || options.trimFrom > 1 || options.trimTo)
    ? trimAlignment(alignment, {
      gapThreshold: options.gapThreshold,
      from: options.trimFrom,
      to: options.trimTo,
    })
    : { ...alignment, originalColumns: null, removedCount: 0 };
  if (trimmed.length < 10) {
    throw new Error(`Trimming left only ${trimmed.length} column(s). Relax the gap threshold or the coordinate range.`);
  }
  timings.trimming = now() - t;

  // ---- 4. Alignment summary ---------------------------------------------
  t = now();
  const variable = variableSites(trimmed);
  const informative = parsimonyInformativeSites(trimmed);
  const freqs = baseFrequencies(trimmed);
  const patterns = compressPatterns(trimmed);
  const gapFraction = columnGapFraction(trimmed);
  const summary = {
    sequences: trimmed.names.length,
    alignedLength: trimmed.length,
    variableSites: variable.length,
    parsimonyInformativeSites: informative.length,
    distinctPatterns: patterns.nPatterns,
    baseFrequencies: freqs,
    meanGapFraction: mean(gapFraction),
    consensus: consensus(trimmed, 1.0),
    variablePositions: variable.map((c) => c + 1),
  };
  timings.summary = now() - t;

  // ---- 5. Starting tree from distances -----------------------------------
  progress(0.24, 'distance', 'Computing pairwise distances');
  t = now();
  const startDistances = distanceMatrix(trimmed, {
    model: 'TN93', freqs, completeDeletion: options.completeDeletion,
  });
  if (startDistances.undefinedPairs) {
    warnings.push(`${startDistances.undefinedPairs} sequence pair(s) exceeded the range in which the TN93 correction is defined; a saturated placeholder distance was used for the starting tree.`);
  }
  const startTree = buildTree('NJ', startDistances.names, startDistances.matrix);
  timings.startingTree = now() - t;

  // ---- 6. Model selection -------------------------------------------------
  let modelSelection = null;
  let model;
  t = now();
  if (options.runModelSelection) {
    progress(0.28, 'models', 'Model selection');
    modelSelection = selectModel(patterns, startTree, {
      freqs,
      nCat: options.gammaCategories,
      onProgress: (f, label) => progress(0.28 + 0.22 * f, 'models', `Fitting ${label}`),
    });
    const criterion = options.modelSelectionCriterion;
    const chosen = modelSelection.results.reduce((best, r) => (r[criterion] < best[criterion] ? r : best));
    model = chosen.model;
    modelSelection.chosen = chosen.label;
    modelSelection.criterionUsed = criterion;
  } else {
    model = new SubstitutionModel({
      model: options.substitutionModel,
      freqs,
      alpha: options.gammaAlpha ?? Infinity,
      pinv: options.proportionInvariable ?? 0,
      nCat: options.gammaCategories,
    });
    // Fit the free parameters of the user's model on the starting tree.
    const engine = new LikelihoodEngine(patterns, model).setTree(relink(cloneTree(startTree)));
    const fit = engine.optimiseModel({ rounds: 4 });
    model = fit.model;
  }
  warnings.push(...boundaryWarnings(model));
  timings.modelSelection = now() - t;

  // ---- 7. Final distance matrix under the chosen model --------------------
  t = now();
  const distances = distanceMatrix(trimmed, {
    model: options.distanceModel === 'ML' ? 'ML' : options.distanceModel,
    substitutionModel: model,
    freqs,
    alpha: model.usesGamma ? model.alpha : Infinity,
    completeDeletion: options.completeDeletion,
  });
  timings.distances = now() - t;

  // ---- 8. Tree inference ---------------------------------------------------
  progress(0.54, 'tree', `Building ${options.treeMethod} tree`);
  t = now();
  let tree;
  let mlInfo = null;
  if (options.treeMethod === 'ML') {
    const result = maximumLikelihoodTree(patterns, model, startTree, {
      search: options.mlSearch,
      optimiseModelParams: true,
      onProgress: (f, msg) => progress(0.54 + 0.16 * f, 'tree', msg),
    });
    tree = result.tree;
    model = result.model;
    mlInfo = {
      lnL: result.lnL,
      nniSweeps: result.sweeps,
      nniMovesApplied: result.moves,
      likelihoodEvaluations: result.evaluations,
      model: result.model.describe(),
    };
  } else {
    tree = buildTree(options.treeMethod, distances.names, distances.matrix);
  }
  timings.treeInference = now() - t;

  // ---- 9. Branch support ----------------------------------------------------
  t = now();
  let supportInfo = null;
  const resolvedSupport = options.support === 'auto'
    ? (options.treeMethod === 'ML' ? 'shalrt' : 'bootstrap')
    : options.support;
  const wantsBootstrap = resolvedSupport === 'bootstrap' || resolvedSupport === 'both';
  const wantsShalrt = (resolvedSupport === 'shalrt' || resolvedSupport === 'both') && options.treeMethod === 'ML';
  if ((options.support === 'shalrt' || options.support === 'both') && options.treeMethod !== 'ML') {
    warnings.push('SH-aLRT is defined only for likelihood trees; it was skipped because the tree method is not ML.');
  }

  if (wantsBootstrap && options.bootstrapReplicates > 0) {
    progress(0.72, 'support', `Bootstrap (${options.bootstrapReplicates} replicates)`);
    const rebuild = options.treeMethod === 'ML'
      ? (names, seqs) => {
        const rep = compressPatterns({ names, seqs, length: seqs[0].length });
        const repStart = buildTree('NJ', names, distanceMatrix({ names, seqs }, { model: 'TN93', freqs }).matrix);
        return maximumLikelihoodTree(rep, model, repStart, { search: true, optimiseModelParams: false }).tree;
      }
      : (names, seqs) => buildTree(
        options.treeMethod,
        names,
        distanceMatrix({ names, seqs, length: seqs[0].length }, {
          model: options.distanceModel === 'ML' ? 'ML' : options.distanceModel,
          substitutionModel: model,
          freqs,
          alpha: model.usesGamma ? model.alpha : Infinity,
          completeDeletion: options.completeDeletion,
        }).matrix,
      );

    const boot = bootstrap(trimmed, tree, rebuild, {
      replicates: options.bootstrapReplicates,
      seed: options.seed,
      onProgress: (f) => progress(0.72 + 0.16 * f, 'support', 'Bootstrap'),
    });
    supportInfo = {
      method: 'nonparametric bootstrap',
      replicates: boot.replicates,
      effectiveReplicates: boot.effectiveReplicates,
      seed: boot.seed,
      meanSupport: boot.meanSupport,
      failedReplicates: boot.failed,
    };
    if (boot.failed) warnings.push(`${boot.failed} bootstrap replicate(s) failed and were excluded.`);
    supportInfo.consensusNewick = writeNewick(
      consensusTree(boot.splitFrequencies, boot.taxonOrder, boot.effectiveReplicates, 0.5),
      { lengths: false },
    );
  }

  if (wantsShalrt) {
    progress(0.86, 'support', 'SH-aLRT');
    const engine = new LikelihoodEngine(patterns, model).setTree(tree);
    engine.optimiseBranchLengths({ rounds: 2 });
    engine.shALRT({ replicates: options.shalrtReplicates, rng: new RNG(options.seed + 1) });
    supportInfo = {
      ...(supportInfo || {}),
      method: supportInfo ? `${supportInfo.method} + SH-aLRT` : 'SH-aLRT',
      shalrt: { replicates: options.shalrtReplicates, seed: options.seed + 1 },
    };
  }
  timings.support = now() - t;

  // ---- 10. Rooting -----------------------------------------------------------
  t = now();
  let rootedTree = tree;
  let rootingInfo = { method: options.rooting };
  if (options.rooting === 'midpoint') {
    rootedTree = midpointRoot(tree);
  } else if (options.rooting === 'outgroup' && options.outgroup.length) {
    const rooted = outgroupRoot(tree, options.outgroup);
    if (rooted) rootedTree = rooted;
    else {
      warnings.push(`Outgroup {${options.outgroup.join(', ')}} is not monophyletic in the inferred tree; the tree was left unrooted.`);
      rootingInfo.method = 'none (outgroup not monophyletic)';
    }
  }
  timings.rooting = now() - t;

  // ---- 11. Population genetics and network ------------------------------------
  progress(0.92, 'popgen', 'Population statistics');
  t = now();
  const popgen = populationStatistics(trimmed.seqs, { completeDeletion: options.completeDeletion });
  warnings.push(...scopeWarnings(popgen));
  timings.populationGenetics = now() - t;

  t = now();
  // Node pie charts are only meaningful when the taxon labels actually encode a
  // grouping. If splitting on the separator gives every sequence its own group
  // (the usual case for bare accessions) the colouring would imply population
  // structure that is not in the data, so grouping is switched off instead.
  const rawGroups = trimmed.names.map((name) => String(name).split(options.groupSeparator)[0]);
  const distinctGroups = new Set(rawGroups).size;
  const useGroups = distinctGroups > 1 && distinctGroups < trimmed.names.length;
  const groupOf = useGroups ? (name) => String(name).split(options.groupSeparator)[0] : null;
  const network = buildNetwork(trimmed.names, trimmed.seqs, {
    type: options.networkType,
    epsilon: options.networkEpsilon,
    limit: options.parsimonyLimit,
    groupOf,
  });
  timings.network = now() - t;

  // ---- 12. Manifest -------------------------------------------------------------
  const finished = new Date();
  if (supportInfo) supportInfo.resolvedMode = resolvedSupport;
  const manifest = {
    software: { name: 'PhyloQuick', version: VERSION },
    run: {
      startedAt: started.toISOString(),
      finishedAt: finished.toISOString(),
      elapsedMs: finished - started,
      randomSeed: options.seed,
      generator: 'xoshiro128** seeded via splitmix32',
    },
    input: {
      sha256: inputHash,
      bytes: fastaText.length,
      recordsRead: records.length,
      recordsRemoved: qc.removed,
      charactersMasked: qc.maskedChars,
      taxonNaming: naming.mode,
    },
    alignment: alignmentInfo,
    trimming: {
      gapThreshold: options.gapThreshold,
      range: [options.trimFrom, options.trimTo],
      columnsRemoved: trimmed.removedCount,
      finalLength: trimmed.length,
    },
    model: {
      selectionPerformed: options.runModelSelection,
      criterion: options.runModelSelection ? options.modelSelectionCriterion : null,
      chosen: model.describe(),
    },
    distances: {
      model: distances.model,
      completeDeletion: options.completeDeletion,
      undefinedPairs: distances.undefinedPairs,
    },
    tree: {
      method: options.treeMethod,
      mlSearch: options.treeMethod === 'ML' ? options.mlSearch : null,
      ...(mlInfo || {}),
    },
    support: supportInfo,
    rooting: rootingInfo,
    network: { type: network.type, ...network.meta, groupingUsed: useGroups, groups: useGroups ? distinctGroups : null },
    timings,
    warnings,
    environment: describeEnvironment(),
  };
  manifest.parametersSha256 = sha256(JSON.stringify(sortedClone(options)));

  progress(1, 'done', 'Complete');
  void rng;

  return {
    options,
    manifest,
    warnings,
    qc,
    alignment: trimmed,
    rawAlignment: alignment,
    summary,
    patterns,
    modelSelection,
    model,
    distances,
    tree,
    rootedTree,
    newick: writeNewick(rootedTree, { support: true }),
    unrootedNewick: writeNewick(tree, { support: true }),
    taxa: leafNames(tree),
    taxonNames: naming,
    support: supportInfo,
    popgen,
    network,
    mlInfo,
  };
}

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function mergeOptions(defaults, overrides) {
  const out = { ...defaults };
  for (const [key, value] of Object.entries(overrides || {})) {
    if (value === undefined) continue;
    if (value && typeof value === 'object' && !Array.isArray(value) && defaults[key] && typeof defaults[key] === 'object') {
      out[key] = { ...defaults[key], ...value };
    } else {
      out[key] = value;
    }
  }
  return out;
}

function sortedClone(obj) {
  if (Array.isArray(obj)) return obj.map(sortedClone);
  if (obj && typeof obj === 'object') {
    const out = {};
    for (const key of Object.keys(obj).sort()) out[key] = sortedClone(obj[key]);
    return out;
  }
  return obj;
}

function makeProgress(cb) {
  let last = 0;
  return (fraction, stage, detail) => {
    if (!cb) return;
    const f = Math.max(last, Math.min(1, fraction));
    last = f;
    cb(f, stage, detail);
  };
}

/**
 * FASTA headers are usually "ACCESSION Genus species description...". Keeping
 * the whole header makes Newick output unreadable and forces quoting, so the
 * first token is used whenever that leaves every taxon uniquely identified.
 */
function shortenNames(names, mode) {
  const first = names.map((n) => String(n).split(/\s+/)[0]);
  const unique = new Set(first).size === first.length;
  if (mode === 'full' || (mode === 'auto' && !unique)) {
    return {
      mode: 'full',
      names: names.slice(),
      map: Object.fromEntries(names.map((n) => [n, n])),
      note: mode === 'auto' && !unique
        ? 'Accession-only labels would not have been unique, so full FASTA headers were kept as taxon names.'
        : null,
    };
  }
  if (!unique) {
    // 'accession' was requested explicitly: disambiguate with a suffix.
    const seen = new Map();
    const out = first.map((f) => {
      const k = (seen.get(f) || 0) + 1;
      seen.set(f, k);
      return k === 1 ? f : `${f}_${k}`;
    });
    return {
      mode: 'accession',
      names: out,
      map: Object.fromEntries(names.map((n, i) => [n, out[i]])),
      note: 'Some accession-only labels were duplicated and were given numeric suffixes.',
    };
  }
  return {
    mode: 'accession',
    names: first,
    map: Object.fromEntries(names.map((n, i) => [n, first[i]])),
    note: null,
  };
}

/**
 * Warn when an estimate sits on the edge of its allowed range. A boundary
 * estimate means the data do not identify that parameter, and reporting the
 * bound as if it were an estimate would be misleading.
 */
function boundaryWarnings(model) {
  const out = [];
  const spec = model.describe();
  const near = (x, bound, tol = 0.02) => Math.abs(x - bound) / Math.max(Math.abs(bound), 1e-9) < tol;
  if (spec.kappa != null && near(spec.kappa, 100)) {
    out.push(`Transition/transversion ratio reached its upper bound (kappa ~ ${spec.kappa}); the data contain too few transversions to identify it. Treat the value as "very large", not as a point estimate.`);
  }
  if (spec.pinv != null && spec.pinv > 0.9) {
    out.push(`The estimated proportion of invariable sites is very high (${spec.pinv}). This is expected for a low-divergence intraspecific alignment, but it leaves little information for the substitution model.`);
  }
  if (spec.alpha != null && spec.alpha < 0.05) {
    out.push(`The gamma shape parameter is very small (alpha = ${spec.alpha}), indicating extreme rate heterogeneity; +I and +G are then difficult to distinguish.`);
  }
  return out;
}

/**
 * Warn when intraspecific summary statistics are being applied to data that do
 * not look intraspecific.
 *
 * Haplotype diversity, nucleotide diversity, Tajima's D, Fu's Fs and haplotype
 * networks are all defined for a sample from a single interbreeding population.
 * Applied across species they still produce numbers, but those numbers do not
 * mean what their names suggest. Divergence above a few per cent, combined with
 * every sequence being its own haplotype, is the signature of a between-species
 * sample, and PhyloQuick says so rather than letting the values be reported
 * as population parameters.
 */
function scopeWarnings(popgen) {
  const out = [];
  const everySequenceUnique = popgen.h === popgen.n && popgen.n >= 4;
  if (popgen.pi > 0.05) {
    out.push(
      `Nucleotide diversity is ${(popgen.pi * 100).toFixed(1)}% per site. Divergence of this magnitude is typical of a between-species comparison, not of a single population. `
      + 'The population-genetic statistics (Hd, pi, Tajima\'s D, Fu\'s Fs, R2) and the haplotype network assume a sample from one interbreeding population and should not be interpreted as population parameters here; the alignment, model selection and tree remain valid.',
    );
  } else if (popgen.pi > 0.02 && everySequenceUnique) {
    out.push(
      `Every sequence is a distinct haplotype and nucleotide diversity is ${(popgen.pi * 100).toFixed(1)}% per site. Check that the sample really comes from a single population before interpreting the neutrality tests.`,
    );
  }
  if (popgen.n < 10 && popgen.tajimaD != null) {
    out.push(`Neutrality tests were computed from only ${popgen.n} sequences; Tajima's D and Fu's Fs have very low power at this sample size.`);
  }
  return out;
}

function mean(values) {
  let s = 0;
  for (let i = 0; i < values.length; i++) s += values[i];
  return values.length ? s / values.length : 0;
}

function describeEnvironment() {
  const env = { runtime: 'unknown' };
  if (typeof process !== 'undefined' && process.versions) {
    env.runtime = process.versions.electron ? 'electron' : 'node';
    env.node = process.versions.node;
    if (process.versions.electron) env.electron = process.versions.electron;
    if (process.versions.v8) env.v8 = process.versions.v8;
    env.platform = process.platform;
    env.arch = process.arch;
  } else if (typeof navigator !== 'undefined') {
    env.runtime = 'browser';
    env.userAgent = navigator.userAgent;
  }
  return env;
}

function now() {
  return typeof performance !== 'undefined' ? performance.now() : Date.now();
}
