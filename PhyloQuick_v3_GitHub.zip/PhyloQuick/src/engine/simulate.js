/**
 * Sequence and tree simulation under a known model.
 *
 * Used for validation: the simulated tree is known, so a reconstructed tree
 * can be scored against it (Robinson-Foulds, split precision/recall) and the
 * estimated model parameters can be compared with the generating values.
 * All draws come from the seeded generator in rng.js.
 */

import { RNG } from './rng.js';
import { makeNode, relink, postorder, preorder, isLeaf, leafNames } from './tree.js';
import { SubstitutionModel } from './models.js';

/**
 * Random tree topology and branch lengths.
 *
 * @param {number} n  number of tips
 * @param {object} opts
 * @param {string} opts.shape      'yule' (pure birth, clock-like) or 'random'
 *                                 (uniform over labelled histories)
 * @param {number} opts.meanBranch mean branch length
 * @param {number} opts.rateVariation  coefficient of variation of the
 *   lineage-specific rate multiplier. 0 gives a strict clock; larger values
 *   produce the unequal rates that make long-branch attraction possible, which
 *   is exactly the regime a distance method should be tested in.
 * @param {RNG} opts.rng
 */
export function randomTree(n, opts = {}) {
  const rng = opts.rng || new RNG(opts.seed ?? 1);
  const shape = opts.shape || 'yule';
  const meanBranch = opts.meanBranch ?? 0.05;
  const rateVariation = opts.rateVariation ?? 0;

  const tips = Array.from({ length: n }, (_, i) => makeNode(`T${String(i + 1).padStart(3, '0')}`, 0));
  let active = tips.slice();

  if (shape === 'yule') {
    // Coalesce backwards in time; with k lineages the waiting time is
    // Exp(k(k-1)/2), which gives the standard Yule/coalescent-shaped tree.
    let height = 0;
    const nodeHeight = new Map(active.map((t) => [t, 0]));
    while (active.length > 1) {
      const k = active.length;
      height += rng.exponential((k * (k - 1)) / 2) * meanBranch * 2;
      const i = rng.int(k);
      let j = rng.int(k - 1);
      if (j >= i) j++;
      const a = active[i];
      const b = active[j];
      const parent = makeNode();
      a.length = height - nodeHeight.get(a);
      b.length = height - nodeHeight.get(b);
      parent.children = [a, b];
      nodeHeight.set(parent, height);
      active = active.filter((x) => x !== a && x !== b);
      active.push(parent);
    }
  } else {
    while (active.length > 1) {
      const i = rng.int(active.length);
      let j = rng.int(active.length - 1);
      if (j >= i) j++;
      const a = active[i];
      const b = active[j];
      a.length = rng.exponential(1 / meanBranch);
      b.length = rng.exponential(1 / meanBranch);
      const parent = makeNode();
      parent.children = [a, b];
      active = active.filter((x) => x !== a && x !== b);
      active.push(parent);
    }
  }

  let root = active[0];
  // Make the root trifurcating so the tree is stored unrooted.
  if (root.children.length === 2) {
    const [a, b] = root.children;
    const target = !isLeaf(a) ? a : b;
    const other = target === a ? b : a;
    const merged = a.length + b.length;
    const newRoot = makeNode();
    newRoot.children = [...target.children, other];
    other.length = merged;
    root = newRoot;
  }
  relink(root);

  if (rateVariation > 0) {
    // Multiply each branch by an independent lognormal rate factor with the
    // requested coefficient of variation and mean 1.
    const sigma = Math.sqrt(Math.log(1 + rateVariation * rateVariation));
    const mu = -0.5 * sigma * sigma;
    for (const node of postorder(root)) {
      if (node.parent) node.length *= Math.exp(mu + sigma * rng.normal());
    }
  }

  return root;
}

/**
 * Simulate an alignment down a tree under a substitution model.
 *
 * The root sequence is drawn from the model's stationary distribution; each
 * site is assigned a rate category (including the invariable class) once, and
 * states are then propagated along every branch by drawing from the exact
 * transition matrix P(t * rate).
 *
 * @returns {{names, seqs, length, rateCategories, tree, model}}
 */
export function simulateAlignment(tree, model, nSites, opts = {}) {
  const rng = opts.rng || new RNG(opts.seed ?? 1);
  const pi = model.freqs;
  const rates = model.rates;
  const catProbs = model.catProbs;
  const pinv = model.invProb;

  // Category assignment: index -1 marks an invariable site.
  const siteCat = new Int32Array(nSites);
  const weights = [pinv, ...catProbs];
  for (let s = 0; s < nSites; s++) siteCat[s] = rng.categorical(weights) - 1;

  const nodes = preorder(tree);
  const state = new Map();
  const rootStates = new Uint8Array(nSites);
  for (let s = 0; s < nSites; s++) rootStates[s] = rng.categorical(pi);
  state.set(tree, rootStates);

  for (const node of nodes) {
    if (node === tree) continue;
    const parentStates = state.get(node.parent);
    const out = new Uint8Array(nSites);
    const len = Math.max(node.length, 0);
    // Cache one transition matrix per rate category for this branch.
    const Ps = rates.map((r) => model.P(len * r));
    for (let s = 0; s < nSites; s++) {
      const cat = siteCat[s];
      if (cat < 0) { out[s] = parentStates[s]; continue; }
      const from = parentStates[s];
      const row = Ps[cat];
      out[s] = rng.categorical([row[from * 4], row[from * 4 + 1], row[from * 4 + 2], row[from * 4 + 3]]);
    }
    state.set(node, out);
  }

  const letters = 'ACGT';
  const tips = postorder(tree).filter(isLeaf);
  const names = tips.map((t) => t.name);
  const seqs = tips.map((t) => {
    const st = state.get(t);
    let out = '';
    for (let s = 0; s < nSites; s++) out += letters[st[s]];
    return out;
  });

  return { names, seqs, length: nSites, rateCategories: siteCat, tree, model };
}

/**
 * Add indels to a simulated alignment so that an *unaligned* dataset can be
 * produced. Used to test the aligner: the true alignment is known, so the
 * recovered one can be scored with sum-of-pairs and total-column accuracy.
 *
 * Returns the gapped true alignment and the corresponding unaligned sequences.
 */
export function addIndels(aln, opts = {}) {
  const rng = opts.rng || new RNG(opts.seed ?? 7);
  const rate = opts.rate ?? 0.02;          // indel events per sequence per 100 sites
  const meanLength = opts.meanLength ?? 3;

  const rows = aln.seqs.map((s) => s.split(''));
  const nSites = aln.length;
  const deletions = rows.map(() => new Uint8Array(nSites));

  for (let r = 0; r < rows.length; r++) {
    const events = Math.round((rate * nSites) / 100);
    for (let e = 0; e < events; e++) {
      const start = rng.int(nSites);
      const len = 1 + Math.floor(rng.exponential(1 / meanLength));
      for (let i = start; i < Math.min(nSites, start + len); i++) deletions[r][i] = 1;
    }
  }

  const trueRows = rows.map((row, r) => row.map((ch, i) => (deletions[r][i] ? '-' : ch)).join(''));
  // Drop columns that became all-gap.
  const keep = [];
  for (let c = 0; c < nSites; c++) {
    if (trueRows.some((row) => row[c] !== '-')) keep.push(c);
  }
  const gapped = trueRows.map((row) => { let o = ''; for (const c of keep) o += row[c]; return o; });
  const unaligned = gapped.map((row) => row.replace(/-/g, ''));

  return {
    trueAlignment: { names: aln.names.slice(), seqs: gapped, length: keep.length },
    unaligned: { names: aln.names.slice(), seqs: unaligned },
  };
}

/**
 * Sum-of-pairs and total-column scores of an estimated alignment against a
 * known true alignment (Thompson et al. 1999).
 *
 * SP  = fraction of residue pairs aligned in the reference that are also
 *       aligned in the estimate.
 * TC  = fraction of reference columns reproduced exactly.
 */
export function alignmentAccuracy(trueAln, estAln) {
  const nameToRow = new Map(estAln.names.map((n, i) => [n, i]));
  const order = trueAln.names.map((n) => nameToRow.get(n));
  if (order.some((i) => i === undefined)) throw new Error('alignments contain different sequences');

  const truePos = residuePositions(trueAln.seqs);
  const estPos = residuePositions(order.map((i) => estAln.seqs[i]));

  // Map (row, residueIndex) -> column, for both alignments.
  const n = trueAln.names.length;
  let pairsTotal = 0;
  let pairsCorrect = 0;
  for (let a = 0; a < n; a++) {
    for (let b = a + 1; b < n; b++) {
      const colOfA = truePos.colOf[a];
      const colOfB = truePos.colOf[b];
      const resAtColA = truePos.resOf[a];
      const resAtColB = truePos.resOf[b];
      for (let c = 0; c < trueAln.length; c++) {
        const ra = resAtColA[c];
        const rb = resAtColB[c];
        if (ra < 0 || rb < 0) continue;
        pairsTotal++;
        if (estPos.colOf[a][ra] === estPos.colOf[b][rb]) pairsCorrect++;
      }
      void colOfA; void colOfB;
    }
  }

  let columnsCorrect = 0;
  for (let c = 0; c < trueAln.length; c++) {
    const signature = [];
    let ok = true;
    for (let r = 0; r < n; r++) {
      const res = truePos.resOf[r][c];
      signature.push(res < 0 ? -1 : estPos.colOf[r][res]);
    }
    const nonGap = signature.filter((x) => x >= 0);
    if (!nonGap.length) continue;
    const first = nonGap[0];
    for (const s of nonGap) if (s !== first) { ok = false; break; }
    if (ok) columnsCorrect++;
  }

  return {
    spScore: pairsTotal ? pairsCorrect / pairsTotal : 0,
    tcScore: trueAln.length ? columnsCorrect / trueAln.length : 0,
    pairsCompared: pairsTotal,
    columnsCompared: trueAln.length,
  };
}

function residuePositions(seqs) {
  const colOf = [];   // residue index -> column
  const resOf = [];   // column -> residue index (or -1)
  for (const s of seqs) {
    const c2r = new Int32Array(s.length).fill(-1);
    const r2c = [];
    let r = 0;
    for (let c = 0; c < s.length; c++) {
      if (s[c] !== '-') { c2r[c] = r; r2c.push(c); r++; }
    }
    colOf.push(Int32Array.from(r2c));
    resOf.push(c2r);
  }
  return { colOf, resOf };
}

/** Convenience: a model with randomly drawn but reportable parameters. */
export function randomModel(name, rng, { gamma = true, invariable = false } = {}) {
  const raw = [rng.gamma(2, 0.5) + 0.2, rng.gamma(2, 0.5) + 0.2, rng.gamma(2, 0.5) + 0.2, rng.gamma(2, 0.5) + 0.2];
  const sum = raw.reduce((a, b) => a + b, 0);
  return new SubstitutionModel({
    model: name,
    freqs: raw.map((x) => x / sum),
    kappa: 1 + rng.gamma(2, 1.5),
    kappa2: 1 + rng.gamma(2, 1.5),
    gtrRates: [0.5 + rng.gamma(2, 1), 1 + rng.gamma(2, 1.5), 0.4 + rng.gamma(2, 0.6), 0.4 + rng.gamma(2, 0.6), 1 + rng.gamma(2, 1.5)],
    alpha: gamma ? 0.2 + rng.gamma(2, 0.4) : Infinity,
    pinv: invariable ? 0.1 + rng.next() * 0.3 : 0,
    nCat: 4,
  });
}

export { leafNames };
