/**
 * Pairwise evolutionary distances.
 *
 * Two families are provided:
 *
 *  - Closed-form corrections (p, JC69, K80, TN93), optionally with a gamma
 *    correction. These are fast and are what MEGA reports by default.
 *  - Maximum-likelihood distances, obtained by numerically maximising the
 *    two-sequence likelihood under any model in models.js, including GTR+I+G.
 *    This is the only way to obtain distances under models that have no
 *    analytical inverse, and it is what makes the distance matrix consistent
 *    with the model chosen by model selection.
 *
 * Missing data handling is pairwise deletion by default (a site is used for a
 * pair whenever both sequences have a resolved nucleotide there); complete
 * deletion is available and is reported in the manifest, because the choice
 * materially changes distances on gappy alignments.
 */

import { brentMax } from './optimise.js';
import { SubstitutionModel } from './models.js';

const CODE = { A: 0, C: 1, G: 2, T: 3 };

export const DISTANCE_MODELS = ['p-distance', 'JC69', 'K80', 'TN93', 'ML'];

/**
 * Counts needed by the closed-form corrections.
 * P1 = purine transitions (A<->G), P2 = pyrimidine transitions (C<->T),
 * Q = transversions, n = compared sites.
 */
export function pairCounts(a, b) {
  let P1 = 0; let P2 = 0; let Q = 0; let n = 0;
  const counts = [0, 0, 0, 0];
  const len = Math.min(a.length, b.length);
  for (let i = 0; i < len; i++) {
    const x = CODE[a[i]];
    const y = CODE[b[i]];
    if (x === undefined || y === undefined) continue;
    n++;
    counts[x]++; counts[y]++;
    if (x === y) continue;
    const purine = (x === 0 || x === 2) && (y === 0 || y === 2);
    const pyrimidine = (x === 1 || x === 3) && (y === 1 || y === 3);
    if (purine) P1++;
    else if (pyrimidine) P2++;
    else Q++;
  }
  const total = 2 * n || 1;
  return { P1, P2, Q, n, freqs: counts.map((c) => c / total) };
}

/** Uncorrected proportion of differing sites. */
export function pDistance(a, b) {
  const { P1, P2, Q, n } = pairCounts(a, b);
  return n ? (P1 + P2 + Q) / n : 0;
}

/**
 * Jukes–Cantor. With `alpha` finite, the gamma-corrected form
 * d = (3/4) a [(1 - 4p/3)^(-1/a) - 1] is used instead.
 */
export function jc69Distance(a, b, alpha = Infinity) {
  const p = pDistance(a, b);
  if (p >= 0.75) return NaN;
  if (Number.isFinite(alpha) && alpha > 0) {
    return 0.75 * alpha * (Math.pow(1 - (4 / 3) * p, -1 / alpha) - 1);
  }
  return -0.75 * Math.log(1 - (4 / 3) * p);
}

/** Kimura two-parameter, with the optional gamma correction of Jin & Nei (1990). */
export function k80Distance(a, b, alpha = Infinity) {
  const { P1, P2, Q, n } = pairCounts(a, b);
  if (!n) return 0;
  const P = (P1 + P2) / n;
  const Qf = Q / n;
  const w1 = 1 - 2 * P - Qf;
  const w2 = 1 - 2 * Qf;
  if (w1 <= 0 || w2 <= 0) return NaN;
  if (Number.isFinite(alpha) && alpha > 0) {
    return (alpha / 2) * (Math.pow(w1, -1 / alpha) + 0.5 * Math.pow(w2, -1 / alpha) - 1.5);
  }
  return -0.5 * Math.log(w1) - 0.25 * Math.log(w2);
}

/**
 * Tamura–Nei (1993). Separate rates for purine and pyrimidine transitions and
 * unequal base frequencies; this is the most general model with a closed-form
 * distance and is the default analytic correction in PhyloQuick.
 */
export function tn93Distance(a, b, freqs, alpha = Infinity) {
  const { P1, P2, Q, n } = pairCounts(a, b);
  if (!n) return 0;
  const [gA, gC, gG, gT] = freqs;
  const gR = gA + gG;
  const gY = gC + gT;
  if (gR <= 0 || gY <= 0) return NaN;
  const p1 = P1 / n;
  const p2 = P2 / n;
  const q = Q / n;

  const k1 = 1 - (gR * p1) / (2 * gA * gG) - q / (2 * gR);
  const k2 = 1 - (gY * p2) / (2 * gC * gT) - q / (2 * gY);
  const k3 = 1 - q / (2 * gR * gY);
  if (k1 <= 0 || k2 <= 0 || k3 <= 0) return NaN;

  const c1 = (2 * gA * gG) / gR;
  const c2 = (2 * gC * gT) / gY;
  const c3 = 2 * (gR * gY - (gA * gG * gY) / gR - (gC * gT * gR) / gY);

  if (Number.isFinite(alpha) && alpha > 0) {
    return alpha * (c1 * (Math.pow(k1, -1 / alpha) - 1)
      + c2 * (Math.pow(k2, -1 / alpha) - 1)
      + c3 * (Math.pow(k3, -1 / alpha) - 1));
  }
  return -c1 * Math.log(k1) - c2 * Math.log(k2) - c3 * Math.log(k3);
}

/**
 * Maximum-likelihood distance between two sequences under an arbitrary model.
 *
 * Maximises  sum_sites log[ sum_cat p_cat sum_i pi_i P_ij(t r_cat) ]  over t,
 * which is the exact two-taxon likelihood; the invariable class is handled the
 * same way as in the full tree likelihood.
 */
export function mlDistance(a, b, model) {
  const len = Math.min(a.length, b.length);
  // Compress to the 4x4 table of observed pairs plus the count of comparable sites.
  const table = new Float64Array(16);
  let n = 0;
  for (let i = 0; i < len; i++) {
    const x = CODE[a[i]];
    const y = CODE[b[i]];
    if (x === undefined || y === undefined) continue;
    table[x * 4 + y] += 1;
    n++;
  }
  if (!n) return 0;

  const pi = model.freqs;
  const rates = model.rates;
  const catProbs = model.catProbs;
  const pinv = model.invProb;

  const objective = (t) => {
    let total = 0;
    const Ps = rates.map((r) => model.P(Math.max(t, 1e-9) * r));
    for (let x = 0; x < 4; x++) {
      for (let y = 0; y < 4; y++) {
        const count = table[x * 4 + y];
        if (!count) continue;
        let lik = 0;
        for (let r = 0; r < rates.length; r++) lik += catProbs[r] * pi[x] * Ps[r][x * 4 + y];
        if (pinv > 0 && x === y) lik += pinv * pi[x];
        total += count * Math.log(Math.max(lik, 1e-300));
      }
    }
    return total;
  };

  // Optimised on a log scale for the same conditioning reason as tree branches.
  const r = brentMax((u) => objective(Math.exp(u)), Math.log(1e-8), Math.log(50), 1e-6, 60);
  return Math.exp(r.x);
}

/**
 * Full pairwise distance matrix.
 *
 * @param {object} aln  {names, seqs}
 * @param {object} opts
 * @param {string} opts.model  one of DISTANCE_MODELS, or a model name understood
 *                             by SubstitutionModel when opts.method === 'ML'
 * @param {number} opts.alpha  gamma shape for the analytic corrections
 * @param {SubstitutionModel} opts.substitutionModel  used when model === 'ML'
 * @param {boolean} opts.completeDeletion  drop every column with a gap or N
 */
export function distanceMatrix(aln, opts = {}) {
  const modelName = opts.model || 'TN93';
  const alpha = opts.alpha ?? Infinity;
  let seqs = aln.seqs;

  if (opts.completeDeletion) {
    const keep = [];
    for (let c = 0; c < seqs[0].length; c++) {
      let ok = true;
      for (let r = 0; r < seqs.length; r++) if (CODE[seqs[r][c]] === undefined) { ok = false; break; }
      if (ok) keep.push(c);
    }
    seqs = seqs.map((s) => { let o = ''; for (const c of keep) o += s[c]; return o; });
  }

  const n = seqs.length;
  const M = Array.from({ length: n }, () => new Float64Array(n));
  const freqs = opts.freqs || empiricalFreqs(seqs);
  const subModel = modelName === 'ML'
    ? (opts.substitutionModel || new SubstitutionModel({ model: 'TN93', freqs, alpha }))
    : null;

  let undefinedPairs = 0;
  let maxFinite = 0;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      let d;
      switch (modelName) {
        case 'p-distance': d = pDistance(seqs[i], seqs[j]); break;
        case 'JC69': d = jc69Distance(seqs[i], seqs[j], alpha); break;
        case 'K80': d = k80Distance(seqs[i], seqs[j], alpha); break;
        case 'ML': d = mlDistance(seqs[i], seqs[j], subModel); break;
        case 'TN93':
        default: d = tn93Distance(seqs[i], seqs[j], freqs, alpha); break;
      }
      if (!Number.isFinite(d) || d < 0) { undefinedPairs++; d = NaN; }
      else if (d > maxFinite) maxFinite = d;
      M[i][j] = d; M[j][i] = d;
    }
  }

  // Saturated pairs get a finite placeholder so tree building can proceed, and
  // the count is surfaced so the user is told the correction broke down.
  if (undefinedPairs) {
    const fill = Math.max(maxFinite * 1.5, 1);
    for (let i = 0; i < n; i++) {
      for (let j = 0; j < n; j++) if (Number.isNaN(M[i][j])) M[i][j] = fill;
    }
  }

  return { names: aln.names.slice(), matrix: M, model: modelName, alpha, freqs, undefinedPairs };
}

function empiricalFreqs(seqs) {
  const counts = [0, 0, 0, 0];
  let total = 0;
  for (const s of seqs) {
    for (let i = 0; i < s.length; i++) {
      const c = CODE[s[i]];
      if (c !== undefined) { counts[c]++; total++; }
    }
  }
  if (!total) return [0.25, 0.25, 0.25, 0.25];
  return counts.map((c) => Math.max(c / total, 1e-6));
}

/** PHYLIP square distance matrix, readable by MEGA, PHYLIP and R/ape. */
export function toPhylipMatrix(result, precision = 6) {
  const { names, matrix } = result;
  const lines = [String(names.length)];
  for (let i = 0; i < names.length; i++) {
    const label = names[i].replace(/[\s():;,]/g, '_').slice(0, 40).padEnd(12, ' ');
    lines.push(label + ' ' + Array.from(matrix[i]).map((v) => v.toFixed(precision)).join(' '));
  }
  return lines.join('\n') + '\n';
}

/** Tab-separated matrix with a header row, for spreadsheets. */
export function toTsvMatrix(result, precision = 6) {
  const { names, matrix } = result;
  const lines = ['\t' + names.join('\t')];
  for (let i = 0; i < names.length; i++) {
    lines.push(names[i] + '\t' + Array.from(matrix[i]).map((v) => v.toFixed(precision)).join('\t'));
  }
  return lines.join('\n') + '\n';
}
