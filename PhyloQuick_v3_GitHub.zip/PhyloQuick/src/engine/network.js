/**
 * Haplotype networks.
 *
 * Three constructions are offered, all operating on the reduced set of variable
 * sites so that the mutational distance between haplotypes is exact:
 *
 *   MSN — minimum spanning network: the union of all minimum spanning trees,
 *         so that equally short alternative connections are all shown rather
 *         than one being picked arbitrarily.
 *   MJ  — median-joining network (Bandelt, Forster & Röhl 1999): the MSN plus
 *         inferred median (latent) haplotypes, added iteratively until no new
 *         median improves the network.
 *   PARSIMONY — a statistical-parsimony network in the style of Templeton et al.
 *         (1992)/TCS: only connections at or below a maximum number of
 *         mutational steps are drawn.
 *
 * Scope note on the parsimony network: the connection limit is an explicit,
 * reported parameter. PhyloQuick does not claim to reproduce TCS's internal
 * derivation of the 95% limit; by default the limit is set from the
 * Watterson-style approximation documented in `parsimonyLimit` below, and the
 * value actually used is always written into the run manifest so that a reader
 * can reproduce or override it.
 */

/**
 * Collapse an alignment into haplotypes.
 * Sequences are compared on resolved nucleotides only; two sequences that
 * differ solely at positions where one of them has a gap or N are treated as
 * the same haplotype, which is the convention used by DnaSP and PopART.
 */
export function haplotypes(names, seqs, { groupOf = null } = {}) {
  const map = new Map();
  seqs.forEach((seq, i) => {
    const key = seq;
    if (!map.has(key)) map.set(key, []);
    map.get(key).push(i);
  });
  const list = [];
  let id = 1;
  for (const [seq, members] of map) {
    list.push({
      id: `H${id++}`,
      seq,
      members,
      names: members.map((i) => names[i]),
      count: members.length,
      groups: groupOf ? tally(members.map((i) => groupOf(names[i], i))) : null,
    });
  }
  list.sort((a, b) => b.count - a.count || a.id.localeCompare(b.id));
  list.forEach((h, i) => { h.id = `H${i + 1}`; });
  return list;
}

function tally(values) {
  const out = new Map();
  for (const v of values) out.set(v, (out.get(v) || 0) + 1);
  return out;
}

/** Reduce haplotype sequences to the columns that vary among them. */
export function variableSiteMatrix(haplotypeSeqs) {
  const len = haplotypeSeqs[0] ? haplotypeSeqs[0].length : 0;
  const positions = [];
  for (let c = 0; c < len; c++) {
    const seen = new Set();
    for (const s of haplotypeSeqs) {
      const ch = s[c];
      if (ch === 'A' || ch === 'C' || ch === 'G' || ch === 'T') seen.add(ch);
    }
    if (seen.size > 1) positions.push(c);
  }
  const rows = haplotypeSeqs.map((s) => positions.map((c) => s[c]));
  return { positions, rows };
}

/** Number of variable sites at which two reduced haplotypes differ. */
export function mutationalDistance(a, b) {
  let d = 0;
  for (let i = 0; i < a.length; i++) {
    const x = a[i]; const y = b[i];
    if (x === '-' || y === '-' || x === 'N' || y === 'N') continue;
    if (x !== y) d++;
  }
  return d;
}

function distanceMatrixOf(rows) {
  const n = rows.length;
  const D = Array.from({ length: n }, () => new Int32Array(n));
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const d = mutationalDistance(rows[i], rows[j]);
      D[i][j] = d; D[j][i] = d;
    }
  }
  return D;
}

// ---------------------------------------------------------------------------
// Minimum spanning network
// ---------------------------------------------------------------------------

/**
 * Union of all minimum spanning trees.
 *
 * Kruskal is run once to find the weight of the MST edge that closes each
 * "level"; every edge whose weight equals the level at which its two endpoints
 * would first be joined is then retained. The result contains every edge that
 * belongs to at least one MST, which is what makes an MSN more informative than
 * a single arbitrary MST.
 */
export function minimumSpanningNetwork(rows, { epsilon = 0 } = {}) {
  const n = rows.length;
  const D = distanceMatrixOf(rows);
  const edges = [];
  for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) edges.push([i, j, D[i][j]]);
  edges.sort((a, b) => a[2] - b[2]);

  const parent = [...Array(n).keys()];
  const find = (x) => (parent[x] === x ? x : (parent[x] = find(parent[x])));
  const union = (a, b) => { parent[find(a)] = find(b); };

  const kept = [];
  let k = 0;
  while (k < edges.length) {
    const w = edges[k][2];
    // Every edge of the current weight that joins two distinct components is
    // part of some MST; collect them all before performing the unions.
    const batch = [];
    let m = k;
    while (m < edges.length && edges[m][2] <= w + epsilon) {
      const [i, j] = edges[m];
      if (find(i) !== find(j)) batch.push(edges[m]);
      m++;
    }
    for (const e of batch) kept.push(e);
    for (const [i, j] of batch) union(i, j);
    k = m;
    if (kept.length && new Set([...Array(n).keys()].map(find)).size === 1 && epsilon === 0) {
      // Continue only to collect equal-weight alternatives already handled above.
      break;
    }
  }
  return kept.map(([i, j, w]) => ({ source: i, target: j, steps: w }));
}

// ---------------------------------------------------------------------------
// Median-joining network
// ---------------------------------------------------------------------------

/**
 * Median-joining network (Bandelt, Forster & Röhl 1999).
 *
 * Observed haplotypes are connected by an MSN; then, for every connected triple
 * of nodes, the median vector (the majority state at each variable site) is
 * computed and added as a latent node if it is new and reduces the total
 * network length. The process repeats until no further median is accepted or
 * the iteration or node budget is exhausted.
 *
 * @param {string[][]} rows  reduced haplotype vectors
 * @param {object} opts
 * @param {number} opts.epsilon  extra weight tolerated when building the MSN
 * @param {number} opts.maxIterations
 * @param {number} opts.maxMedians  hard cap on inferred nodes, to keep the
 *   interface responsive on diverse datasets
 */
export function medianJoiningNetwork(rows, opts = {}) {
  const epsilon = opts.epsilon ?? 0;
  const maxIterations = opts.maxIterations ?? 20;
  const maxMedians = opts.maxMedians ?? 200;

  let nodes = rows.map((r) => r.slice());
  const observedCount = nodes.length;
  let edges = minimumSpanningNetwork(nodes, { epsilon });
  let iterations = 0;

  for (; iterations < maxIterations; iterations++) {
    const adjacency = buildAdjacency(nodes.length, edges);
    const candidates = new Map();

    for (let a = 0; a < nodes.length; a++) {
      for (const b of adjacency[a]) {
        if (b <= a) continue;
        for (const c of adjacency[a]) {
          if (c <= b) continue;
          const median = medianVector(nodes[a], nodes[b], nodes[c]);
          if (!median) continue;
          const key = median.join('');
          if (nodes.some((nd) => nd.join('') === key)) continue;
          // Accept only if the median shortens the sum of the three connections.
          const before = mutationalDistance(nodes[a], nodes[b])
            + mutationalDistance(nodes[a], nodes[c])
            + mutationalDistance(nodes[b], nodes[c]);
          const after = mutationalDistance(median, nodes[a])
            + mutationalDistance(median, nodes[b])
            + mutationalDistance(median, nodes[c]);
          if (after < before) candidates.set(key, median);
        }
      }
    }

    if (!candidates.size) break;
    let added = 0;
    for (const median of candidates.values()) {
      if (nodes.length - observedCount >= maxMedians) break;
      nodes.push(median);
      added++;
    }
    if (!added) break;
    edges = minimumSpanningNetwork(nodes, { epsilon });
  }

  // Drop median vectors that ended up with degree < 3: they add nothing.
  const degree = new Int32Array(nodes.length);
  for (const e of edges) { degree[e.source]++; degree[e.target]++; }
  const keep = nodes.map((_, i) => i < observedCount || degree[i] >= 3);
  const remap = new Map();
  const finalNodes = [];
  nodes.forEach((nd, i) => {
    if (!keep[i]) return;
    remap.set(i, finalNodes.length);
    finalNodes.push(nd);
  });
  const finalEdges = edges
    .filter((e) => keep[e.source] && keep[e.target])
    .map((e) => ({ source: remap.get(e.source), target: remap.get(e.target), steps: e.steps }));

  return {
    nodes: finalNodes,
    edges: finalEdges,
    observedCount,
    medianCount: finalNodes.length - observedCount,
    iterations,
  };
}

function buildAdjacency(n, edges) {
  const adj = Array.from({ length: n }, () => []);
  for (const e of edges) { adj[e.source].push(e.target); adj[e.target].push(e.source); }
  return adj;
}

/** Majority state at each site; null when any site has three distinct states. */
function medianVector(a, b, c) {
  const out = new Array(a.length);
  for (let i = 0; i < a.length; i++) {
    const x = a[i]; const y = b[i]; const z = c[i];
    if (x === y || x === z) out[i] = x;
    else if (y === z) out[i] = y;
    else return null; // no unambiguous median for this triple
  }
  return out;
}

// ---------------------------------------------------------------------------
// Statistical parsimony
// ---------------------------------------------------------------------------

/**
 * Connection limit used by the parsimony network when none is supplied.
 *
 * This is a transparent approximation, not a reimplementation of the TCS
 * derivation: it returns the largest j for which the probability that j
 * observed differences reflect j single substitutions, approximated as
 *
 *     P(j) = prod_{i=1..j} (1 - (2i - 1) / (2 b))
 *
 * with b the number of compared sites, remains at or above `confidence`.
 * Under the coalescent assumptions of Templeton et al. (1992) this is
 * conservative. The value is always reported so that it can be overridden.
 */
export function parsimonyLimit(nSites, confidence = 0.95) {
  if (!nSites) return 1;
  let p = 1;
  let j = 0;
  for (;;) {
    const next = p * (1 - (2 * (j + 1) - 1) / (2 * nSites));
    if (next < confidence || j > nSites) break;
    p = next;
    j++;
  }
  return Math.max(1, j);
}

/**
 * Statistical-parsimony network: all connections at or below `limit` steps.
 * Haplotypes that cannot be joined within the limit fall into separate
 * subnetworks; an unconnected component suggests that the sample spans more
 * than one gene pool.
 */
export function parsimonyNetwork(rows, { limit = null, nSites = null, confidence = 0.95 } = {}) {
  const used = limit ?? parsimonyLimit(nSites ?? (rows[0] ? rows[0].length : 0), confidence);
  const n = rows.length;
  const D = distanceMatrixOf(rows);
  const edges = [];
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      if (D[i][j] <= used) edges.push({ source: i, target: j, steps: D[i][j] });
    }
  }
  // Components, so the caller can report how many subnetworks resulted.
  const parent = [...Array(n).keys()];
  const find = (x) => (parent[x] === x ? x : (parent[x] = find(parent[x])));
  for (const e of edges) parent[find(e.source)] = find(e.target);
  const components = new Set([...Array(n).keys()].map(find));

  return { edges, limit: used, components: components.size, confidence };
}

// ---------------------------------------------------------------------------
// Entry point
// ---------------------------------------------------------------------------

/**
 * Build a haplotype network of the requested type.
 * @returns {{type, nodes, edges, haplotypes, positions, meta}}
 */
export function buildNetwork(names, seqs, { type = 'MJ', epsilon = 0, limit = null, groupOf = null } = {}) {
  const haps = haplotypes(names, seqs, { groupOf });
  const { positions, rows } = variableSiteMatrix(haps.map((h) => h.seq));

  if (type === 'MJ') {
    const net = medianJoiningNetwork(rows, { epsilon });
    return {
      type: 'MJ',
      nodes: net.nodes.map((row, i) => ({
        index: i,
        inferred: i >= net.observedCount,
        haplotype: i < net.observedCount ? haps[i] : null,
        vector: row,
      })),
      edges: net.edges,
      haplotypes: haps,
      positions,
      meta: { medianCount: net.medianCount, iterations: net.iterations, epsilon },
    };
  }

  if (type === 'PARSIMONY') {
    const net = parsimonyNetwork(rows, { limit, nSites: seqs[0] ? seqs[0].length : 0 });
    return {
      type: 'PARSIMONY',
      nodes: haps.map((h, i) => ({ index: i, inferred: false, haplotype: h, vector: rows[i] })),
      edges: net.edges,
      haplotypes: haps,
      positions,
      meta: { connectionLimit: net.limit, components: net.components, confidence: net.confidence },
    };
  }

  const edges = minimumSpanningNetwork(rows, { epsilon });
  return {
    type: 'MSN',
    nodes: haps.map((h, i) => ({ index: i, inferred: false, haplotype: h, vector: rows[i] })),
    edges,
    haplotypes: haps,
    positions,
    meta: { epsilon },
  };
}
