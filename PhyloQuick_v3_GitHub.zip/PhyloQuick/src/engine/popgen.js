/**
 * Intraspecific summary statistics and neutrality tests.
 *
 * All statistics are computed from the aligned sequences directly, using
 * pairwise deletion of gaps and ambiguous characters. Formulae follow the
 * original sources so the values are directly comparable with DnaSP and Arlequin:
 *
 *   S, eta         segregating sites and total mutations
 *   h, Hd          number of haplotypes and haplotype (gene) diversity — Nei (1987) eq. 8.4
 *   pi             nucleotide diversity — Nei (1987) eq. 10.5
 *   k              mean number of pairwise differences
 *   theta_W        Watterson (1975)
 *   Tajima's D     Tajima (1989)
 *   Fu & Li's D*, F*   Fu & Li (1993), total-sample (no outgroup) versions
 *   Fu's Fs        Fu (1997)
 *   R2             Ramos-Onsins & Rozas (2002)
 *   raggedness     Harpending (1994) mismatch-distribution raggedness index
 */

import { lnGamma } from './models.js';

const RESOLVED = new Set(['A', 'C', 'G', 'T']);

/**
 * @param {string[]} seqs aligned sequences
 * @param {object} opts
 * @param {boolean} opts.completeDeletion  exclude every site with a gap/N in any sequence
 */
export function populationStatistics(seqs, opts = {}) {
  const n = seqs.length;
  if (n < 2) {
    return { n, sites: 0, S: 0, h: 0, Hd: 0, pi: 0, k: 0, thetaW: 0, tajimaD: null };
  }

  const length = seqs[0].length;
  const usableColumns = [];
  for (let c = 0; c < length; c++) {
    let resolved = 0;
    for (let r = 0; r < n; r++) if (RESOLVED.has(seqs[r][c])) resolved++;
    if (opts.completeDeletion ? resolved === n : resolved >= 2) usableColumns.push(c);
  }

  // Segregating sites and the number of distinct states per site.
  let S = 0;
  let eta = 0;
  let singletons = 0;
  const siteStates = [];
  for (const c of usableColumns) {
    const counts = { A: 0, C: 0, G: 0, T: 0 };
    let total = 0;
    for (let r = 0; r < n; r++) {
      const ch = seqs[r][c];
      if (RESOLVED.has(ch)) { counts[ch]++; total++; }
    }
    const present = Object.entries(counts).filter(([, v]) => v > 0);
    siteStates.push({ column: c, counts, total, states: present.length });
    if (present.length > 1) {
      S++;
      eta += present.length - 1;
      // eta_s counts *mutations* seen exactly once, not sites: a site with
      // states (1, 1, n-2) contributes two singleton mutations.
      const singletonStates = present.filter(([, v]) => v === 1).length;
      singletons += Math.min(singletonStates, present.length - 1);
    }
  }

  // Nucleotide diversity: mean pairwise difference per site, pairwise deletion.
  let pairSum = 0;
  let pairCount = 0;
  let diffSum = 0;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      let diff = 0;
      let compared = 0;
      for (const c of usableColumns) {
        const a = seqs[i][c];
        const b = seqs[j][c];
        if (!RESOLVED.has(a) || !RESOLVED.has(b)) continue;
        compared++;
        if (a !== b) diff++;
      }
      if (!compared) continue;
      pairSum += diff / compared;
      diffSum += diff;
      pairCount++;
    }
  }
  const pi = pairCount ? pairSum / pairCount : 0;
  const k = pairCount ? diffSum / pairCount : 0;

  // Haplotype diversity.
  const hapCounts = new Map();
  for (const s of seqs) hapCounts.set(s, (hapCounts.get(s) || 0) + 1);
  const h = hapCounts.size;
  let sumSq = 0;
  for (const c of hapCounts.values()) sumSq += (c / n) * (c / n);
  const Hd = (n / (n - 1)) * (1 - sumSq);
  const HdVariance = haplotypeDiversityVariance([...hapCounts.values()], n);

  // Watterson's theta.
  const a1 = harmonic(n - 1, 1);
  const a2 = harmonic(n - 1, 2);
  const nSites = usableColumns.length;
  const thetaW = a1 ? S / a1 : 0;
  const thetaWPerSite = nSites ? thetaW / nSites : 0;

  const tajima = tajimaD(k, S, n, a1, a2);
  const fuLi = fuLiDStar(n, eta, singletons, k, a1, a2);
  const fs = fuFs(n, h, k);
  const r2 = ramosOnsinsRozasR2(seqs, usableColumns, n, k);
  const mismatch = mismatchDistribution(seqs, usableColumns, n);

  return {
    n,
    sites: nSites,
    totalSites: length,
    S,
    eta,
    singletonMutations: singletons,
    h,
    Hd,
    HdSD: Math.sqrt(Math.max(HdVariance, 0)),
    pi,
    piSD: Math.sqrt(Math.max(nucleotideDiversityVariance(pi, n, nSites), 0)),
    k,
    thetaW,
    thetaWPerSite,
    tajimaD: tajima.D,
    tajimaDVariance: tajima.variance,
    tajimaP: tajima.p,
    fuLiDStar: fuLi.dStar,
    fuLiFStar: fuLi.fStar,
    fuFs: fs,
    r2,
    mismatch,
    siteStates,
  };
}

function harmonic(m, power) {
  let s = 0;
  for (let i = 1; i <= m; i++) s += 1 / Math.pow(i, power);
  return s;
}

/**
 * Tajima's D (Tajima 1989, eq. 38): the standardised difference between the
 * two estimators of theta, pi (from pairwise differences) and Watterson's
 * (from segregating sites).
 */
export function tajimaD(k, S, n, a1 = harmonic(n - 1, 1), a2 = harmonic(n - 1, 2)) {
  if (!S || n < 4) return { D: null, variance: null, p: null };
  const b1 = (n + 1) / (3 * (n - 1));
  const b2 = (2 * (n * n + n + 3)) / (9 * n * (n - 1));
  const c1 = b1 - 1 / a1;
  const c2 = b2 - (n + 2) / (a1 * n) + a2 / (a1 * a1);
  const e1 = c1 / a1;
  const e2 = c2 / (a1 * a1 + a2);
  const variance = e1 * S + e2 * S * (S - 1);
  if (variance <= 0) return { D: null, variance, p: null };
  const D = (k - S / a1) / Math.sqrt(variance);
  return { D, variance, p: tajimaBetaP(D, n) };
}

/**
 * Approximate two-tailed significance for Tajima's D using the beta
 * distribution over [Dmin, Dmax] recommended by Tajima (1989).
 * Reported as an approximation; coalescent simulation is the exact route and
 * is offered separately in the validation module.
 */
function tajimaBetaP(D, n) {
  const a1 = harmonic(n - 1, 1);
  const a2 = harmonic(n - 1, 2);
  const b2 = (2 * (n * n + n + 3)) / (9 * n * (n - 1));
  const c2 = b2 - (n + 2) / (a1 * n) + a2 / (a1 * a1);
  const e2 = c2 / (a1 * a1 + a2);
  if (!(e2 > 0)) return null;
  const sd = Math.sqrt(e2);
  // Tajima (1989) eqs. 39-40: the attainable range of D as S grows.
  const Dmin = (2 / n - 1 / a1) / sd;
  const Dmax = (n % 2 === 0 ? n / (2 * (n - 1)) : (n + 1) / (2 * n)) / 1 - 1 / a1;
  const DmaxScaled = Dmax / sd;
  if (!Number.isFinite(Dmin) || !Number.isFinite(DmaxScaled) || DmaxScaled <= Dmin) return null;
  return betaTail(D, Dmin, DmaxScaled);
}

function betaTail(D, Dmin, Dmax) {
  const alpha = -(1 + Dmin * Dmax) * Dmax / (Dmax - Dmin);
  const beta = (1 + Dmin * Dmax) * Dmin / (Dmax - Dmin);
  if (!(alpha > 0) || !(beta > 0)) return null;
  const x = (D - Dmin) / (Dmax - Dmin);
  const cdf = incompleteBeta(Math.min(Math.max(x, 0), 1), alpha, beta);
  return 2 * Math.min(cdf, 1 - cdf);
}

/**
 * Fu & Li's D* and F* (Fu & Li 1993), the total-sample versions that use the
 * count of singleton mutations in place of an outgroup.
 *
 *   D* = [ (n/(n-1)) eta - a_n eta_s ] / sqrt( u_D eta + v_D eta^2 )
 *   F* = [ k - ((n-1)/n) eta_s ]      / sqrt( u_F eta + v_F eta^2 )
 *
 * with eta the total number of mutations, eta_s the number of mutations
 * observed exactly once, and k the mean number of pairwise differences.
 * The variance terms are Fu & Li's equations (25)-(32).
 */
export function fuLiDStar(n, eta, etaS, k, a1 = harmonic(n - 1, 1), a2 = harmonic(n - 1, 2)) {
  if (n < 4 || !eta) return { dStar: null, fStar: null };
  const an = a1;
  const bn = a2;
  const anPlus1 = an + 1 / n; // a_{n+1}

  const cn = (2 * (n * an - 2 * (n - 1))) / ((n - 1) * (n - 2));
  const dn = cn + (n - 2) / ((n - 1) * (n - 1))
    + (2 / (n - 1)) * (1.5 - (2 * anPlus1 - 3) / (n - 2) - 1 / n);

  const vD = (((n / (n - 1)) ** 2) * bn + (an ** 2) * dn
    - 2 * (n * an * (an + 1)) / ((n - 1) ** 2)) / (an ** 2 + bn);
  const uD = (n / (n - 1)) * (an - n / (n - 1)) - vD;

  const vF = (dn + (2 * (n * n + n + 3)) / (9 * n * (n - 1))
    - (2 / (n - 1)) * (4 * bn - 6 + 8 / n)) / (an ** 2 + bn);
  const uF = ((n / (n - 1)) + (n + 1) / (3 * (n - 1)) - 4 / (n * (n - 1))
    + ((2 * (n + 1)) / ((n - 1) ** 2)) * (anPlus1 - (2 * n) / (n + 1))) / an - vF;

  const denomD = Math.sqrt(uD * eta + vD * eta * eta);
  const denomF = Math.sqrt(uF * eta + vF * eta * eta);
  const dStar = denomD > 0 ? ((n / (n - 1)) * eta - an * etaS) / denomD : null;
  const fStar = denomF > 0 ? (k - ((n - 1) / n) * etaS) / denomF : null;

  return {
    dStar: Number.isFinite(dStar) ? dStar : null,
    fStar: Number.isFinite(fStar) ? fStar : null,
    uD, vD, uF, vF,
  };
}

/**
 * Fu's Fs (Fu 1997).
 *
 *   Fs = ln( S' / (1 - S') ),  S' = P(K >= k_obs | theta = pi)
 *
 * where the distribution of the number of alleles K given theta follows the
 * Ewens sampling formula. Stirling numbers of the first kind are accumulated in
 * log space, without which the recursion overflows past n ~ 30.
 */
export function fuFs(n, observedHaplotypes, k) {
  if (n < 2 || k <= 0) return null;
  const theta = k;
  if (!(theta > 0)) return null;

  // log|s(n, i)| by the recursion |s(n+1,i)| = |s(n,i-1)| + n|s(n,i)|.
  let logS = [0]; // n = 1: |s(1,1)| = 1
  for (let m = 1; m < n; m++) {
    const next = new Array(m + 2).fill(-Infinity);
    for (let i = 0; i < logS.length; i++) {
      const cur = logS[i];
      if (!Number.isFinite(cur)) continue;
      // |s(m+1, k)| = |s(m, k-1)| + m |s(m, k)| ; logS[i] holds |s(m, i+1)|
      next[i] = logAdd(next[i], cur + Math.log(m));
      next[i + 1] = logAdd(next[i + 1], cur);
    }
    logS = next;
  }

  // log theta^(n) = sum_{i=0}^{n-1} log(theta + i)
  let logTheta_n = 0;
  for (let i = 0; i < n; i++) logTheta_n += Math.log(theta + i);

  const probs = [];
  for (let i = 1; i <= n; i++) {
    const ls = logS[i - 1];
    if (ls === -Infinity) { probs.push(-Infinity); continue; }
    probs.push(ls + i * Math.log(theta) - logTheta_n);
  }

  let logTail = -Infinity;
  for (let i = observedHaplotypes; i <= n; i++) logTail = logAdd(logTail, probs[i - 1]);
  const sPrime = Math.exp(logTail);
  if (!(sPrime > 0) || !(sPrime < 1)) return null;
  return Math.log(sPrime / (1 - sPrime));
}

function logAdd(a, b) {
  if (a === -Infinity) return b;
  if (b === -Infinity) return a;
  const m = Math.max(a, b);
  return m + Math.log(Math.exp(a - m) + Math.exp(b - m));
}

/**
 * R2 statistic (Ramos-Onsins & Rozas 2002): sensitive to recent population
 * growth, and better behaved than Tajima's D at small sample sizes.
 */
export function ramosOnsinsRozasR2(seqs, columns, n, k) {
  if (n < 2 || !columns.length) return null;
  // Number of singleton mutations carried by each sequence.
  const singletonsPerSeq = new Float64Array(n);
  let S = 0;
  for (const c of columns) {
    const counts = new Map();
    for (let r = 0; r < n; r++) {
      const ch = seqs[r][c];
      if (RESOLVED.has(ch)) counts.set(ch, (counts.get(ch) || 0) + 1);
    }
    if (counts.size < 2) continue;
    S++;
    for (const [state, count] of counts) {
      if (count !== 1) continue;
      for (let r = 0; r < n; r++) if (seqs[r][c] === state) singletonsPerSeq[r] += 1;
    }
  }
  if (!S) return null;
  let sum = 0;
  for (let r = 0; r < n; r++) {
    const d = singletonsPerSeq[r] - k / 2;
    sum += d * d;
  }
  return Math.sqrt(sum / n) / S;
}

/**
 * Mismatch distribution and Harpending's (1994) raggedness index.
 * A smooth unimodal distribution is the signature of a population expansion;
 * the raggedness index quantifies how far from smooth the observed one is.
 */
export function mismatchDistribution(seqs, columns, n) {
  const counts = new Map();
  let pairs = 0;
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      let diff = 0;
      for (const c of columns) {
        const a = seqs[i][c];
        const b = seqs[j][c];
        if (!RESOLVED.has(a) || !RESOLVED.has(b)) continue;
        if (a !== b) diff++;
      }
      counts.set(diff, (counts.get(diff) || 0) + 1);
      pairs++;
    }
  }
  if (!pairs) return { distribution: [], raggedness: null };
  const maxDiff = Math.max(...counts.keys());
  const freq = [];
  for (let d = 0; d <= maxDiff; d++) freq.push((counts.get(d) || 0) / pairs);
  let raggedness = 0;
  for (let d = 1; d < freq.length; d++) raggedness += (freq[d] - freq[d - 1]) ** 2;
  return {
    distribution: freq.map((f, d) => ({ differences: d, frequency: f, count: counts.get(d) || 0 })),
    raggedness,
    pairs,
  };
}

function haplotypeDiversityVariance(counts, n) {
  const f = counts.map((c) => c / n);
  const s2 = f.reduce((a, x) => a + x * x, 0);
  const s3 = f.reduce((a, x) => a + x * x * x, 0);
  return (2 / (n * (n - 1))) * (2 * (n - 2) * (s3 - s2 * s2) + s2 - s2 * s2);
}

function nucleotideDiversityVariance(pi, n, sites) {
  if (!sites) return 0;
  return ((n + 1) / (3 * (n - 1) * sites)) * pi + ((2 * (n * n + n + 3)) / (9 * n * (n - 1))) * pi * pi;
}

// ---------------------------------------------------------------------------
// Incomplete beta, for the Tajima's D significance approximation
// ---------------------------------------------------------------------------

function incompleteBeta(x, a, b) {
  if (x <= 0) return 0;
  if (x >= 1) return 1;
  const lnBeta = lnGamma(a) + lnGamma(b) - lnGamma(a + b);
  const front = Math.exp(a * Math.log(x) + b * Math.log(1 - x) - lnBeta);
  if (x < (a + 1) / (a + b + 2)) return front * betaCF(x, a, b) / a;
  return 1 - Math.exp(b * Math.log(1 - x) + a * Math.log(x) - lnBeta) * betaCF(1 - x, b, a) / b;
}

function betaCF(x, a, b) {
  const tiny = 1e-300;
  let c = 1;
  let d = 1 - ((a + b) * x) / (a + 1);
  if (Math.abs(d) < tiny) d = tiny;
  d = 1 / d;
  let h = d;
  for (let m = 1; m <= 300; m++) {
    const m2 = 2 * m;
    let aa = (m * (b - m) * x) / ((a + m2 - 1) * (a + m2));
    d = 1 + aa * d; if (Math.abs(d) < tiny) d = tiny;
    c = 1 + aa / c; if (Math.abs(c) < tiny) c = tiny;
    d = 1 / d;
    h *= d * c;
    aa = (-(a + m) * (a + b + m) * x) / ((a + m2) * (a + m2 + 1));
    d = 1 + aa * d; if (Math.abs(d) < tiny) d = tiny;
    c = 1 + aa / c; if (Math.abs(c) < tiny) c = tiny;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < 1e-12) break;
  }
  return h;
}
