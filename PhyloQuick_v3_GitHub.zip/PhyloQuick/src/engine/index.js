/**
 * PhyloQuick analysis engine: public exports.
 *
 * Dependency-free ES modules that run unchanged in a browser, in a Web Worker,
 * in Electron's renderer and in plain Node. The desktop interface, the Web
 * Worker and the command-line tool all import from here, so a result cannot
 * differ between them.
 */

export { VERSION, DEFAULTS, runAnalysis } from './pipeline.js';

export { RNG } from './rng.js';
export { sha256 } from './hash.js';

export {
  parseFasta, toFasta, toPhylip, toNexus, qualityControl, toAlignment,
  isAligned, trimAlignment, variableSites, parsimonyInformativeSites,
  baseFrequencies, consensus, compressPatterns, columnGapFraction, sanitizeName,
} from './seq.js';

export {
  align, sumOfPairsScore, kmerDistanceMatrix, DEFAULT_ALIGN_OPTIONS,
} from './align.js';

export {
  SubstitutionModel, MODEL_NAMES, MODEL_SPEC, MODEL_FREE_PARAMS,
  discreteGammaRates, jacobiEigen, lnGamma, incompleteGamma, pointChi2, pointGamma,
} from './models.js';

export {
  distanceMatrix, toPhylipMatrix, toTsvMatrix, DISTANCE_MODELS,
  pDistance, jc69Distance, k80Distance, tn93Distance, mlDistance,
} from './distance.js';

export { neighborJoining, bionj, upgma, buildTree } from './cluster.js';

export {
  LikelihoodEngine, maximumLikelihoodTree,
} from './likelihood.js';

export {
  selectModel, candidateModels, toTsv as modelSelectionToTsv, RATE_VARIANTS,
} from './modelselect.js';

export { bootstrap, consensusTree, collapseWeakBranches } from './support.js';

export { populationStatistics, tajimaD, fuFs, fuLiDStar, mismatchDistribution } from './popgen.js';

export {
  buildNetwork, haplotypes, minimumSpanningNetwork, medianJoiningNetwork,
  parsimonyNetwork, parsimonyLimit, variableSiteMatrix,
} from './network.js';

export {
  robinsonFoulds, splitAccuracy, branchScoreDistance, quartetDistance,
} from './treecmp.js';

export {
  randomTree, simulateAlignment, addIndels, alignmentAccuracy, randomModel,
} from './simulate.js';

export {
  parseNewick, writeNewick, makeNode, cloneTree, relink, unroot,
  midpointRoot, outgroupRoot, rootOnBranch, collapseDegreeTwo,
  postorder, preorder, isLeaf, leaves, leafNames, nodeCount, treeLength,
  bipartitions,
} from './tree.js';

export { brentMin, brentMax, coordinateAscent } from './optimise.js';
