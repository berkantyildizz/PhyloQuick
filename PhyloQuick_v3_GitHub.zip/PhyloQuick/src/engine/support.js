/**
 * Branch support: nonparametric bootstrap and consensus.
 *
 * Support is computed per bipartition: each internal branch of the reference
 * tree receives the percentage of replicates in which its split was recovered.
 * Resampling uses the seeded generator in rng.js, so a given seed reproduces
 * the same support values.
 */

import { RNG } from './rng.js';
import { bipartitions, leafNames, postorder, isLeaf, makeNode, relink } from './tree.js';

/**
 * Nonparametric bootstrap.
 *
 * @param {object} aln          {names, seqs}
 * @param {object} referenceTree tree whose branches are to be scored
 * @param {function} rebuild     (names, seqs) => tree, the full inference
 *                               procedure, re-run on each replicate
 * @param {object} opts
 * @param {number} opts.replicates
 * @param {number} opts.seed
 * @param {function} opts.onProgress (fraction) => void
 */
export function bootstrap(aln, referenceTree, rebuild, opts = {}) {
  const replicates = opts.replicates ?? 500;
  const seed = opts.seed ?? 42;
  const rng = new RNG(seed);
  const taxonOrder = leafNames(referenceTree).slice().sort();
  const reference = bipartitions(referenceTree, taxonOrder);
  const counts = new Map([...reference.keys()].map((k) => [k, 0]));
  const allSplits = new Map(); // for the majority-rule consensus

  const nSites = aln.seqs[0] ? aln.seqs[0].length : 0;
  const t0 = now();
  let failed = 0;

  for (let b = 0; b < replicates; b++) {
    const columns = new Int32Array(nSites);
    for (let i = 0; i < nSites; i++) columns[i] = rng.int(nSites);
    const seqs = aln.seqs.map((s) => {
      const out = new Array(nSites);
      for (let i = 0; i < nSites; i++) out[i] = s[columns[i]];
      return out.join('');
    });

    let tree;
    try {
      tree = rebuild(aln.names, seqs, b);
    } catch (err) {
      failed++;
      continue;
    }
    if (!tree) { failed++; continue; }

    const splits = bipartitions(tree, taxonOrder);
    for (const key of splits.keys()) {
      if (counts.has(key)) counts.set(key, counts.get(key) + 1);
      allSplits.set(key, (allSplits.get(key) || 0) + 1);
    }
    if (opts.onProgress && (b % 10 === 0 || b === replicates - 1)) {
      opts.onProgress((b + 1) / replicates);
    }
  }

  const effective = replicates - failed;
  const support = new Map();
  for (const [key, node] of reference) {
    const value = effective ? (counts.get(key) / effective) * 100 : 0;
    support.set(node, value);
    node.support = value;
  }

  return {
    support,
    splitFrequencies: allSplits,
    taxonOrder,
    replicates,
    effectiveReplicates: effective,
    failed,
    seed,
    meanSupport: mean([...support.values()]),
    elapsedMs: now() - t0,
  };
}

/**
 * Majority-rule (or extended majority-rule) consensus from bootstrap split
 * frequencies. Splits are added in order of decreasing frequency, skipping any
 * that conflict with those already accepted.
 */
export function consensusTree(splitFrequencies, taxonOrder, effectiveReplicates, threshold = 0.5) {
  const entries = [...splitFrequencies.entries()]
    .map(([key, count]) => ({ key, freq: count / effectiveReplicates }))
    .filter((e) => e.freq >= threshold)
    .sort((a, b) => b.freq - a.freq);

  const accepted = [];
  for (const e of entries) {
    if (accepted.every((a) => compatible(a.key, e.key))) accepted.push(e);
  }

  // Build the tree from nested clades: sort by clade size, then insert.
  const n = taxonOrder.length;
  const clades = accepted.map((e) => ({
    members: new Set(sideOf(e.key, taxonOrder, false)),
    freq: e.freq,
  })).sort((a, b) => a.members.size - b.members.size);

  const root = makeNode();
  const tipNodes = new Map(taxonOrder.map((name) => [name, makeNode(name, 0)]));
  const nodeFor = [];

  for (const clade of clades) {
    const node = makeNode();
    node.support = clade.freq * 100;
    const children = [];
    const consumed = new Set();
    for (const inner of nodeFor) {
      if ([...inner.members].every((m) => clade.members.has(m))) {
        children.push(inner.node);
        for (const m of inner.members) consumed.add(m);
      }
    }
    for (const m of clade.members) {
      if (!consumed.has(m)) children.push(tipNodes.get(m));
    }
    node.children = children;
    // Replace absorbed clades with this one.
    for (let i = nodeFor.length - 1; i >= 0; i--) {
      if ([...nodeFor[i].members].every((m) => clade.members.has(m))) nodeFor.splice(i, 1);
    }
    nodeFor.push({ members: clade.members, node });
  }

  const topLevel = new Set();
  for (const entry of nodeFor) for (const m of entry.members) topLevel.add(m);
  root.children = [...nodeFor.map((e) => e.node),
    ...taxonOrder.filter((name) => !topLevel.has(name)).map((name) => tipNodes.get(name))];
  void n;
  return relink(root);
}

/** Two canonical split keys are compatible if they can coexist in one tree. */
function compatible(a, b) {
  let n00 = 0; let n01 = 0; let n10 = 0; let n11 = 0;
  for (let i = 0; i < a.length; i++) {
    const x = a[i] === '1';
    const y = b[i] === '1';
    if (!x && !y) n00++;
    else if (!x && y) n01++;
    else if (x && !y) n10++;
    else n11++;
  }
  return n00 === 0 || n01 === 0 || n10 === 0 || n11 === 0;
}

function sideOf(key, taxonOrder, wantZero) {
  const out = [];
  for (let i = 0; i < key.length; i++) {
    const bit = key[i] === '1';
    if (bit !== wantZero) out.push(taxonOrder[i]);
  }
  return out;
}

/**
 * Collapse branches whose support falls below `threshold` into polytomies.
 * Useful for reporting: a tree with 40% branches shown as resolved implies
 * more than the data support.
 */
export function collapseWeakBranches(root, threshold = 50) {
  for (const node of postorder(root)) {
    if (node === root || isLeaf(node)) continue;
    if (node.support != null && node.support < threshold) {
      const parent = node.parent;
      const at = parent.children.indexOf(node);
      for (const child of node.children) child.length += node.length;
      parent.children.splice(at, 1, ...node.children);
      for (const child of node.children) child.parent = parent;
    }
  }
  return relink(root);
}

function mean(values) {
  if (!values.length) return 0;
  return values.reduce((a, b) => a + b, 0) / values.length;
}

function now() {
  return typeof performance !== 'undefined' ? performance.now() : Date.now();
}
