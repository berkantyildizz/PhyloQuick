/**
 * Deterministic pseudo-random number generation.
 *
 * Every stochastic step in PhyloQuick (bootstrap resampling, RELL replicates,
 * sequence simulation, random starting trees) draws from a seeded generator so
 * that an identical seed reproduces an identical result on any machine and in
 * any of the three runtimes (browser, Electron, Node CLI).
 *
 * Generator: xoshiro128** (Blackman & Vigna 2018) seeded through splitmix32.
 * Chosen over Math.random() because the state is explicit and portable.
 */

const U32 = 0xffffffff;

function splitmix32(seed) {
  let a = seed >>> 0;
  return function () {
    a = (a + 0x9e3779b9) >>> 0;
    let t = a;
    t = Math.imul(t ^ (t >>> 15), t | 1) >>> 0;
    t = (t ^ (t + Math.imul(t ^ (t >>> 7), t | 61))) >>> 0;
    return (t ^ (t >>> 14)) >>> 0;
  };
}

export class RNG {
  constructor(seed = 42) {
    this.seed = seed >>> 0;
    const sm = splitmix32(this.seed);
    this.s = [sm(), sm(), sm(), sm()];
  }

  /** Raw 32-bit unsigned draw. */
  nextUint32() {
    const s = this.s;
    const result = (Math.imul(rotl(Math.imul(s[1], 5) >>> 0, 7), 9) >>> 0) >>> 0;
    const t = (s[1] << 9) >>> 0;
    s[2] = (s[2] ^ s[0]) >>> 0;
    s[3] = (s[3] ^ s[1]) >>> 0;
    s[1] = (s[1] ^ s[2]) >>> 0;
    s[0] = (s[0] ^ s[3]) >>> 0;
    s[2] = (s[2] ^ t) >>> 0;
    s[3] = rotl(s[3], 11);
    return result;
  }

  /** Uniform on [0,1). */
  next() {
    return this.nextUint32() / (U32 + 1);
  }

  /** Uniform integer on [0,n). */
  int(n) {
    return Math.floor(this.next() * n);
  }

  /** Exponential with the given rate. */
  exponential(rate = 1) {
    let u = this.next();
    if (u <= 0) u = Number.MIN_VALUE;
    return -Math.log(u) / rate;
  }

  /** Standard normal (Box–Muller, second variate cached). */
  normal() {
    if (this._spare !== undefined) {
      const v = this._spare;
      this._spare = undefined;
      return v;
    }
    let u = this.next();
    if (u <= 0) u = Number.MIN_VALUE;
    const r = Math.sqrt(-2 * Math.log(u));
    const theta = 2 * Math.PI * this.next();
    this._spare = r * Math.sin(theta);
    return r * Math.cos(theta);
  }

  /** Gamma(shape, scale) via Marsaglia & Tsang (2000). */
  gamma(shape, scale = 1) {
    if (shape < 1) {
      const u = this.next();
      return this.gamma(shape + 1, scale) * Math.pow(u, 1 / shape);
    }
    const d = shape - 1 / 3;
    const c = 1 / Math.sqrt(9 * d);
    for (;;) {
      let x, v;
      do {
        x = this.normal();
        v = 1 + c * x;
      } while (v <= 0);
      v = v * v * v;
      const u = this.next();
      if (u < 1 - 0.0331 * x * x * x * x) return d * v * scale;
      if (Math.log(u) < 0.5 * x * x + d * (1 - v + Math.log(v))) return d * v * scale;
    }
  }

  /** Index drawn from a discrete distribution given as unnormalised weights. */
  categorical(weights) {
    let total = 0;
    for (let i = 0; i < weights.length; i++) total += weights[i];
    let u = this.next() * total;
    for (let i = 0; i < weights.length; i++) {
      u -= weights[i];
      if (u <= 0) return i;
    }
    return weights.length - 1;
  }

  /** In-place Fisher–Yates shuffle. */
  shuffle(array) {
    for (let i = array.length - 1; i > 0; i--) {
      const j = this.int(i + 1);
      const tmp = array[i];
      array[i] = array[j];
      array[j] = tmp;
    }
    return array;
  }

  /**
   * Bootstrap resample of site indices: n draws with replacement from [0,n).
   * Returned as a count vector so that downstream code can use pattern weights
   * instead of materialising the resampled alignment.
   */
  bootstrapCounts(n, total = n) {
    const counts = new Float64Array(n);
    for (let i = 0; i < total; i++) counts[this.int(n)] += 1;
    return counts;
  }
}

function rotl(x, k) {
  return (((x << k) | (x >>> (32 - k))) >>> 0);
}

export default RNG;
