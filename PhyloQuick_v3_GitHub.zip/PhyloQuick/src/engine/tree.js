/**
 * Tree representation, Newick I/O and topology utilities.
 *
 * A tree is a plain object graph of nodes:
 *   { id, name, length, support, children: [Node], parent: Node|null }
 *
 * `length` is the length of the branch connecting the node to its parent.
 * Unrooted trees are stored as rooted trees whose root has three children;
 * everything that cares about rootedness (bipartitions, Robinson–Foulds,
 * likelihood) works from that convention.
 */

let nodeCounter = 0;

export function makeNode(name = '', length = 0) {
  return { id: nodeCounter++, name, length, support: null, children: [], parent: null };
}

export function isLeaf(node) {
  return node.children.length === 0;
}

/** Depth-first list of nodes, children before parents. */
export function postorder(root) {
  const out = [];
  const stack = [[root, false]];
  while (stack.length) {
    const [node, visited] = stack.pop();
    if (visited) { out.push(node); continue; }
    stack.push([node, true]);
    for (let i = node.children.length - 1; i >= 0; i--) stack.push([node.children[i], false]);
  }
  return out;
}

/** Depth-first list of nodes, parents before children. */
export function preorder(root) {
  const out = [];
  const stack = [root];
  while (stack.length) {
    const node = stack.pop();
    out.push(node);
    for (let i = node.children.length - 1; i >= 0; i--) stack.push(node.children[i]);
  }
  return out;
}

export function leaves(root) {
  return postorder(root).filter(isLeaf);
}

export function leafNames(root) {
  return leaves(root).map((n) => n.name);
}

/** Total number of nodes in the tree. */
export function nodeCount(root) {
  return postorder(root).length;
}

/** Sum of all branch lengths. */
export function treeLength(root) {
  return postorder(root).reduce((sum, n) => sum + (n.parent ? n.length : 0), 0);
}

// ---------------------------------------------------------------------------
// Newick parsing / writing
// ---------------------------------------------------------------------------

/**
 * Parse a Newick string. Handles quoted labels, branch lengths, internal node
 * labels (interpreted as support values when numeric) and comments in [].
 */
export function parseNewick(text) {
  const s = String(text).replace(/\[[^\]]*\]/g, '').trim();
  let i = 0;

  function skipSpace() { while (i < s.length && /\s/.test(s[i])) i++; }

  function readLabel() {
    skipSpace();
    if (s[i] === "'" || s[i] === '"') {
      const quote = s[i++];
      let out = '';
      while (i < s.length && s[i] !== quote) out += s[i++];
      i++;
      return out;
    }
    let out = '';
    while (i < s.length && !/[(),:;]/.test(s[i])) out += s[i++];
    return out.trim().replace(/_/g, ' ').trim() || out.trim();
  }

  function readNumber() {
    skipSpace();
    let out = '';
    while (i < s.length && /[-+0-9.eE]/.test(s[i])) out += s[i++];
    const v = parseFloat(out);
    return Number.isFinite(v) ? v : 0;
  }

  function readNode() {
    skipSpace();
    const node = makeNode();
    if (s[i] === '(') {
      i++;
      for (;;) {
        const child = readNode();
        child.parent = node;
        node.children.push(child);
        skipSpace();
        if (s[i] === ',') { i++; continue; }
        if (s[i] === ')') { i++; break; }
        if (i >= s.length) break;
        i++;
      }
      const label = readLabel();
      if (label !== '') {
        const num = parseFloat(label);
        if (Number.isFinite(num) && /^[0-9.]+$/.test(label)) node.support = num;
        else node.name = label;
      }
    } else {
      node.name = readLabel();
    }
    skipSpace();
    if (s[i] === ':') { i++; node.length = readNumber(); }
    return node;
  }

  const root = readNode();
  return root;
}

/**
 * Serialise a tree to Newick. `opts.support` writes internal node support as
 * the internal label; `opts.precision` controls branch-length digits.
 */
export function writeNewick(root, opts = {}) {
  const precision = opts.precision ?? 6;
  const withSupport = opts.support !== false;
  const withLengths = opts.lengths !== false;

  function fmt(node, isRoot) {
    let out;
    if (isLeaf(node)) {
      out = quote(node.name);
    } else {
      out = '(' + node.children.map((c) => fmt(c, false)).join(',') + ')';
      if (withSupport) {
        // When both SH-aLRT and bootstrap are available they are written as
        // "shalrt/bootstrap", the convention IQ-TREE uses, so downstream
        // viewers can show either.
        const parts = [];
        if (node.shalrt != null) parts.push(round(node.shalrt, 1));
        if (node.support != null) parts.push(round(node.support, 1));
        if (parts.length) out += parts.join('/');
      }
    }
    if (!isRoot && withLengths) out += ':' + round(node.length, precision);
    return out;
  }
  return fmt(root, true) + ';';
}

function round(x, digits) {
  if (!Number.isFinite(x)) return 0;
  const v = Number(x.toFixed(digits));
  return Object.is(v, -0) ? 0 : v;
}

function quote(name) {
  return /[\s(),:;'"\[\]]/.test(name) ? `'${String(name).replace(/'/g, "''")}'` : name;
}

// ---------------------------------------------------------------------------
// Structure helpers
// ---------------------------------------------------------------------------

/** Deep copy preserving structure (ids are regenerated). */
export function cloneTree(root) {
  function rec(node, parent) {
    const copy = makeNode(node.name, node.length);
    copy.support = node.support;
    copy.shalrt = node.shalrt;
    copy.parent = parent;
    copy.children = node.children.map((c) => rec(c, copy));
    return copy;
  }
  return rec(root, null);
}

/** Re-link parent pointers after manual surgery on `children` arrays. */
export function relink(root) {
  root.parent = null;
  for (const node of preorder(root)) {
    for (const child of node.children) child.parent = node;
  }
  return root;
}

/**
 * Convert a rooted binary tree to the unrooted convention used internally:
 * a root with exactly three children. If the root has two children, the two
 * root branches are merged into one.
 */
export function unroot(root) {
  if (root.children.length !== 2) return root;
  const [a, b] = root.children;
  const merged = a.length + b.length;
  // Collapse into whichever child is internal so no taxon is lost.
  const keep = !isLeaf(a) ? a : (!isLeaf(b) ? b : null);
  if (!keep) return root; // two-taxon tree, nothing to do
  const other = keep === a ? b : a;
  other.length = merged;
  const newRoot = makeNode();
  newRoot.children = [...keep.children, other];
  relink(newRoot);
  return newRoot;
}

/** Root the tree on the branch above `target` (midpoint of that branch). */
export function rootOnBranch(root, target, position = 0.5) {
  const tree = cloneTree(root);
  const nodes = postorder(tree);
  const node = nodes.find((n) => n.name === target.name && isLeaf(n) === isLeaf(target))
    || nodes.find((n) => n.id === target.id);
  if (!node || !node.parent) return tree;

  const newRoot = makeNode();
  const len = node.length;
  const parent = node.parent;

  // Detach node from its parent, then re-hang the rest of the tree under the
  // new root by reversing parent links along the path to the old root.
  parent.children = parent.children.filter((c) => c !== node);
  newRoot.children.push(node);
  node.length = len * position;

  let current = parent;
  let carried = len * (1 - position);
  for (;;) {
    const up = current.parent;
    if (!up) break;
    up.children = up.children.filter((c) => c !== current);
    current.children.push(up);
    const nextCarried = current.length;
    up.length = nextCarried;
    current = up;
    if (current.children.length === 1 && current.parent === null) break;
  }
  // Collapse degree-1 remnants of the old root.
  const stray = parent;
  stray.length = carried;
  newRoot.children.push(stray);
  relink(newRoot);
  collapseDegreeTwo(newRoot);
  return newRoot;
}

/** Remove internal nodes with a single child, adding their branch lengths. */
export function collapseDegreeTwo(root) {
  for (const node of postorder(root)) {
    if (node === root || isLeaf(node)) continue;
    if (node.children.length === 1) {
      const child = node.children[0];
      child.length += node.length;
      const parent = node.parent;
      parent.children[parent.children.indexOf(node)] = child;
      child.parent = parent;
    }
  }
  if (root.children.length === 1 && !isLeaf(root.children[0])) {
    const child = root.children[0];
    root.children = child.children;
    relink(root);
  }
  return root;
}

/** Midpoint rooting: place the root at the midpoint of the longest leaf path. */
export function midpointRoot(root) {
  const tree = cloneTree(root);
  const all = postorder(tree);
  const tips = all.filter(isLeaf);
  if (tips.length < 3) return tree;

  // Farthest-pair search over the tree metric.
  const adj = new Map();
  for (const n of all) adj.set(n, []);
  for (const n of all) {
    if (n.parent) {
      adj.get(n).push([n.parent, n.length]);
      adj.get(n.parent).push([n, n.length]);
    }
  }
  function farthest(start) {
    const dist = new Map([[start, 0]]);
    const stack = [start];
    let best = start;
    while (stack.length) {
      const n = stack.pop();
      for (const [m, w] of adj.get(n)) {
        if (dist.has(m)) continue;
        dist.set(m, dist.get(n) + w);
        if (isLeaf(m) && dist.get(m) > (dist.get(best) ?? -1)) best = m;
        stack.push(m);
      }
    }
    return { node: best, dist };
  }
  const a = farthest(tips[0]).node;
  const { node: b, dist } = farthest(a);
  const total = dist.get(b);
  // Walk back from b towards a until half the diameter is covered.
  const path = [];
  let cur = b;
  const seen = new Set();
  (function walk(n) {
    seen.add(n);
    path.push(n);
    if (n === a) return true;
    for (const [m] of adj.get(n)) {
      if (seen.has(m)) continue;
      if (walk(m)) return true;
    }
    path.pop();
    return false;
  })(b);

  let acc = 0;
  for (let i = 0; i < path.length - 1; i++) {
    const w = adj.get(path[i]).find(([m]) => m === path[i + 1])[1];
    if (acc + w >= total / 2) {
      const child = path[i].parent === path[i + 1] ? path[i] : path[i + 1];
      const pos = child === path[i] ? (total / 2 - acc) / w : 1 - (total / 2 - acc) / w;
      return rootOnBranch(tree, child, Math.min(0.999, Math.max(0.001, pos)));
    }
    acc += w;
  }
  return tree;
}

/** Root using one or more outgroup taxon names. */
export function outgroupRoot(root, outgroupNames) {
  const wanted = new Set(outgroupNames);
  const tree = cloneTree(root);
  const target = postorder(tree).find((n) => {
    if (n === tree) return false;
    const names = new Set(leafNames(n));
    return names.size === wanted.size && [...wanted].every((w) => names.has(w));
  });
  if (!target) return null;
  return rootOnBranch(tree, target, 0.5);
}

// ---------------------------------------------------------------------------
// Bipartitions
// ---------------------------------------------------------------------------

/**
 * Encode the non-trivial splits of a tree as canonical bitstrings over a fixed
 * taxon ordering. Two trees can then be compared by set operations on the
 * returned keys, which is what Robinson–Foulds and bootstrap support need.
 */
export function bipartitions(root, taxonOrder) {
  const index = new Map(taxonOrder.map((name, i) => [name, i]));
  const n = taxonOrder.length;
  const splits = new Map(); // key -> node

  function rec(node) {
    if (isLeaf(node)) {
      const bits = new Uint8Array(n);
      const idx = index.get(node.name);
      if (idx !== undefined) bits[idx] = 1;
      return bits;
    }
    const bits = new Uint8Array(n);
    for (const child of node.children) {
      const cb = rec(child);
      for (let i = 0; i < n; i++) if (cb[i]) bits[i] = 1;
    }
    if (node !== root) {
      let ones = 0;
      for (let i = 0; i < n; i++) ones += bits[i];
      if (ones > 1 && ones < n - 1) splits.set(canonicalKey(bits, n), node);
    }
    return bits;
  }
  rec(root);
  return splits;
}

/** Bitstring, flipped so that taxon 0 is always on the "0" side. */
function canonicalKey(bits, n) {
  const flip = bits[0] === 1;
  let key = '';
  for (let i = 0; i < n; i++) key += (flip ? 1 - bits[i] : bits[i]);
  return key;
}

export { canonicalKey };
