/**
 * One-dimensional numerical optimisation used throughout the likelihood code.
 *
 * Brent's method (parabolic interpolation with golden-section fallback) is used
 * rather than a plain golden-section search because likelihood surfaces in
 * branch length and in the model parameters are smooth and close to quadratic
 * near the optimum, where parabolic steps converge much faster.
 */

const GOLDEN = 0.3819660112501051;

/**
 * Minimise `f` on [a, b]. Returns { x, fx, evaluations }.
 * `tol` is the relative tolerance on x.
 */
export function brentMin(f, a, b, tol = 1e-6, maxIter = 100) {
  let x = a + GOLDEN * (b - a);
  let w = x; let v = x;
  let fx = f(x); let fw = fx; let fv = fx;
  let d = 0; let e = 0;
  let evaluations = 1;

  for (let iter = 0; iter < maxIter; iter++) {
    const mid = 0.5 * (a + b);
    const tol1 = tol * Math.abs(x) + 1e-12;
    const tol2 = 2 * tol1;
    if (Math.abs(x - mid) <= tol2 - 0.5 * (b - a)) break;

    let useGolden = true;
    if (Math.abs(e) > tol1) {
      // Try a parabolic fit through (x,fx), (w,fw), (v,fv).
      const r = (x - w) * (fx - fv);
      const q0 = (x - v) * (fx - fw);
      let p = (x - v) * q0 - (x - w) * r;
      let q = 2 * (q0 - r);
      if (q > 0) p = -p;
      q = Math.abs(q);
      const eTemp = e;
      e = d;
      if (Math.abs(p) < Math.abs(0.5 * q * eTemp) && p > q * (a - x) && p < q * (b - x)) {
        d = p / q;
        const u = x + d;
        if (u - a < tol2 || b - u < tol2) d = Math.sign(mid - x) * tol1;
        useGolden = false;
      }
    }
    if (useGolden) {
      e = (x >= mid) ? a - x : b - x;
      d = GOLDEN * e;
    }

    const u = Math.abs(d) >= tol1 ? x + d : x + Math.sign(d || 1) * tol1;
    const fu = f(u);
    evaluations++;

    if (fu <= fx) {
      if (u >= x) a = x; else b = x;
      v = w; fv = fw;
      w = x; fw = fx;
      x = u; fx = fu;
    } else {
      if (u < x) a = u; else b = u;
      if (fu <= fw || w === x) { v = w; fv = fw; w = u; fw = fu; }
      else if (fu <= fv || v === x || v === w) { v = u; fv = fu; }
    }
  }
  return { x, fx, evaluations };
}

/** Maximise `f` on [a, b] by minimising its negation. */
export function brentMax(f, a, b, tol = 1e-6, maxIter = 100) {
  const r = brentMin((x) => -f(x), a, b, tol, maxIter);
  return { x: r.x, fx: -r.fx, evaluations: r.evaluations };
}

/**
 * Coordinate-wise maximisation over several bounded parameters.
 * Each parameter is optimised in turn with Brent until the objective stops
 * improving by more than `tol`. Adequate here because the parameters of a
 * substitution model are only weakly correlated once branch lengths are fixed.
 */
export function coordinateAscent(params, objective, { tol = 1e-4, maxRounds = 12 } = {}) {
  const values = params.map((p) => p.value);
  let best = objective(values);
  let evaluations = 1;

  for (let round = 0; round < maxRounds; round++) {
    const before = best;
    for (let i = 0; i < params.length; i++) {
      const p = params[i];
      const probe = (x) => {
        const trial = values.slice();
        trial[i] = x;
        evaluations++;
        return objective(trial);
      };
      const r = brentMax(probe, p.min, p.max, p.tol ?? 1e-4, p.maxIter ?? 40);
      if (r.fx > best) { best = r.fx; values[i] = r.x; }
    }
    if (best - before < tol) break;
  }
  return { values, value: best, evaluations };
}
