/**
 * Multiple sequence alignment.
 *
 * Three-stage progressive alignment:
 *
 *   1. k-mer distance matrix, computed without alignment;
 *   2. UPGMA guide tree on those distances;
 *   3. profile-profile alignment with affine (Gotoh) gap costs along the guide
 *      tree, followed by optional tree-dependent iterative refinement.
 *
 * Refinement splits the alignment on each guide-tree branch, realigns the two
 * halves and keeps the result only when the sum-of-pairs score improves (the
 * acceptance rule used by MUSCLE).
 *
 * Scoring defaults follow the EMBOSS DNA conventions (match +5, mismatch -4)
 * with affine gaps.
 */

import { upgma } from './cluster.js';
import { postorder, isLeaf } from './tree.js';

export const DEFAULT_ALIGN_OPTIONS = {
  match: 5,
  mismatch: -4,
  transitionBonus: 1,   // transitions penalised less than transversions
  gapOpen: -12,
  gapExtend: -1,
  terminalGapFactor: 0.5, // terminal gaps cost less, so ragged ends do not distort the core
  kmer: 4,
  refineRounds: 2,
  maxCells: 120e6,      // above this the DP is banded instead of full
  bandMin: 256,
};

const CODE = { A: 0, C: 1, G: 2, T: 3 };

// ---------------------------------------------------------------------------
// Stage 1: alignment-free k-mer distances
// ---------------------------------------------------------------------------

/**
 * Fractional common k-mer count distance (Edgar 2004).
 *   d = 1 - sum_w min(c1(w), c2(w)) / (min(L1, L2) - k + 1)
 * O(n * L) to build the profiles and O(n^2 * distinct k-mers) to compare, with
 * no alignment involved, which keeps a 500-sequence guide tree affordable.
 */
export function kmerDistanceMatrix(seqs, k = 4) {
  const profiles = seqs.map((s) => kmerProfile(s, k));
  const counts = seqs.map((s) => Math.max(s.replace(/[^ACGT]/g, '').length - k + 1, 1));
  const n = seqs.length;
  const D = Array.from({ length: n }, () => new Float64Array(n));
  for (let i = 0; i < n; i++) {
    for (let j = i + 1; j < n; j++) {
      const [small, large] = profiles[i].size <= profiles[j].size
        ? [profiles[i], profiles[j]] : [profiles[j], profiles[i]];
      let shared = 0;
      for (const [key, c] of small) {
        const other = large.get(key);
        if (other !== undefined) shared += Math.min(c, other);
      }
      const denom = Math.min(counts[i], counts[j]);
      const d = 1 - shared / denom;
      D[i][j] = D[j][i] = Math.max(0, Math.min(1, d));
    }
  }
  return D;
}

function kmerProfile(seq, k) {
  const map = new Map();
  let code = 0;
  let run = 0;
  const mask = (1 << (2 * k)) - 1;
  for (let i = 0; i < seq.length; i++) {
    const c = CODE[seq[i]];
    if (c === undefined) { run = 0; code = 0; continue; }
    code = ((code << 2) | c) & mask;
    run++;
    if (run >= k) map.set(code, (map.get(code) || 0) + 1);
  }
  return map;
}

// ---------------------------------------------------------------------------
// Profiles
// ---------------------------------------------------------------------------

/**
 * A profile is a set of aligned rows plus the per-column state frequencies
 * that the profile–profile score needs. Frequencies are recomputed only when
 * the profile is built, never inside the DP inner loop.
 */
function makeProfile(indices, rows) {
  const len = rows[0].length;
  const freq = new Float32Array(len * 4);
  const residue = new Float32Array(len); // fraction of non-gap characters
  const nRows = rows.length;
  for (let c = 0; c < len; c++) {
    let nonGap = 0;
    for (let r = 0; r < nRows; r++) {
      const ch = rows[r][c];
      const code = CODE[ch];
      if (code !== undefined) { freq[c * 4 + code] += 1; nonGap++; }
      else if (ch !== '-') {
        // Ambiguity code: spread its weight over the states it allows.
        const spread = AMBIG[ch];
        if (spread) {
          for (let s = 0; s < 4; s++) freq[c * 4 + s] += spread[s];
          nonGap++;
        }
      }
    }
    for (let s = 0; s < 4; s++) freq[c * 4 + s] /= nRows;
    residue[c] = nonGap / nRows;
  }
  return { indices, rows, len, freq, residue, nRows };
}

const AMBIG = {
  R: [0.5, 0, 0.5, 0], Y: [0, 0.5, 0, 0.5], S: [0, 0.5, 0.5, 0], W: [0.5, 0, 0, 0.5],
  K: [0, 0, 0.5, 0.5], M: [0.5, 0.5, 0, 0], B: [0, 1 / 3, 1 / 3, 1 / 3],
  D: [1 / 3, 0, 1 / 3, 1 / 3], H: [1 / 3, 1 / 3, 0, 1 / 3], V: [1 / 3, 1 / 3, 1 / 3, 0],
  N: [0.25, 0.25, 0.25, 0.25], '?': [0.25, 0.25, 0.25, 0.25],
};

/** 4x4 score matrix with a transition/transversion distinction. */
function scoreMatrix(opts) {
  const S = new Float64Array(16);
  for (let a = 0; a < 4; a++) {
    for (let b = 0; b < 4; b++) {
      if (a === b) S[a * 4 + b] = opts.match;
      else {
        const isTransition = (a === 0 && b === 2) || (a === 2 && b === 0)
          || (a === 1 && b === 3) || (a === 3 && b === 1);
        S[a * 4 + b] = opts.mismatch + (isTransition ? opts.transitionBonus : 0);
      }
    }
  }
  return S;
}

// ---------------------------------------------------------------------------
// Stage 3: profile-profile alignment with affine gaps (Gotoh 1982)
// ---------------------------------------------------------------------------

/**
 * Align two profiles and return the merged profile.
 *
 * Three DP layers are kept: M (columns matched), X (gap in Y) and Y (gap in X).
 * The traceback is stored as three byte planes, which is the memory bottleneck;
 * when the full matrix would exceed `maxCells` the DP is restricted to a
 * diagonal band, which is safe here because progressive alignment only ever
 * compares profiles that the k-mer stage already judged similar.
 */
function alignProfiles(P, Q, opts, S) {
  const m = P.len;
  const n = Q.len;
  const cells = (m + 1) * (n + 1);
  const banded = cells > opts.maxCells;
  const band = banded
    ? Math.max(opts.bandMin, Math.abs(m - n) + Math.ceil(Math.sqrt(Math.max(m, n)) * 4))
    : Infinity;

  const NEG = -1e18;
  const width = n + 1;
  const M = new Float64Array(width);
  const X = new Float64Array(width);
  const Y = new Float64Array(width);
  const Mprev = new Float64Array(width);
  const Xprev = new Float64Array(width);
  const Yprev = new Float64Array(width);
  // Traceback: 2 bits per layer per cell.
  const tbM = new Uint8Array(cells);
  const tbX = new Uint8Array(cells);
  const tbY = new Uint8Array(cells);

  const go = opts.gapOpen;
  const ge = opts.gapExtend;
  const tf = opts.terminalGapFactor;

  // Row 0.
  Mprev[0] = 0; Xprev[0] = NEG; Yprev[0] = NEG;
  for (let j = 1; j <= n; j++) {
    Mprev[j] = NEG;
    Xprev[j] = NEG;
    Yprev[j] = (go + ge * j) * tf;
    tbY[j] = j === 1 ? 0 : 2;
  }

  for (let i = 1; i <= m; i++) {
    const lo = banded ? Math.max(0, Math.floor(i * n / m) - band) : 0;
    const hi = banded ? Math.min(n, Math.floor(i * n / m) + band) : n;
    const base = i * width;

    M[0] = NEG;
    X[0] = (go + ge * i) * tf;
    Y[0] = NEG;
    tbX[base] = i === 1 ? 0 : 1;
    for (let j = 1; j < lo; j++) { M[j] = NEG; X[j] = NEG; Y[j] = NEG; }

    for (let j = Math.max(1, lo); j <= hi; j++) {
      const pairScore = profileScore(P, i - 1, Q, j - 1, S);

      // M: both profiles advance.
      let best = Mprev[j - 1]; let from = 0;
      if (Xprev[j - 1] > best) { best = Xprev[j - 1]; from = 1; }
      if (Yprev[j - 1] > best) { best = Yprev[j - 1]; from = 2; }
      M[j] = best + pairScore;
      tbM[base + j] = from;

      // X: gap in Q, P advances. Terminal columns are discounted.
      const xTerm = (j === 0 || j === n) ? tf : 1;
      const openX = Mprev[j] + (go + ge) * xTerm * gapWeight(Q, j - 1);
      const extX = Xprev[j] + ge * xTerm * gapWeight(Q, j - 1);
      if (openX >= extX) { X[j] = openX; tbX[base + j] = 0; }
      else { X[j] = extX; tbX[base + j] = 1; }

      // Y: gap in P, Q advances.
      const yTerm = (i === 0 || i === m) ? tf : 1;
      const openY = M[j - 1] + (go + ge) * yTerm * gapWeight(P, i - 1);
      const extY = Y[j - 1] + ge * yTerm * gapWeight(P, i - 1);
      if (openY >= extY) { Y[j] = openY; tbY[base + j] = 0; }
      else { Y[j] = extY; tbY[base + j] = 2; }
    }
    for (let j = hi + 1; j <= n; j++) { M[j] = NEG; X[j] = NEG; Y[j] = NEG; }

    Mprev.set(M); Xprev.set(X); Yprev.set(Y);
  }

  // Traceback from the best of the three layers at (m, n).
  let layer = 0;
  let best = Mprev[n];
  if (Xprev[n] > best) { best = Xprev[n]; layer = 1; }
  if (Yprev[n] > best) { best = Yprev[n]; layer = 2; }

  const ops = [];
  let i = m; let j = n;
  while (i > 0 || j > 0) {
    if (i === 0) { ops.push(2); j--; continue; }
    if (j === 0) { ops.push(1); i--; continue; }
    const idx = i * width + j;
    if (layer === 0) {
      const from = tbM[idx];
      ops.push(0); i--; j--; layer = from;
    } else if (layer === 1) {
      const from = tbX[idx];
      ops.push(1); i--; layer = from === 0 ? 0 : 1;
    } else {
      const from = tbY[idx];
      ops.push(2); j--; layer = from === 0 ? 0 : 2;
    }
  }
  ops.reverse();

  return { ops, score: best };
}

/** Expected substitution score between profile columns, gaps contributing 0. */
function profileScore(P, ci, Q, cj, S) {
  const pf = P.freq; const qf = Q.freq;
  const pi = ci * 4; const qi = cj * 4;
  let s = 0;
  for (let a = 0; a < 4; a++) {
    const fa = pf[pi + a];
    if (fa === 0) continue;
    for (let b = 0; b < 4; b++) {
      const fb = qf[qi + b];
      if (fb === 0) continue;
      s += fa * fb * S[a * 4 + b];
    }
  }
  return s;
}

/** Gap penalties are scaled by how many rows actually carry a residue there. */
function gapWeight(profile, col) {
  if (col < 0 || col >= profile.len) return 1;
  return profile.residue[col];
}

/** Apply a traceback op list to two profiles, producing the merged rows. */
function mergeProfiles(P, Q, ops) {
  const rows = [];
  const total = ops.length;
  for (let r = 0; r < P.nRows; r++) {
    const src = P.rows[r];
    const out = new Array(total);
    let p = 0;
    for (let k = 0; k < total; k++) out[k] = ops[k] === 2 ? '-' : src[p++];
    rows.push(out.join(''));
  }
  for (let r = 0; r < Q.nRows; r++) {
    const src = Q.rows[r];
    const out = new Array(total);
    let q = 0;
    for (let k = 0; k < total; k++) out[k] = ops[k] === 1 ? '-' : src[q++];
    rows.push(out.join(''));
  }
  return makeProfile([...P.indices, ...Q.indices], rows);
}

// ---------------------------------------------------------------------------
// Sum-of-pairs score (used for refinement acceptance and quality reporting)
// ---------------------------------------------------------------------------

/**
 * Sum-of-pairs score of an alignment under the same affine model used to build
 * it. Reported alongside the alignment so that alternative parameterisations,
 * or alignments produced by other programs, can be scored on equal terms.
 */
export function sumOfPairsScore(rows, options = {}) {
  const opts = { ...DEFAULT_ALIGN_OPTIONS, ...options };
  const S = scoreMatrix(opts);
  const n = rows.length;
  const len = rows[0].length;
  let total = 0;
  for (let a = 0; a < n; a++) {
    for (let b = a + 1; b < n; b++) {
      const x = rows[a]; const y = rows[b];
      let inGap = false;
      for (let c = 0; c < len; c++) {
        const cx = x[c]; const cy = y[c];
        const gx = cx === '-'; const gy = cy === '-';
        if (gx && gy) { continue; }
        if (gx || gy) {
          total += inGap ? opts.gapExtend : opts.gapOpen + opts.gapExtend;
          inGap = true;
          continue;
        }
        inGap = false;
        const ca = CODE[cx]; const cb = CODE[cy];
        if (ca !== undefined && cb !== undefined) total += S[ca * 4 + cb];
      }
    }
  }
  return total;
}

// ---------------------------------------------------------------------------
// Public entry point
// ---------------------------------------------------------------------------

/**
 * Align a set of sequences.
 *
 * @param {string[]} names
 * @param {string[]} seqs  unaligned (or already aligned) sequences
 * @param {object} options see DEFAULT_ALIGN_OPTIONS
 * @param {function} onProgress optional callback (fraction, message)
 * @returns {{names, seqs, length, guideTree, spScore, refinements, elapsedMs}}
 */
export function align(names, seqs, options = {}, onProgress = null) {
  const opts = { ...DEFAULT_ALIGN_OPTIONS, ...options };
  const t0 = now();
  const n = seqs.length;
  if (n === 0) return { names: [], seqs: [], length: 0, guideTree: null, spScore: 0, refinements: 0, elapsedMs: 0 };
  if (n === 1) {
    return { names: names.slice(), seqs: seqs.slice(), length: seqs[0].length, guideTree: null, spScore: 0, refinements: 0, elapsedMs: now() - t0 };
  }

  const S = scoreMatrix(opts);
  const clean = seqs.map((s) => s.replace(/-/g, ''));

  report(onProgress, 0.05, 'Computing k-mer distances');
  const kd = kmerDistanceMatrix(clean, opts.kmer);

  report(onProgress, 0.15, 'Building guide tree');
  const labels = clean.map((_, i) => String(i));
  const guide = upgma(labels, kd);

  report(onProgress, 0.2, 'Progressive alignment');
  const profileOf = new Map();
  const order = postorder(guide);
  let done = 0;
  for (const node of order) {
    if (isLeaf(node)) {
      const idx = Number(node.name);
      profileOf.set(node, makeProfile([idx], [clean[idx]]));
      continue;
    }
    let acc = null;
    for (const child of node.children) {
      const p = profileOf.get(child);
      if (!p) continue;
      if (!acc) { acc = p; continue; }
      const { ops } = alignProfiles(acc, p, opts, S);
      acc = mergeProfiles(acc, p, ops);
    }
    profileOf.set(node, acc);
    done++;
    report(onProgress, 0.2 + 0.5 * (done / Math.max(1, n - 1)), 'Progressive alignment');
  }

  let root = profileOf.get(guide);
  let refinements = 0;

  if (opts.refineRounds > 0 && n > 2) {
    report(onProgress, 0.75, 'Iterative refinement');
    const result = refine(root, guide, opts, S, onProgress);
    root = result.profile;
    refinements = result.accepted;
  }

  // Restore original input order.
  const outSeqs = new Array(n);
  root.indices.forEach((origIdx, row) => { outSeqs[origIdx] = root.rows[row]; });
  for (let i = 0; i < n; i++) if (!outSeqs[i]) outSeqs[i] = '-'.repeat(root.len);

  return {
    names: names.slice(),
    seqs: outSeqs,
    length: root.len,
    guideTree: guide,
    spScore: sumOfPairsScore(outSeqs, opts),
    refinements,
    options: {
      match: opts.match, mismatch: opts.mismatch, transitionBonus: opts.transitionBonus,
      gapOpen: opts.gapOpen, gapExtend: opts.gapExtend, kmer: opts.kmer,
      refineRounds: opts.refineRounds,
    },
    elapsedMs: now() - t0,
  };
}

/**
 * Tree-dependent iterative refinement.
 *
 * Each internal branch of the guide tree defines a bipartition of the taxa.
 * The alignment is split along it, all-gap columns are dropped from each half,
 * the two halves are realigned as profiles, and the result replaces the current
 * alignment only if the sum-of-pairs score strictly improves.
 */
function refine(profile, guide, opts, S, onProgress) {
  let current = profile;
  let currentScore = sumOfPairsScore(current.rows, opts);
  let accepted = 0;

  const internal = postorder(guide).filter((nd) => !isLeaf(nd) && nd.parent);
  for (let round = 0; round < opts.refineRounds; round++) {
    let improvedThisRound = false;
    for (let b = 0; b < internal.length; b++) {
      const groupNames = new Set(collectLeafNames(internal[b]));
      const groupA = [];
      const groupB = [];
      current.indices.forEach((origIdx, row) => {
        (groupNames.has(String(origIdx)) ? groupA : groupB).push(row);
      });
      if (!groupA.length || !groupB.length) continue;

      const PA = stripAllGapColumns(groupA.map((r) => current.rows[r]), groupA.map((r) => current.indices[r]));
      const PB = stripAllGapColumns(groupB.map((r) => current.rows[r]), groupB.map((r) => current.indices[r]));
      if (!PA.len || !PB.len) continue;

      const { ops } = alignProfiles(PA, PB, opts, S);
      const merged = mergeProfiles(PA, PB, ops);
      const score = sumOfPairsScore(merged.rows, opts);
      if (score > currentScore + 1e-9) {
        current = merged;
        currentScore = score;
        accepted++;
        improvedThisRound = true;
      }
      report(onProgress, 0.75 + 0.2 * ((round * internal.length + b) / (opts.refineRounds * Math.max(1, internal.length))), 'Iterative refinement');
    }
    if (!improvedThisRound) break;
  }
  return { profile: current, accepted };
}

function collectLeafNames(node) {
  const out = [];
  const stack = [node];
  while (stack.length) {
    const n = stack.pop();
    if (isLeaf(n)) out.push(n.name);
    else stack.push(...n.children);
  }
  return out;
}

function stripAllGapColumns(rows, indices) {
  const len = rows[0].length;
  const keep = [];
  for (let c = 0; c < len; c++) {
    let any = false;
    for (let r = 0; r < rows.length; r++) if (rows[r][c] !== '-') { any = true; break; }
    if (any) keep.push(c);
  }
  const out = rows.map((s) => {
    let acc = '';
    for (const c of keep) acc += s[c];
    return acc;
  });
  return makeProfile(indices, out.length && out[0].length ? out : rows);
}

function report(cb, fraction, message) {
  if (cb) cb(fraction, message);
}

function now() {
  return typeof performance !== 'undefined' ? performance.now() : Date.now();
}
