/**
 * Time-reversible nucleotide substitution models with rate heterogeneity.
 *
 * Supported base models (nested, in order of increasing generality):
 *   JC69  — equal frequencies, single rate                     (0 free params)
 *   F81   — empirical frequencies, single rate                 (3)
 *   K80   — equal frequencies, transition/transversion ratio   (1)
 *   HKY85 — empirical frequencies + kappa                      (3+1)
 *   TN93  — empirical frequencies + separate purine/pyrimidine
 *           transition rates                                   (3+2)
 *   GTR   — empirical frequencies + 5 free exchangeabilities    (3+5)
 *
 * Each may be combined with:
 *   +I  proportion of invariable sites          (1 param)
 *   +G  discrete-gamma rate heterogeneity, k categories, shape alpha (1 param)
 *
 * All models are of the general time-reversible form Q_ij = r_ij * pi_j, so the
 * matrix B = Pi^(1/2) Q Pi^(-1/2) is symmetric and can be diagonalised with a
 * cyclic Jacobi rotation. That gives P(t) = exp(Qt) in closed form:
 *
 *     P(t) = Pi^(-1/2) U exp(Lambda t) U^T Pi^(1/2)
 *
 * Q is scaled so that the expected number of substitutions per site per unit
 * branch length is 1, which makes branch lengths comparable across models.
 */

export const MODEL_NAMES = ['JC69', 'F81', 'K80', 'HKY85', 'TN93', 'GTR'];

/** Number of free parameters of a base model, excluding branch lengths. */
export const MODEL_FREE_PARAMS = {
  JC69: 0, F81: 3, K80: 1, HKY85: 4, TN93: 5, GTR: 8,
};

/** Which of {kappa, kappa2, gtrRates, freqs} a model actually estimates. */
export const MODEL_SPEC = {
  JC69: { freqs: 'equal', rates: 'equal' },
  F81: { freqs: 'empirical', rates: 'equal' },
  K80: { freqs: 'equal', rates: 'kappa' },
  HKY85: { freqs: 'empirical', rates: 'kappa' },
  TN93: { freqs: 'empirical', rates: 'tn93' },
  GTR: { freqs: 'empirical', rates: 'gtr' },
};

/**
 * A fully specified evolutionary model, ready to hand branch lengths to.
 *
 * @param {object} opts
 * @param {string} opts.model     one of MODEL_NAMES
 * @param {number[]} opts.freqs   base frequencies [piA,piC,piG,piT]
 * @param {number} opts.kappa     transition/transversion ratio (or purine ti rate for TN93)
 * @param {number} opts.kappa2    pyrimidine transition rate (TN93 only)
 * @param {number[]} opts.gtrRates  [a,b,c,d,e] with f (G<->T) fixed at 1
 * @param {number} opts.alpha     gamma shape; Infinity or null disables +G
 * @param {number} opts.pinv      proportion of invariable sites
 * @param {number} opts.nCat      number of discrete gamma categories
 */
export class SubstitutionModel {
  constructor(opts = {}) {
    this.model = opts.model || 'HKY85';
    this.freqs = normaliseFreqs(
      MODEL_SPEC[this.model].freqs === 'equal' ? [0.25, 0.25, 0.25, 0.25] : (opts.freqs || [0.25, 0.25, 0.25, 0.25]),
    );
    this.kappa = opts.kappa ?? 2;
    this.kappa2 = opts.kappa2 ?? this.kappa;
    this.gtrRates = (opts.gtrRates || [1, 1, 1, 1, 1]).slice();
    this.alpha = opts.alpha ?? Infinity;
    this.pinv = opts.pinv ?? 0;
    this.nCat = opts.nCat ?? 4;
    this._build();
  }

  get usesGamma() { return Number.isFinite(this.alpha) && this.alpha > 0; }
  get usesInvariable() { return this.pinv > 0; }

  /** Human-readable model string, e.g. "TN93+I+G4". */
  get label() {
    let s = this.model;
    if (this.usesInvariable) s += '+I';
    if (this.usesGamma) s += `+G${this.nCat}`;
    return s;
  }

  /** Free parameters counted for AIC/BIC, excluding branch lengths. */
  get freeParams() {
    return MODEL_FREE_PARAMS[this.model] + (this.usesInvariable ? 1 : 0) + (this.usesGamma ? 1 : 0);
  }

  clone(overrides = {}) {
    return new SubstitutionModel({
      model: this.model,
      freqs: this.freqs.slice(),
      kappa: this.kappa,
      kappa2: this.kappa2,
      gtrRates: this.gtrRates.slice(),
      alpha: this.alpha,
      pinv: this.pinv,
      nCat: this.nCat,
      ...overrides,
    });
  }

  /** Recompute Q, its eigen-decomposition and the rate categories. */
  _build() {
    const pi = this.freqs;
    const R = this._exchangeabilities();

    // Q_ij = R_ij * pi_j, rows summing to zero.
    const Q = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]];
    for (let i = 0; i < 4; i++) {
      let rowSum = 0;
      for (let j = 0; j < 4; j++) {
        if (i === j) continue;
        Q[i][j] = R[i][j] * pi[j];
        rowSum += Q[i][j];
      }
      Q[i][i] = -rowSum;
    }

    // Scale to one expected substitution per site per unit time.
    let mu = 0;
    for (let i = 0; i < 4; i++) mu -= pi[i] * Q[i][i];
    this.scale = mu;
    if (mu > 0) for (let i = 0; i < 4; i++) for (let j = 0; j < 4; j++) Q[i][j] /= mu;
    this.Q = Q;

    // Symmetrise, diagonalise, keep the transform matrices.
    const sq = pi.map(Math.sqrt);
    const B = [[0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0], [0, 0, 0, 0]];
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 4; j++) B[i][j] = Q[i][j] * sq[i] / sq[j];
    }
    // Enforce exact symmetry against round-off before the Jacobi sweep.
    for (let i = 0; i < 4; i++) {
      for (let j = i + 1; j < 4; j++) {
        const m = 0.5 * (B[i][j] + B[j][i]);
        B[i][j] = m; B[j][i] = m;
      }
    }
    const { values, vectors } = jacobiEigen(B);
    this.eigenvalues = values;
    // Left/right transforms folded in so P(t) is three 4x4 products.
    this.U = vectors;                                   // columns are eigenvectors of B
    this.invSqrtPi = sq.map((s) => 1 / s);
    this.sqrtPi = sq;

    this._rateCategories();
    this._pCache = new Map();
  }

  _exchangeabilities() {
    const spec = MODEL_SPEC[this.model].rates;
    // Index order A=0, C=1, G=2, T=3. Transitions: A<->G, C<->T.
    const R = [[0, 1, 1, 1], [1, 0, 1, 1], [1, 1, 0, 1], [1, 1, 1, 0]];
    if (spec === 'equal') return R;
    if (spec === 'kappa') {
      R[0][2] = R[2][0] = this.kappa;
      R[1][3] = R[3][1] = this.kappa;
      return R;
    }
    if (spec === 'tn93') {
      R[0][2] = R[2][0] = this.kappa;   // purine transition
      R[1][3] = R[3][1] = this.kappa2;  // pyrimidine transition
      return R;
    }
    // GTR: [a=A-C, b=A-G, c=A-T, d=C-G, e=C-T], f=G-T fixed at 1.
    const [a, b, c, d, e] = this.gtrRates;
    R[0][1] = R[1][0] = a;
    R[0][2] = R[2][0] = b;
    R[0][3] = R[3][0] = c;
    R[1][2] = R[2][1] = d;
    R[1][3] = R[3][1] = e;
    R[2][3] = R[3][2] = 1;
    return R;
  }

  /**
   * Discrete-gamma rate categories (Yang 1994, mean of each equal-probability
   * bin) plus the invariable class. Rates for the variable classes are rescaled
   * by 1/(1-pinv) so the overall mean rate stays 1.
   */
  _rateCategories() {
    const k = this.usesGamma ? this.nCat : 1;
    let rates;
    if (this.usesGamma) {
      rates = discreteGammaRates(this.alpha, k);
    } else {
      rates = [1];
    }
    const scale = this.pinv < 1 ? 1 / (1 - this.pinv) : 1;
    this.rates = rates.map((r) => r * scale);
    this.catProbs = new Array(k).fill((1 - this.pinv) / k);
    this.invProb = this.pinv;
  }

  /**
   * Transition probability matrix P(t) = exp(Qt), as a flat length-16 array in
   * row-major order. Results are memoised on (t) because a likelihood sweep
   * asks for the same branch length once per rate category and per pattern.
   */
  P(t) {
    const key = t;
    const hit = this._pCache.get(key);
    if (hit) return hit;
    const out = new Float64Array(16);
    const lam = this.eigenvalues;
    const U = this.U;
    const expLam = [
      Math.exp(lam[0] * t), Math.exp(lam[1] * t),
      Math.exp(lam[2] * t), Math.exp(lam[3] * t),
    ];
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 4; j++) {
        let s = 0;
        for (let k = 0; k < 4; k++) s += U[i][k] * expLam[k] * U[j][k];
        // Undo the Pi^(1/2) symmetrisation.
        let v = s * this.invSqrtPi[i] * this.sqrtPi[j];
        if (v < 0) v = 0;
        out[i * 4 + j] = v;
      }
    }
    // Renormalise rows against accumulated round-off.
    for (let i = 0; i < 4; i++) {
      let rs = 0;
      for (let j = 0; j < 4; j++) rs += out[i * 4 + j];
      if (rs > 0) for (let j = 0; j < 4; j++) out[i * 4 + j] /= rs;
    }
    if (this._pCache.size > 4096) this._pCache.clear();
    this._pCache.set(key, out);
    return out;
  }

  /** Serialisable description for the run manifest. */
  describe() {
    const d = { model: this.model, label: this.label, freqs: this.freqs.map((f) => +f.toFixed(6)) };
    const spec = MODEL_SPEC[this.model].rates;
    if (spec === 'kappa') d.kappa = +this.kappa.toFixed(4);
    if (spec === 'tn93') { d.kappaPurine = +this.kappa.toFixed(4); d.kappaPyrimidine = +this.kappa2.toFixed(4); }
    if (spec === 'gtr') d.gtrRates = this.gtrRates.map((r) => +r.toFixed(4)).concat([1]);
    if (this.usesGamma) { d.alpha = +this.alpha.toFixed(4); d.gammaCategories = this.nCat; }
    if (this.usesInvariable) d.pinv = +this.pinv.toFixed(4);
    d.freeParameters = this.freeParams;
    return d;
  }
}

function normaliseFreqs(f) {
  const clipped = f.map((x) => Math.max(x, 1e-6));
  const sum = clipped.reduce((a, b) => a + b, 0);
  return clipped.map((x) => x / sum);
}

// ---------------------------------------------------------------------------
// Symmetric eigen-decomposition (cyclic Jacobi)
// ---------------------------------------------------------------------------

/**
 * Diagonalise a symmetric 4x4 matrix. Returns eigenvalues and a matrix whose
 * COLUMNS are the corresponding orthonormal eigenvectors.
 */
export function jacobiEigen(matrix, maxSweeps = 100) {
  const n = matrix.length;
  const a = matrix.map((row) => row.slice());
  const v = Array.from({ length: n }, (_, i) =>
    Array.from({ length: n }, (_, j) => (i === j ? 1 : 0)));

  for (let sweep = 0; sweep < maxSweeps; sweep++) {
    let off = 0;
    for (let i = 0; i < n; i++) for (let j = i + 1; j < n; j++) off += a[i][j] * a[i][j];
    if (off < 1e-24) break;
    for (let p = 0; p < n - 1; p++) {
      for (let q = p + 1; q < n; q++) {
        if (Math.abs(a[p][q]) < 1e-30) continue;
        const theta = (a[q][q] - a[p][p]) / (2 * a[p][q]);
        const t = Math.sign(theta || 1) / (Math.abs(theta) + Math.sqrt(theta * theta + 1));
        const c = 1 / Math.sqrt(t * t + 1);
        const s = t * c;
        for (let k = 0; k < n; k++) {
          const akp = a[k][p]; const akq = a[k][q];
          a[k][p] = c * akp - s * akq;
          a[k][q] = s * akp + c * akq;
        }
        for (let k = 0; k < n; k++) {
          const apk = a[p][k]; const aqk = a[q][k];
          a[p][k] = c * apk - s * aqk;
          a[q][k] = s * apk + c * aqk;
        }
        for (let k = 0; k < n; k++) {
          const vkp = v[k][p]; const vkq = v[k][q];
          v[k][p] = c * vkp - s * vkq;
          v[k][q] = s * vkp + c * vkq;
        }
      }
    }
  }
  return { values: Array.from({ length: n }, (_, i) => a[i][i]), vectors: v };
}

// ---------------------------------------------------------------------------
// Discrete gamma (Yang 1994) and the special functions it needs
// ---------------------------------------------------------------------------

/**
 * Mean rate of each of k equal-probability categories of a Gamma(alpha, alpha)
 * distribution, normalised to mean 1. This is the standard "mean" (as opposed
 * to "median") discretisation used by PAML, PhyML, MEGA and IQ-TREE, so the
 * alpha values PhyloQuick reports are directly comparable to theirs.
 */
export function discreteGammaRates(alpha, k) {
  if (!Number.isFinite(alpha) || alpha <= 0) return new Array(k).fill(1);
  if (k === 1) return [1];
  const a = alpha;
  const cut = new Array(k - 1);
  for (let i = 0; i < k - 1; i++) cut[i] = pointGamma((i + 1) / k, a, a);
  const cum = new Array(k - 1);
  for (let i = 0; i < k - 1; i++) cum[i] = incompleteGamma(cut[i] * a, a + 1);
  const rates = new Array(k);
  rates[0] = cum[0] * k;
  rates[k - 1] = (1 - cum[k - 2]) * k;
  for (let i = 1; i < k - 1; i++) rates[i] = (cum[i] - cum[i - 1]) * k;
  return rates;
}

/** log Gamma(x), Lanczos approximation. */
export function lnGamma(x) {
  const g = [76.18009172947146, -86.50532032941677, 24.01409824083091,
    -1.231739572450155, 0.1208650973866179e-2, -0.5395239384953e-5];
  let y = x;
  let tmp = x + 5.5;
  tmp -= (x + 0.5) * Math.log(tmp);
  let ser = 1.000000000190015;
  for (let j = 0; j < 6; j++) ser += g[j] / ++y;
  return -tmp + Math.log(2.5066282746310005 * ser / x);
}

/** Regularised lower incomplete gamma P(a, x). */
export function incompleteGamma(x, a) {
  if (x <= 0) return 0;
  const lga = lnGamma(a);
  if (x < a + 1) {
    // Series expansion.
    let ap = a;
    let sum = 1 / a;
    let del = sum;
    for (let n = 1; n <= 500; n++) {
      ap += 1;
      del *= x / ap;
      sum += del;
      if (Math.abs(del) < Math.abs(sum) * 1e-14) break;
    }
    return sum * Math.exp(-x + a * Math.log(x) - lga);
  }
  // Continued fraction for Q(a,x), returned as 1 - Q.
  let b = x + 1 - a;
  let c = 1e300;
  let d = 1 / b;
  let h = d;
  for (let i = 1; i <= 500; i++) {
    const an = -i * (i - a);
    b += 2;
    d = an * d + b;
    if (Math.abs(d) < 1e-300) d = 1e-300;
    c = b + an / c;
    if (Math.abs(c) < 1e-300) c = 1e-300;
    d = 1 / d;
    const del = d * c;
    h *= del;
    if (Math.abs(del - 1) < 1e-14) break;
  }
  return 1 - Math.exp(-x + a * Math.log(x) - lga) * h;
}

/** Standard normal quantile (Odeh & Evans rational approximation). */
export function pointNormal(prob) {
  return pointNormalQ(prob);
}

/** Chi-square quantile with v degrees of freedom (PAML's PointChi2). */
export function pointChi2(prob, v) {
  const e = 0.5e-6;
  const aa = 0.6931471805;
  let ch;
  const g = lnGamma(v / 2);
  const xx = v / 2;
  const c = xx - 1;
  if (v <= 0) return -1;

  if (v < -1.24 * Math.log(prob)) {
    ch = Math.pow(prob * xx * Math.exp(g + xx * aa), 1 / xx);
    if (ch - e < 0) return ch;
  } else if (v > 0.32) {
    const x = pointNormalQ(prob);
    const p1 = 0.222222 / v;
    ch = v * Math.pow(x * Math.sqrt(p1) + 1 - p1, 3);
    if (ch > 2.2 * v + 6) ch = -2 * (Math.log(1 - prob) - c * Math.log(0.5 * ch) + g);
  } else {
    ch = 0.4;
    const q0 = -Math.log(prob);
    for (;;) {
      const q = ch;
      const p1 = 1 + ch * (4.67 + ch);
      const p2 = ch * (6.73 + ch * (6.66 + ch));
      let t = -0.5 + (4.67 + 2 * ch) / p1 - (6.73 + ch * (13.32 + 3 * ch)) / p2;
      ch -= (1 - Math.exp(q0 + g + 0.5 * ch + c * aa) * p2 / p1) / t;
      if (Math.abs(q / ch - 1) - 0.01 <= 0) break;
    }
  }

  for (let i = 0; i < 200; i++) {
    const q = ch;
    const p1 = 0.5 * ch;
    const p2 = prob - incompleteGamma(p1, xx);
    const t = p2 * Math.exp(xx * aa + g + p1 - c * Math.log(ch));
    const b = t / ch;
    const a2 = 0.5 * t - b * c;
    const s1 = (210 + a2 * (140 + a2 * (105 + a2 * (84 + a2 * (70 + 60 * a2))))) / 420;
    const s2 = (420 + a2 * (735 + a2 * (966 + a2 * (1141 + 1278 * a2)))) / 2520;
    const s3 = (210 + a2 * (462 + a2 * (707 + 932 * a2))) / 2520;
    const s4 = (252 + a2 * (672 + 1182 * a2) + c * (294 + a2 * (889 + 1740 * a2))) / 5040;
    const s5 = (84 + 264 * a2 + c * (175 + 606 * a2)) / 2520;
    const s6 = (120 + c * (346 + 127 * c)) / 5040;
    ch += t * (1 + 0.5 * t * s1 - b * c * (s1 - b * (s2 - b * (s3 - b * (s4 - b * (s5 - b * s6))))));
    if (Math.abs(q / ch - 1) <= e) break;
  }
  return ch;
}

/** Gamma(alpha, beta) quantile. */
export function pointGamma(prob, alpha, beta) {
  return pointChi2(prob, 2 * alpha) / (2 * beta);
}

/** Standard normal quantile, Odeh & Evans style; used by pointChi2. */
function pointNormalQ(prob) {
  const a0 = -0.322232431088, a1 = -1, a2 = -0.342242088547, a3 = -0.0204231210245, a4 = -0.453642210148e-4;
  const b0 = 0.0993484626060, b1 = 0.588581570495, b2 = 0.531103462366, b3 = 0.103537752850, b4 = 0.38560700634e-2;
  let p = prob;
  if (p > 0.5) p = 1 - p;
  if (p < 1e-20) return -40;
  const y = Math.sqrt(-2 * Math.log(p));
  let z = y + ((((y * a4 + a3) * y + a2) * y + a1) * y + a0)
    / ((((y * b4 + b3) * y + b2) * y + b1) * y + b0);
  return prob < 0.5 ? -z : z;
}
