/**
 * Figure rendering: phylogenetic trees, haplotype networks, distance heatmaps
 * and the mismatch-distribution chart.
 *
 * Trees and networks are drawn as SVG, so exporting a figure serialises the
 * same element that is shown on screen. The heatmap uses a canvas because an
 * n x n grid of SVG rectangles becomes slow at a few hundred taxa.
 *
 * Figures use a white background and dark ink regardless of the interface
 * theme.
 */

import { postorder, isLeaf } from '../engine/tree.js';

const SVG_NS = 'http://www.w3.org/2000/svg';
const INK = '#1a2433';
const MUTED = '#6b7c93';

function el(name, attrs = {}, text = null) {
  const node = document.createElementNS(SVG_NS, name);
  for (const [k, v] of Object.entries(attrs)) {
    if (v !== null && v !== undefined) node.setAttribute(k, String(v));
  }
  if (text !== null) node.textContent = text;
  return node;
}

// ---------------------------------------------------------------------------
// Trees
// ---------------------------------------------------------------------------

/**
 * @param {object} root       tree root (node objects with parent links)
 * @param {object} opts
 * @param {string} opts.layout      rectangular | slanted | circular
 * @param {number} opts.width       drawing width in px
 * @param {number} opts.fontSize
 * @param {boolean} opts.showSupport
 * @param {boolean} opts.showLengths
 * @param {number} opts.supportCutoff  hide support labels below this value
 */
export function renderTree(root, opts = {}) {
  const layout = opts.layout || 'rectangular';
  const fontSize = opts.fontSize ?? 12;
  const rowHeight = Math.max(16, fontSize + 6);
  const showSupport = opts.showSupport !== false;
  const showLengths = !!opts.showLengths;
  const cutoff = opts.supportCutoff ?? 0;

  const nodes = postorder(root);
  const tips = nodes.filter(isLeaf);
  if (!tips.length) return el('svg');

  // Cumulative distance from the root, and tip ordering.
  const depth = new Map([[root, 0]]);
  for (const node of nodes.slice().reverse()) {
    for (const child of node.children) depth.set(child, depth.get(node) + Math.max(child.length, 0));
  }
  const order = [];
  (function walk(n) {
    if (isLeaf(n)) { order.push(n); return; }
    for (const c of n.children) walk(c);
  })(root);

  const maxDepth = Math.max(...order.map((t) => depth.get(t)), 1e-9);
  const labelWidth = Math.max(...order.map((t) => t.name.length)) * fontSize * 0.58 + 16;

  if (layout === 'circular') {
    return renderCircular(root, { nodes, order, depth, maxDepth, fontSize, showSupport, cutoff, labelWidth, size: opts.width ?? 900 });
  }

  const plotWidth = Math.max(240, (opts.width ?? 900) - labelWidth - 60);
  const top = 24;
  const height = top + order.length * rowHeight + 56;
  const width = plotWidth + labelWidth + 60;

  const y = new Map();
  order.forEach((t, i) => y.set(t, top + i * rowHeight + rowHeight / 2));
  for (const node of nodes) {
    if (isLeaf(node)) continue;
    const ys = node.children.map((c) => y.get(c));
    y.set(node, (Math.min(...ys) + Math.max(...ys)) / 2);
  }
  const x = (n) => 30 + (depth.get(n) / maxDepth) * plotWidth;

  const svg = el('svg', {
    xmlns: SVG_NS, width, height, viewBox: `0 0 ${width} ${height}`,
    'font-family': 'system-ui, sans-serif',
  });
  svg.appendChild(el('rect', { x: 0, y: 0, width, height, fill: '#ffffff' }));

  const branches = el('g', { fill: 'none', stroke: INK, 'stroke-width': 1.3, 'stroke-linecap': 'round' });
  const labels = el('g', { fill: INK, 'font-size': fontSize });
  const supports = el('g', { fill: MUTED, 'font-size': Math.max(8, fontSize - 3), 'text-anchor': 'middle' });
  const lengths = el('g', { fill: MUTED, 'font-size': Math.max(7, fontSize - 4), 'text-anchor': 'middle' });

  for (const node of nodes) {
    for (const child of node.children) {
      const x1 = x(node); const x2 = x(child);
      const y1 = y.get(node); const y2 = y.get(child);
      if (layout === 'slanted') {
        branches.appendChild(el('path', { d: `M${x1},${y1} L${x2},${y2}` }));
      } else {
        branches.appendChild(el('path', { d: `M${x1},${y1} L${x1},${y2} L${x2},${y2}` }));
      }
      if (showLengths && child.length > 0) {
        lengths.appendChild(el('text', { x: (x1 + x2) / 2, y: y2 - 3 }, formatLength(child.length)));
      }
    }
  }

  for (const tip of order) {
    labels.appendChild(el('text', { x: x(tip) + 6, y: y.get(tip) + fontSize * 0.35 }, tip.name));
    // Dotted guide from the branch tip to the label when the branch is short.
    if (x(tip) < 30 + plotWidth - 4) {
      branches.appendChild(el('path', {
        d: `M${x(tip)},${y.get(tip)} L${30 + plotWidth},${y.get(tip)}`,
        stroke: '#d5dde7', 'stroke-width': 0.8, 'stroke-dasharray': '2 3',
      }));
      labels.lastChild.setAttribute('x', 30 + plotWidth + 6);
    }
  }

  if (showSupport) {
    for (const node of nodes) {
      if (isLeaf(node) || node === root) continue;
      const text = supportLabel(node, cutoff);
      if (!text) continue;
      supports.appendChild(el('text', { x: x(node) - 3, y: y.get(node) - 4, 'text-anchor': 'end' }, text));
    }
  }

  svg.appendChild(branches);
  svg.appendChild(supports);
  svg.appendChild(lengths);
  svg.appendChild(labels);
  svg.appendChild(scaleBar(maxDepth, plotWidth, 30, height - 26, fontSize));
  return svg;
}

function renderCircular(root, ctx) {
  const { nodes, order, depth, maxDepth, fontSize, showSupport, cutoff, labelWidth, size } = ctx;
  const dim = Math.max(420, size);
  const cx = dim / 2; const cy = dim / 2;
  const radius = dim / 2 - labelWidth - 20;
  const angleOf = new Map();
  order.forEach((t, i) => angleOf.set(t, (i / order.length) * 2 * Math.PI - Math.PI / 2));
  for (const node of nodes) {
    if (isLeaf(node)) continue;
    const as = node.children.map((c) => angleOf.get(c));
    angleOf.set(node, (Math.min(...as) + Math.max(...as)) / 2);
  }
  const rOf = (n) => 12 + (depth.get(n) / maxDepth) * radius;

  const svg = el('svg', {
    xmlns: SVG_NS, width: dim, height: dim, viewBox: `0 0 ${dim} ${dim}`,
    'font-family': 'system-ui, sans-serif',
  });
  svg.appendChild(el('rect', { x: 0, y: 0, width: dim, height: dim, fill: '#ffffff' }));
  const branches = el('g', { fill: 'none', stroke: INK, 'stroke-width': 1.2 });
  const labels = el('g', { fill: INK, 'font-size': fontSize });
  const supports = el('g', { fill: MUTED, 'font-size': Math.max(8, fontSize - 3) });

  const pt = (r, a) => [cx + r * Math.cos(a), cy + r * Math.sin(a)];

  for (const node of nodes) {
    for (const child of node.children) {
      const r1 = rOf(node); const r2 = rOf(child);
      const a1 = angleOf.get(node); const a2 = angleOf.get(child);
      const [ax, ay] = pt(r1, a1);
      const [bx, by] = pt(r1, a2);
      const [dx, dy] = pt(r2, a2);
      const large = Math.abs(a2 - a1) > Math.PI ? 1 : 0;
      const sweep = a2 > a1 ? 1 : 0;
      branches.appendChild(el('path', { d: `M${ax},${ay} A${r1},${r1} 0 ${large} ${sweep} ${bx},${by} L${dx},${dy}` }));
    }
  }

  for (const tip of order) {
    const a = angleOf.get(tip);
    const [tx, ty] = pt(rOf(tip) + 6, a);
    const deg = (a * 180) / Math.PI;
    const flip = Math.cos(a) < 0;
    labels.appendChild(el('text', {
      x: tx, y: ty,
      transform: `rotate(${flip ? deg + 180 : deg} ${tx} ${ty})`,
      'text-anchor': flip ? 'end' : 'start',
      'dominant-baseline': 'middle',
    }, tip.name));
  }

  if (showSupport) {
    for (const node of nodes) {
      if (isLeaf(node) || node === root) continue;
      const text = supportLabel(node, cutoff);
      if (!text) continue;
      const [sx, sy] = pt(rOf(node) + 4, angleOf.get(node));
      supports.appendChild(el('text', { x: sx, y: sy, 'dominant-baseline': 'middle' }, text));
    }
  }

  svg.appendChild(branches);
  svg.appendChild(supports);
  svg.appendChild(labels);
  return svg;
}

function supportLabel(node, cutoff) {
  const parts = [];
  if (node.shalrt != null && node.shalrt >= cutoff) parts.push(node.shalrt.toFixed(0));
  if (node.support != null && node.support >= cutoff) parts.push(node.support.toFixed(0));
  return parts.join('/');
}

function scaleBar(maxDepth, plotWidth, x0, y0, fontSize) {
  const target = niceNumber(maxDepth / 4);
  const px = (target / maxDepth) * plotWidth;
  const g = el('g', { stroke: INK, fill: INK, 'font-size': Math.max(8, fontSize - 2) });
  g.appendChild(el('path', { d: `M${x0},${y0} L${x0 + px},${y0} M${x0},${y0 - 4} L${x0},${y0 + 4} M${x0 + px},${y0 - 4} L${x0 + px},${y0 + 4}`, fill: 'none', 'stroke-width': 1 }));
  g.appendChild(el('text', { x: x0 + px / 2, y: y0 + 16, 'text-anchor': 'middle', stroke: 'none' },
    `${formatLength(target)} substitutions/site`));
  return g;
}

function niceNumber(x) {
  if (!(x > 0)) return 0.01;
  const exp = Math.floor(Math.log10(x));
  const base = x / 10 ** exp;
  const nice = base < 1.5 ? 1 : base < 3.5 ? 2 : base < 7.5 ? 5 : 10;
  return nice * 10 ** exp;
}

function formatLength(x) {
  if (x === 0) return '0';
  if (x >= 0.01) return x.toFixed(3).replace(/0+$/, '').replace(/\.$/, '');
  return x.toExponential(1);
}

// ---------------------------------------------------------------------------
// Haplotype network
// ---------------------------------------------------------------------------

/**
 * Force-directed layout with edge lengths proportional to the number of
 * mutational steps, node areas proportional to haplotype frequency, and pie
 * slices showing the composition of each haplotype when group labels are
 * available. The layout is deterministic: node positions are initialised on a
 * circle in a fixed order and relaxed for a fixed number of iterations, so the
 * same data always produce the same picture.
 */
export function renderNetwork(network, opts = {}) {
  const width = opts.width ?? 900;
  const height = opts.height ?? 560;
  const showLabels = opts.showLabels !== false;
  const showTicks = opts.showTicks !== false;

  const nodes = network.nodes.map((n, i) => ({
    ...n,
    x: width / 2 + Math.cos((i / network.nodes.length) * 2 * Math.PI) * Math.min(width, height) * 0.32,
    y: height / 2 + Math.sin((i / network.nodes.length) * 2 * Math.PI) * Math.min(width, height) * 0.32,
    vx: 0, vy: 0,
  }));
  const edges = network.edges;
  const maxCount = Math.max(...nodes.map((n) => n.count), 1);
  const radiusOf = (n) => (n.inferred ? 3.5 : 7 + 13 * Math.sqrt(n.count / maxCount));

  const stepLength = 34;
  for (let iter = 0; iter < 420; iter++) {
    const cooling = 1 - iter / 420;
    for (const e of edges) {
      const a = nodes[e.source]; const b = nodes[e.target];
      const dx = b.x - a.x; const dy = b.y - a.y;
      const dist = Math.hypot(dx, dy) || 0.01;
      const target = stepLength * Math.max(1, e.steps);
      const force = (dist - target) * 0.06 * cooling;
      const fx = (dx / dist) * force; const fy = (dy / dist) * force;
      a.vx += fx; a.vy += fy; b.vx -= fx; b.vy -= fy;
    }
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        const a = nodes[i]; const b = nodes[j];
        const dx = b.x - a.x; const dy = b.y - a.y;
        const dist = Math.hypot(dx, dy) || 0.01;
        const minDist = radiusOf(a) + radiusOf(b) + 14;
        if (dist < minDist * 3) {
          const push = ((minDist * 3 - dist) / dist) * 0.35 * cooling;
          a.vx -= dx * push; a.vy -= dy * push;
          b.vx += dx * push; b.vy += dy * push;
        }
      }
    }
    for (const n of nodes) {
      n.x += Math.max(-12, Math.min(12, n.vx));
      n.y += Math.max(-12, Math.min(12, n.vy));
      n.vx *= 0.72; n.vy *= 0.72;
    }
  }

  // Fit to the viewport.
  const pad = 48;
  const xs = nodes.map((n) => n.x); const ys = nodes.map((n) => n.y);
  const minX = Math.min(...xs); const maxX = Math.max(...xs);
  const minY = Math.min(...ys); const maxY = Math.max(...ys);
  const sx = (width - 2 * pad) / Math.max(maxX - minX, 1);
  const sy = (height - 2 * pad) / Math.max(maxY - minY, 1);
  const scale = Math.min(sx, sy, 1.6);
  for (const n of nodes) {
    n.x = pad + (n.x - minX) * scale;
    n.y = pad + (n.y - minY) * scale;
  }

  const svg = el('svg', {
    xmlns: SVG_NS, width, height, viewBox: `0 0 ${width} ${height}`,
    'font-family': 'system-ui, sans-serif',
  });
  svg.appendChild(el('rect', { x: 0, y: 0, width, height, fill: '#ffffff' }));

  const edgeLayer = el('g', { stroke: '#8fa1b8', 'stroke-width': 1.4, fill: 'none' });
  const tickLayer = el('g', { stroke: '#5d6f88', 'stroke-width': 1.1 });
  for (const e of edges) {
    const a = nodes[e.source]; const b = nodes[e.target];
    edgeLayer.appendChild(el('line', { x1: a.x, y1: a.y, x2: b.x, y2: b.y }));
    if (showTicks && e.steps > 1 && e.steps <= 25) {
      const dx = b.x - a.x; const dy = b.y - a.y;
      const len = Math.hypot(dx, dy) || 1;
      const nx = -dy / len; const ny = dx / len;
      for (let k = 1; k < e.steps; k++) {
        const t = k / e.steps;
        const px = a.x + dx * t; const py = a.y + dy * t;
        tickLayer.appendChild(el('line', {
          x1: px - nx * 4, y1: py - ny * 4, x2: px + nx * 4, y2: py + ny * 4,
        }));
      }
    } else if (e.steps > 25) {
      const mx = (a.x + b.x) / 2; const my = (a.y + b.y) / 2;
      tickLayer.appendChild(el('text', { x: mx, y: my - 4, 'text-anchor': 'middle', 'font-size': 10, fill: '#5d6f88', stroke: 'none' }, String(e.steps)));
    }
  }
  svg.appendChild(edgeLayer);
  svg.appendChild(tickLayer);

  const nodeLayer = el('g', {});
  const labelLayer = el('g', { 'font-size': 11, fill: INK, 'text-anchor': 'middle' });
  const palette = ['#2563eb', '#e11d48', '#16a34a', '#d97706', '#7c3aed', '#0891b2', '#be123c', '#4d7c0f'];

  for (const n of nodes) {
    const r = radiusOf(n);
    if (n.inferred) {
      nodeLayer.appendChild(el('circle', { cx: n.x, cy: n.y, r, fill: '#ffffff', stroke: '#64748b', 'stroke-width': 1.2 }));
      continue;
    }
    const groups = n.groups && Object.keys(n.groups).length > 1 ? Object.entries(n.groups) : null;
    if (groups) {
      let start = -Math.PI / 2;
      const total = groups.reduce((a, [, v]) => a + v, 0);
      groups.forEach(([, v], gi) => {
        const angle = (v / total) * 2 * Math.PI;
        const end = start + angle;
        const x1 = n.x + r * Math.cos(start); const y1 = n.y + r * Math.sin(start);
        const x2 = n.x + r * Math.cos(end); const y2 = n.y + r * Math.sin(end);
        nodeLayer.appendChild(el('path', {
          d: `M${n.x},${n.y} L${x1},${y1} A${r},${r} 0 ${angle > Math.PI ? 1 : 0} 1 ${x2},${y2} Z`,
          fill: palette[gi % palette.length], stroke: '#ffffff', 'stroke-width': 0.8,
        }));
        start = end;
      });
      nodeLayer.appendChild(el('circle', { cx: n.x, cy: n.y, r, fill: 'none', stroke: INK, 'stroke-width': 1 }));
    } else {
      nodeLayer.appendChild(el('circle', {
        cx: n.x, cy: n.y, r, fill: palette[0], 'fill-opacity': 0.85, stroke: INK, 'stroke-width': 1,
      }));
    }
    if (showLabels) {
      labelLayer.appendChild(el('text', { x: n.x, y: n.y + r + 13 }, `${n.id} (${n.count})`));
    }
  }
  svg.appendChild(nodeLayer);
  svg.appendChild(labelLayer);
  return svg;
}

// ---------------------------------------------------------------------------
// Distance heatmap (canvas)
// ---------------------------------------------------------------------------

const PALETTES = {
  viridis: [[68, 1, 84], [59, 82, 139], [33, 145, 140], [94, 201, 98], [253, 231, 37]],
  magma: [[0, 0, 4], [81, 18, 124], [183, 55, 121], [252, 137, 97], [252, 253, 191]],
  blues: [[247, 251, 255], [198, 219, 239], [107, 174, 214], [33, 113, 181], [8, 48, 107]],
  grey: [[255, 255, 255], [200, 200, 200], [150, 150, 150], [90, 90, 90], [20, 20, 20]],
};

export function colourFor(value, max, paletteName = 'viridis') {
  const stops = PALETTES[paletteName] || PALETTES.viridis;
  const t = max > 0 ? Math.min(1, Math.max(0, value / max)) : 0;
  const pos = t * (stops.length - 1);
  const i = Math.min(stops.length - 2, Math.floor(pos));
  const f = pos - i;
  const c = stops[i].map((v, k) => Math.round(v + (stops[i + 1][k] - v) * f));
  return `rgb(${c[0]},${c[1]},${c[2]})`;
}

export function renderHeatmap(canvas, names, matrix, opts = {}) {
  const palette = opts.palette || 'viridis';
  const order = opts.order || names.map((_, i) => i);
  const n = order.length;
  const fontSize = 11;
  const cell = Math.max(6, Math.min(26, Math.floor(620 / Math.max(n, 1))));
  const measure = canvas.getContext('2d');
  measure.font = `${fontSize}px system-ui`;
  const labelWidth = Math.min(180, Math.max(...order.map((i) => measure.measureText(names[i]).width)) + 10);
  const legend = 54;

  const dpr = window.devicePixelRatio || 1;
  const width = labelWidth + n * cell + 24;
  const height = labelWidth + n * cell + 24 + legend;
  canvas.width = width * dpr;
  canvas.height = height * dpr;
  canvas.style.width = `${width}px`;
  canvas.style.height = `${height}px`;

  const ctx = canvas.getContext('2d');
  ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
  ctx.fillStyle = '#ffffff';
  ctx.fillRect(0, 0, width, height);

  let max = 0;
  for (const i of order) for (const j of order) if (matrix[i][j] > max) max = matrix[i][j];

  for (let a = 0; a < n; a++) {
    for (let b = 0; b < n; b++) {
      ctx.fillStyle = colourFor(matrix[order[a]][order[b]], max, palette);
      ctx.fillRect(labelWidth + b * cell, labelWidth + a * cell, cell, cell);
    }
  }

  ctx.fillStyle = INK;
  ctx.font = `${fontSize}px system-ui`;
  ctx.textBaseline = 'middle';
  if (cell >= 9) {
    ctx.textAlign = 'right';
    for (let a = 0; a < n; a++) {
      ctx.fillText(names[order[a]], labelWidth - 5, labelWidth + a * cell + cell / 2, labelWidth - 8);
    }
    ctx.save();
    ctx.textAlign = 'left';
    for (let b = 0; b < n; b++) {
      ctx.save();
      ctx.translate(labelWidth + b * cell + cell / 2, labelWidth - 5);
      ctx.rotate(-Math.PI / 2);
      ctx.fillText(names[order[b]], 0, 0, labelWidth - 8);
      ctx.restore();
    }
    ctx.restore();
  }

  // Legend.
  const lx = labelWidth;
  const ly = labelWidth + n * cell + 26;
  const lw = Math.min(260, n * cell);
  for (let i = 0; i < lw; i++) {
    ctx.fillStyle = colourFor((i / lw) * max, max, palette);
    ctx.fillRect(lx + i, ly, 1, 10);
  }
  ctx.strokeStyle = '#c9d3e0';
  ctx.strokeRect(lx, ly, lw, 10);
  ctx.fillStyle = MUTED;
  ctx.textAlign = 'left';
  ctx.fillText('0', lx, ly + 22);
  ctx.textAlign = 'right';
  ctx.fillText(max.toFixed(4), lx + lw, ly + 22);
  ctx.textAlign = 'center';
  ctx.fillText('pairwise distance (substitutions/site)', lx + lw / 2, ly + 36);

  return { cell, labelWidth, max, order };
}

// ---------------------------------------------------------------------------
// Mismatch distribution
// ---------------------------------------------------------------------------

export function renderMismatch(distribution, opts = {}) {
  const width = opts.width ?? 420;
  const height = opts.height ?? 240;
  const pad = { l: 44, r: 12, t: 14, b: 38 };
  const svg = el('svg', {
    xmlns: SVG_NS, width, height, viewBox: `0 0 ${width} ${height}`,
    'font-family': 'system-ui, sans-serif',
  });
  svg.appendChild(el('rect', { x: 0, y: 0, width, height, fill: '#ffffff' }));
  if (!distribution || !distribution.length) return svg;

  const maxFreq = Math.max(...distribution.map((d) => d.frequency), 0.0001);
  const plotW = width - pad.l - pad.r;
  const plotH = height - pad.t - pad.b;
  const barW = Math.max(1, plotW / distribution.length - 1.5);

  const axes = el('g', { stroke: '#c9d3e0', 'stroke-width': 1, fill: 'none' });
  axes.appendChild(el('path', { d: `M${pad.l},${pad.t} L${pad.l},${pad.t + plotH} L${pad.l + plotW},${pad.t + plotH}` }));
  svg.appendChild(axes);

  const bars = el('g', { fill: '#2563eb', 'fill-opacity': 0.8 });
  distribution.forEach((d, i) => {
    const h = (d.frequency / maxFreq) * plotH;
    bars.appendChild(el('rect', {
      x: pad.l + (i * plotW) / distribution.length + 0.75,
      y: pad.t + plotH - h, width: barW, height: h,
    }));
  });
  svg.appendChild(bars);

  const text = el('g', { fill: MUTED, 'font-size': 10 });
  text.appendChild(el('text', { x: pad.l + plotW / 2, y: height - 8, 'text-anchor': 'middle' }, 'pairwise differences'));
  text.appendChild(el('text', { x: 10, y: pad.t + plotH / 2, 'text-anchor': 'middle', transform: `rotate(-90 10 ${pad.t + plotH / 2})` }, 'frequency'));
  text.appendChild(el('text', { x: pad.l - 5, y: pad.t + 4, 'text-anchor': 'end' }, maxFreq.toFixed(2)));
  text.appendChild(el('text', { x: pad.l - 5, y: pad.t + plotH, 'text-anchor': 'end' }, '0'));
  const step = Math.max(1, Math.ceil(distribution.length / 8));
  for (let i = 0; i < distribution.length; i += step) {
    text.appendChild(el('text', {
      x: pad.l + (i * plotW) / distribution.length + barW / 2,
      y: pad.t + plotH + 13, 'text-anchor': 'middle',
    }, String(distribution[i].differences)));
  }
  svg.appendChild(text);
  return svg;
}

// ---------------------------------------------------------------------------
// Simple line chart, used by the benchmark panel
// ---------------------------------------------------------------------------

export function renderLineChart(series, opts = {}) {
  const width = opts.width ?? 560;
  const height = opts.height ?? 300;
  const pad = { l: 58, r: 130, t: 16, b: 44 };
  const logY = opts.logY !== false;
  const svg = el('svg', {
    xmlns: SVG_NS, width, height, viewBox: `0 0 ${width} ${height}`,
    'font-family': 'system-ui, sans-serif',
  });
  svg.appendChild(el('rect', { x: 0, y: 0, width, height, fill: '#ffffff' }));

  const allX = series.flatMap((s) => s.points.map((p) => p[0]));
  const allY = series.flatMap((s) => s.points.map((p) => p[1])).filter((v) => v > 0);
  if (!allX.length || !allY.length) return svg;
  const minX = Math.min(...allX); const maxX = Math.max(...allX);
  const minY = Math.min(...allY); const maxY = Math.max(...allY);
  const plotW = width - pad.l - pad.r;
  const plotH = height - pad.t - pad.b;
  const tx = (x) => pad.l + ((x - minX) / Math.max(maxX - minX, 1e-9)) * plotW;
  const ty = (y) => {
    if (!logY) return pad.t + plotH - ((y - 0) / Math.max(maxY, 1e-9)) * plotH;
    const a = Math.log10(Math.max(y, minY / 2));
    const lo = Math.log10(minY / 2); const hi = Math.log10(maxY * 1.6);
    return pad.t + plotH - ((a - lo) / (hi - lo)) * plotH;
  };

  const axes = el('g', { stroke: '#c9d3e0', 'stroke-width': 1, fill: 'none' });
  axes.appendChild(el('path', { d: `M${pad.l},${pad.t} L${pad.l},${pad.t + plotH} L${pad.l + plotW},${pad.t + plotH}` }));
  svg.appendChild(axes);

  const palette = ['#2563eb', '#e11d48', '#16a34a', '#d97706', '#7c3aed', '#0891b2'];
  series.forEach((s, si) => {
    const colour = palette[si % palette.length];
    const d = s.points.map((p, i) => `${i ? 'L' : 'M'}${tx(p[0])},${ty(p[1])}`).join(' ');
    svg.appendChild(el('path', { d, fill: 'none', stroke: colour, 'stroke-width': 1.8 }));
    for (const p of s.points) {
      svg.appendChild(el('circle', { cx: tx(p[0]), cy: ty(p[1]), r: 3, fill: colour }));
    }
    svg.appendChild(el('text', {
      x: pad.l + plotW + 10, y: pad.t + 12 + si * 16, 'font-size': 11, fill: colour,
    }, s.label));
  });

  const text = el('g', { fill: MUTED, 'font-size': 10 });
  for (const x of [minX, ...(maxX !== minX ? [maxX] : [])]) {
    text.appendChild(el('text', { x: tx(x), y: pad.t + plotH + 15, 'text-anchor': 'middle' }, String(x)));
  }
  text.appendChild(el('text', { x: pad.l + plotW / 2, y: height - 10, 'text-anchor': 'middle' }, opts.xLabel || 'taxa'));
  text.appendChild(el('text', { x: pad.l - 6, y: ty(minY), 'text-anchor': 'end' }, fmtMs(minY)));
  text.appendChild(el('text', { x: pad.l - 6, y: ty(maxY), 'text-anchor': 'end' }, fmtMs(maxY)));
  text.appendChild(el('text', {
    x: 12, y: pad.t + plotH / 2, 'text-anchor': 'middle',
    transform: `rotate(-90 12 ${pad.t + plotH / 2})`,
  }, opts.yLabel || (logY ? 'time (log scale)' : 'time')));
  svg.appendChild(text);
  return svg;
}

function fmtMs(ms) {
  if (ms >= 1000) return `${(ms / 1000).toFixed(1)} s`;
  return `${ms.toFixed(0)} ms`;
}

// ---------------------------------------------------------------------------
// Export helpers
// ---------------------------------------------------------------------------

export function svgToString(svg) {
  const clone = svg.cloneNode(true);
  clone.setAttribute('xmlns', SVG_NS);
  return '<?xml version="1.0" encoding="UTF-8"?>\n' + new XMLSerializer().serializeToString(clone);
}

/** Rasterise an SVG element to a PNG blob at the requested scale. */
export function svgToPng(svg, scale = 2) {
  return new Promise((resolve, reject) => {
    const width = Number(svg.getAttribute('width'));
    const height = Number(svg.getAttribute('height'));
    const blob = new Blob([svgToString(svg)], { type: 'image/svg+xml;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const img = new Image();
    img.onload = () => {
      const canvas = document.createElement('canvas');
      canvas.width = width * scale;
      canvas.height = height * scale;
      const ctx = canvas.getContext('2d');
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.drawImage(img, 0, 0, canvas.width, canvas.height);
      URL.revokeObjectURL(url);
      canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('PNG conversion failed'))), 'image/png');
    };
    img.onerror = () => { URL.revokeObjectURL(url); reject(new Error('PNG conversion failed')); };
    img.src = url;
  });
}
