/**
 * Analysis worker.
 *
 * Everything numerically expensive runs here so the interface never blocks.
 * The worker imports the same engine modules as the CLI, so a result obtained
 * in the desktop application is identical to one obtained from the terminal.
 *
 * Trees are sent back as Newick strings rather than as objects: the internal
 * node representation contains parent pointers, which are cyclic and cannot be
 * cloned across the worker boundary. The main thread re-parses them for drawing.
 */

import { runAnalysis } from '../engine/pipeline.js';
import { RNG } from '../engine/rng.js';
import { randomTree, simulateAlignment, randomModel, addIndels, alignmentAccuracy } from '../engine/simulate.js';
import { SubstitutionModel } from '../engine/models.js';
import { compressPatterns, toAlignment, baseFrequencies } from '../engine/seq.js';
import { distanceMatrix } from '../engine/distance.js';
import { buildTree } from '../engine/cluster.js';
import { maximumLikelihoodTree } from '../engine/likelihood.js';
import { robinsonFoulds, splitAccuracy, branchScoreDistance } from '../engine/treecmp.js';
import { writeNewick, parseNewick, unroot, relink, leafNames } from '../engine/tree.js';
import { align } from '../engine/align.js';
import { populationStatistics } from '../engine/popgen.js';

let cancelled = false;

self.onmessage = async (event) => {
  const { id, type, payload } = event.data;
  cancelled = false;
  try {
    let result;
    if (type === 'cancel') { cancelled = true; return; }
    if (type === 'analyse') result = await doAnalyse(id, payload);
    else if (type === 'simulate') result = await doSimulate(id, payload);
    else if (type === 'benchmark') result = await doBenchmark(id, payload);
    else if (type === 'compare') result = doCompare(payload);
    else throw new Error(`unknown request: ${type}`);
    self.postMessage({ id, ok: true, result });
  } catch (err) {
    self.postMessage({ id, ok: false, error: err.message, stack: err.stack });
  }
};

function progress(id, fraction, stage, detail) {
  self.postMessage({ id, progress: { fraction, stage, detail } });
}

// ---------------------------------------------------------------------------

async function doAnalyse(id, { text, options }) {
  const r = await runAnalysis(text, options, (f, stage, detail) => progress(id, f, stage, detail));
  return {
    manifest: r.manifest,
    warnings: r.warnings,
    summary: { ...r.summary, baseFrequencies: Array.from(r.summary.baseFrequencies) },
    options: r.options,
    alignment: { names: r.alignment.names, seqs: r.alignment.seqs, length: r.alignment.length },
    modelChosen: r.model.describe(),
    modelSelection: r.modelSelection ? {
      criterion: r.modelSelection.criterionUsed,
      chosen: r.modelSelection.chosen,
      bestAIC: r.modelSelection.bestAIC,
      bestAICc: r.modelSelection.bestAICc,
      bestBIC: r.modelSelection.bestBIC,
      results: r.modelSelection.results.map((m) => ({
        label: m.label, collapsed: m.collapsed, lnL: m.lnL,
        freeParameters: m.freeParameters, modelParameters: m.modelParameters,
        AIC: m.AIC, dAIC: m.dAIC, AICc: m.AICc, dAICc: m.dAICc,
        BIC: m.BIC, dBIC: m.dBIC, akaikeWeight: m.akaikeWeight,
        parameters: m.parameters,
      })),
    } : null,
    distances: {
      names: r.distances.names,
      matrix: r.distances.matrix.map((row) => Array.from(row)),
      model: r.distances.model,
      undefinedPairs: r.distances.undefinedPairs,
    },
    newick: r.newick,
    unrootedNewick: r.unrootedNewick,
    taxa: r.taxa,
    support: r.support,
    popgen: { ...r.popgen, siteStates: undefined },
    network: {
      type: r.network.type,
      meta: r.network.meta,
      positions: r.network.positions,
      edges: r.network.edges,
      nodes: r.network.nodes.map((n) => ({
        index: n.index,
        inferred: n.inferred,
        id: n.haplotype ? n.haplotype.id : `M${n.index}`,
        count: n.haplotype ? n.haplotype.count : 0,
        names: n.haplotype ? n.haplotype.names : [],
        groups: n.haplotype && n.haplotype.groups ? Object.fromEntries(n.haplotype.groups) : null,
      })),
      haplotypes: r.network.haplotypes.map((h) => ({
        id: h.id, count: h.count, names: h.names, seq: h.seq,
      })),
    },
  };
}

// ---------------------------------------------------------------------------

/**
 * Simulation-based accuracy test.
 *
 * For each replicate a random tree and a random parameterisation of the chosen
 * model are drawn, an alignment is simulated down that tree, and every requested
 * reconstruction method is scored against the true topology. Optionally the
 * sequences are also degraded with indels and realigned, so that alignment error
 * is included in the measured accuracy rather than assumed away.
 */
async function doSimulate(id, opts) {
  const {
    taxa = 20, sites = 1000, replicates = 20, meanBranch = 0.05,
    rateVariation = 0.5, model = 'GTR', methods = ['NJ', 'ML'], seed = 1,
    realign = false, indelRate = 0,
  } = opts;

  const rng = new RNG(seed);
  const rows = [];
  const perMethod = new Map(methods.map((m) => [m, []]));

  for (let rep = 0; rep < replicates; rep++) {
    if (cancelled) throw new Error('cancelled');
    progress(id, rep / replicates, 'simulate', `replicate ${rep + 1} of ${replicates}`);

    const trueTree = randomTree(taxa, { rng, meanBranch, rateVariation, shape: 'yule' });
    const genModel = randomModel(model, rng, { gamma: true, invariable: false });
    const sim = simulateAlignment(trueTree, genModel, sites, { rng });

    let aln = { names: sim.names, seqs: sim.seqs, length: sites };
    let alnAccuracy = null;
    if (realign && indelRate > 0) {
      const withIndels = addIndels(aln, { rng, rate: indelRate });
      const realigned = align(withIndels.unaligned.names, withIndels.unaligned.seqs, {});
      alnAccuracy = alignmentAccuracy(
        withIndels.trueAlignment,
        { names: realigned.names, seqs: realigned.seqs, length: realigned.length },
      );
      aln = { names: realigned.names, seqs: realigned.seqs, length: realigned.length };
    }

    const freqs = baseFrequencies(aln);
    const dm = distanceMatrix(aln, { model: 'TN93', freqs });
    const patterns = compressPatterns(aln);

    const row = { replicate: rep + 1, alignment: alnAccuracy, methods: {} };
    for (const method of methods) {
      const t0 = now();
      let estimated;
      if (method === 'ML') {
        const start = buildTree('NJ', dm.names, dm.matrix);
        const fitModel = new SubstitutionModel({ model, freqs, alpha: 0.5, nCat: 4 });
        estimated = maximumLikelihoodTree(patterns, fitModel, start, { search: true, optimiseModelParams: true }).tree;
      } else {
        estimated = buildTree(method, dm.names, dm.matrix);
      }
      const elapsed = now() - t0;
      const rf = robinsonFoulds(trueTree, estimated);
      const acc = splitAccuracy(trueTree, estimated);
      const bsd = branchScoreDistance(trueTree, estimated);
      const entry = {
        rf: rf.rf, normalisedRF: rf.normalised, recall: acc.recall,
        precision: acc.precision, branchScore: bsd, ms: elapsed,
      };
      row.methods[method] = entry;
      perMethod.get(method).push(entry);
    }
    rows.push(row);
  }

  const summary = {};
  for (const [method, entries] of perMethod) {
    summary[method] = {
      replicates: entries.length,
      meanRF: mean(entries.map((e) => e.rf)),
      meanNormalisedRF: mean(entries.map((e) => e.normalisedRF)),
      sdNormalisedRF: sd(entries.map((e) => e.normalisedRF)),
      meanRecall: mean(entries.map((e) => e.recall)),
      perfectReconstructions: entries.filter((e) => e.rf === 0).length,
      meanBranchScore: mean(entries.map((e) => e.branchScore)),
      meanMs: mean(entries.map((e) => e.ms)),
    };
  }

  const alignmentScores = rows.map((r) => r.alignment).filter(Boolean);
  return {
    settings: { taxa, sites, replicates, meanBranch, rateVariation, model, methods, seed, realign, indelRate },
    summary,
    alignment: alignmentScores.length ? {
      meanSP: mean(alignmentScores.map((a) => a.spScore)),
      meanTC: mean(alignmentScores.map((a) => a.tcScore)),
    } : null,
    rows,
  };
}

// ---------------------------------------------------------------------------

/**
 * Runtime scaling measurement. Each stage is timed separately so the reader can
 * see which one dominates, and the empirical scaling exponent is estimated by
 * regressing log(time) on log(n).
 */
async function doBenchmark(id, { sizes = [10, 25, 50, 100], sites = 1000, replicates = 100, seed = 1 }) {
  const rng = new RNG(seed);
  const rows = [];

  for (let i = 0; i < sizes.length; i++) {
    const n = sizes[i];
    if (cancelled) throw new Error('cancelled');
    progress(id, i / sizes.length, 'benchmark', `${n} taxa x ${sites} sites`);

    const tree = randomTree(n, { rng, meanBranch: 0.05, rateVariation: 0.4 });
    const model = new SubstitutionModel({ model: 'HKY85', freqs: [0.3, 0.2, 0.2, 0.3], kappa: 3, alpha: 0.5, nCat: 4 });
    const sim = simulateAlignment(tree, model, sites, { rng });
    const aln = toAlignment(sim.names.map((nm, k) => ({ name: nm, seq: sim.seqs[k] })));

    const timings = {};
    let t0 = now();
    const unaligned = { names: aln.names, seqs: aln.seqs.map((s) => s.replace(/-/g, '')) };
    align(unaligned.names, unaligned.seqs, { refineRounds: 1 });
    timings.alignment = now() - t0;

    t0 = now();
    const patterns = compressPatterns(aln);
    timings.patternCompression = now() - t0;

    t0 = now();
    const freqs = baseFrequencies(aln);
    const dm = distanceMatrix(aln, { model: 'TN93', freqs });
    timings.distances = now() - t0;

    t0 = now();
    const nj = buildTree('NJ', dm.names, dm.matrix);
    timings.neighborJoining = now() - t0;

    t0 = now();
    maximumLikelihoodTree(patterns, model, nj, { search: true, optimiseModelParams: false });
    timings.maximumLikelihood = now() - t0;

    t0 = now();
    if (replicates > 0) {
      const boot = new RNG(seed + 1);
      for (let b = 0; b < replicates; b++) {
        const cols = new Int32Array(aln.length);
        for (let s = 0; s < aln.length; s++) cols[s] = boot.int(aln.length);
        const seqs = aln.seqs.map((s) => { let o = ''; for (let k = 0; k < cols.length; k++) o += s[cols[k]]; return o; });
        const rdm = distanceMatrix({ names: aln.names, seqs, length: aln.length }, { model: 'TN93', freqs });
        buildTree('NJ', rdm.names, rdm.matrix);
      }
    }
    timings.bootstrap = now() - t0;

    t0 = now();
    populationStatistics(aln.seqs);
    timings.populationGenetics = now() - t0;

    rows.push({ taxa: n, sites, patterns: patterns.nPatterns, timings, total: sum(Object.values(timings)) });
  }

  return {
    settings: { sizes, sites, replicates, seed },
    rows,
    scaling: fitScaling(rows),
  };
}

/** Least-squares slope of log(time) on log(n): the empirical scaling exponent. */
function fitScaling(rows) {
  const stages = Object.keys(rows[0].timings);
  const out = {};
  for (const stage of [...stages, 'total']) {
    const pts = rows
      .map((r) => [Math.log(r.taxa), Math.log(stage === 'total' ? r.total : r.timings[stage])])
      .filter(([, y]) => Number.isFinite(y));
    if (pts.length < 2) { out[stage] = null; continue; }
    const mx = mean(pts.map((p) => p[0]));
    const my = mean(pts.map((p) => p[1]));
    let num = 0; let den = 0;
    for (const [x, y] of pts) { num += (x - mx) * (y - my); den += (x - mx) ** 2; }
    out[stage] = den ? num / den : null;
  }
  return out;
}

// ---------------------------------------------------------------------------

function doCompare({ newickA, newickB }) {
  const a = unroot(relink(parseNewick(newickA)));
  const b = unroot(relink(parseNewick(newickB)));
  const rf = robinsonFoulds(a, b);
  const acc = splitAccuracy(a, b);
  return {
    ...rf,
    recall: acc.recall,
    precision: acc.precision,
    branchScore: branchScoreDistance(a, b),
    taxaA: leafNames(a).length,
    taxaB: leafNames(b).length,
    newickA: writeNewick(a),
  };
}

// ---------------------------------------------------------------------------

function mean(xs) { return xs.length ? xs.reduce((a, b) => a + b, 0) / xs.length : 0; }
function sum(xs) { return xs.reduce((a, b) => a + b, 0); }
function sd(xs) {
  if (xs.length < 2) return 0;
  const m = mean(xs);
  return Math.sqrt(xs.reduce((a, x) => a + (x - m) ** 2, 0) / (xs.length - 1));
}
function now() { return typeof performance !== 'undefined' ? performance.now() : Date.now(); }
