/**
 * Interface controller.
 *
 * Collects parameters, passes them to the analysis worker and renders the
 * results. No analysis code lives here: the worker and the command-line tool
 * both call `runAnalysis`, so they produce the same output.
 */

import { EXAMPLES } from './examples.js';
import { HELP_HTML } from './help.js';
import {
  renderTree, renderNetwork, renderHeatmap, renderMismatch, renderLineChart,
  svgToString, svgToPng,
} from './figures.js';
import { parseNewick, relink, postorder, isLeaf, leafNames } from '../engine/tree.js';
import { toFasta, toPhylip, toNexus, consensus, toAlignment } from '../engine/seq.js';
import { toPhylipMatrix, toTsvMatrix } from '../engine/distance.js';

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => Array.from(document.querySelectorAll(sel));

const state = {
  result: null,
  tree: null,
  treeSvg: null,
  netSvg: null,
  heatOrder: null,
  fileName: null,
  busyRequest: null,
};

// ---------------------------------------------------------------------------
// Worker plumbing
// ---------------------------------------------------------------------------

const worker = new Worker(new URL('./worker.js', import.meta.url), { type: 'module' });
const pending = new Map();
let requestCounter = 0;

worker.onmessage = (event) => {
  const { id, ok, result, error, progress } = event.data;
  const entry = pending.get(id);
  if (!entry) return;
  if (progress) { entry.onProgress?.(progress); return; }
  pending.delete(id);
  if (ok) entry.resolve(result); else entry.reject(new Error(error));
};

worker.onerror = (event) => {
  showError(`Worker error: ${event.message}`);
  hideBusy();
};

function ask(type, payload, onProgress) {
  const id = ++requestCounter;
  return new Promise((resolve, reject) => {
    pending.set(id, { resolve, reject, onProgress });
    worker.postMessage({ id, type, payload });
  });
}

// ---------------------------------------------------------------------------
// Chrome: tabs, busy overlay, messages
// ---------------------------------------------------------------------------

$$('#tabs .tab').forEach((tab) => {
  tab.addEventListener('click', () => selectTab(tab.dataset.tab));
});

function selectTab(name) {
  $$('#tabs .tab').forEach((t) => t.classList.toggle('active', t.dataset.tab === name));
  $$('.panel').forEach((p) => p.classList.toggle('active', p.dataset.panel === name));
  if (name === 'distances' && state.result) drawHeatmap();
}

function showBusy(text) {
  $('#busyText').textContent = text;
  $('#busyDetail').textContent = '';
  $('#busyBar').style.width = '0%';
  $('#busy').hidden = false;
  $('#statusChip').textContent = 'Running';
  $('#statusChip').className = 'chip busy';
  $('#btnRun').disabled = true;
}

function updateBusy(fraction, stage, detail) {
  $('#busyBar').style.width = `${Math.round(fraction * 100)}%`;
  $('#busyText').textContent = stageLabel(stage);
  $('#busyDetail').textContent = detail || '';
}

function hideBusy() {
  $('#busy').hidden = true;
  $('#btnRun').disabled = false;
}

const STAGE_LABELS = {
  input: 'Reading sequences', alignment: 'Aligning', trimming: 'Trimming',
  distance: 'Computing distances', models: 'Selecting a model', tree: 'Building the tree',
  support: 'Estimating branch support', popgen: 'Population statistics',
  simulate: 'Simulating', benchmark: 'Benchmarking', done: 'Finishing',
};
function stageLabel(stage) { return STAGE_LABELS[stage] || 'Working'; }

function showError(message) {
  const box = $('#errBox');
  box.textContent = message;
  box.hidden = false;
  box.scrollIntoView({ block: 'nearest', behavior: 'smooth' });
}
function clearError() { $('#errBox').hidden = true; }

function showWarnings(list) {
  const box = $('#warnBox');
  if (!list || !list.length) { box.hidden = true; return; }
  box.innerHTML = `<strong>${list.length} note${list.length > 1 ? 's' : ''} about this run</strong><ul>${
    list.map((w) => `<li>${escapeHtml(w)}</li>`).join('')}</ul>`;
  box.hidden = false;
}

function escapeHtml(s) {
  return String(s).replace(/[&<>"']/g, (c) => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
}

// ---------------------------------------------------------------------------
// Input handling
// ---------------------------------------------------------------------------

$('#btnOpen').addEventListener('click', async () => {
  if (window.phyloquick?.openFile) {
    const file = await window.phyloquick.openFile();
    if (!file) return;
    $('#fasta').value = file.content;
    setFileName(file.name);
    updateInputSummary();
  } else {
    $('#fileInput').click();
  }
});

$('#fileInput').addEventListener('change', async (event) => {
  const file = event.target.files[0];
  if (!file) return;
  $('#fasta').value = await file.text();
  setFileName(file.name);
  updateInputSummary();
});

$('#btnClear').addEventListener('click', () => {
  $('#fasta').value = '';
  setFileName(null);
  updateInputSummary();
});

$$('[data-example]').forEach((btn) => {
  btn.addEventListener('click', () => {
    const example = EXAMPLES[btn.dataset.example];
    if (!example) return;
    $('#fasta').value = example.fasta;
    setFileName(`${example.title} (bundled example)`);
    updateInputSummary();
  });
});

function setFileName(name) {
  state.fileName = name;
  $('#fileLabel').textContent = name || 'no file selected';
  $('#fileLabel').title = name || '';
}

$('#fasta').addEventListener('input', updateInputSummary);

function updateInputSummary() {
  const text = $('#fasta').value;
  const count = (text.match(/^>/gm) || []).length;
  if (!count) { $('#inputSummary').textContent = ''; return; }
  const lengths = text.split(/^>/m).slice(1)
    .map((block) => block.split('\n').slice(1).join('').replace(/\s/g, '').length)
    .filter((n) => n > 0);
  const min = Math.min(...lengths); const max = Math.max(...lengths);
  $('#inputSummary').textContent =
    `${count} sequence${count > 1 ? 's' : ''}, ${min === max ? `${min} bp (equal length — already aligned)` : `${min}–${max} bp (unaligned)`}`;
}

// Model-selection checkbox greys out the manual model chooser.
$('#runModelSelection').addEventListener('change', () => {
  const auto = $('#runModelSelection').checked;
  $('#model').disabled = auto;
  $('#gammaAlpha').disabled = auto;
  $('#criterion').disabled = !auto;
});
$('#runModelSelection').dispatchEvent(new Event('change'));

// ---------------------------------------------------------------------------
// Running the analysis
// ---------------------------------------------------------------------------

function collectOptions() {
  const num = (sel, fallback = null) => {
    const raw = $(sel).value;
    if (raw === '' || raw === null) return fallback;
    const v = Number(raw);
    return Number.isFinite(v) ? v : fallback;
  };
  return {
    forceRealign: $('#forceRealign').checked,
    alignment: {
      gapOpen: num('#gapOpen', -12),
      gapExtend: num('#gapExtend', -1),
      refineRounds: num('#refineRounds', 2),
    },
    gapThreshold: num('#gapThreshold', 1),
    runModelSelection: $('#runModelSelection').checked,
    modelSelectionCriterion: $('#criterion').value,
    substitutionModel: $('#model').value,
    gammaCategories: num('#categories', 4),
    gammaAlpha: num('#gammaAlpha', null),
    treeMethod: $('#treeMethod').value,
    distanceModel: $('#distanceModel').value,
    completeDeletion: $('#completeDeletion').checked,
    rooting: $('#rooting').value,
    outgroup: $('#outgroup').value.split(',').map((s) => s.trim()).filter(Boolean),
    support: $('#support').value,
    bootstrapReplicates: num('#bootstrapReplicates', 500),
    shalrtReplicates: num('#shalrtReplicates', 1000),
    seed: num('#seed', 42),
    networkType: $('#networkType').value,
    parsimonyLimit: num('#parsimonyLimit', null),
  };
}

$('#btnRun').addEventListener('click', runAnalysisNow);
$('#btnCancel').addEventListener('click', () => {
  worker.postMessage({ type: 'cancel' });
  hideBusy();
  $('#statusChip').textContent = 'Cancelled';
  $('#statusChip').className = 'chip';
});

async function runAnalysisNow() {
  const text = $('#fasta').value.trim();
  if (!text) { showError('Load a FASTA file or paste sequences first.'); return; }
  clearError();
  showBusy('Starting');
  try {
    const result = await ask('analyse', { text, options: collectOptions() },
      (p) => updateBusy(p.fraction, p.stage, p.detail));
    state.result = result;
    state.tree = relink(parseNewick(result.newick));
    state.heatOrder = null;
    renderEverything();
    $('#statusChip').textContent = `Done in ${(result.manifest.run.elapsedMs / 1000).toFixed(1)} s`;
    $('#statusChip').className = 'chip ok';
    selectTab('overview');
  } catch (err) {
    showError(err.message);
    $('#statusChip').textContent = 'Failed';
    $('#statusChip').className = 'chip';
  } finally {
    hideBusy();
  }
}

// ---------------------------------------------------------------------------
// Rendering
// ---------------------------------------------------------------------------

function renderEverything() {
  const r = state.result;
  showWarnings(r.warnings);
  $('#overviewEmpty').hidden = true;
  $('#overviewBody').hidden = false;
  renderOverview(r);
  renderAlignment();
  renderModels(r);
  drawTree();
  drawHeatmap();
  renderHaplotypes(r);
  renderPopgen(r);
  $('#manifestView').textContent = JSON.stringify(r.manifest, null, 2);
}

function renderOverview(r) {
  const cards = [
    ['Sequences', r.summary.sequences],
    ['Aligned length', `${r.summary.alignedLength} bp`],
    ['Variable sites', r.summary.variableSites],
    ['Parsimony-informative', r.summary.parsimonyInformativeSites],
    ['Site patterns', r.summary.distinctPatterns],
    ['Model', r.modelChosen.label],
    ['Haplotypes', r.popgen.h],
    ['Nucleotide diversity', r.popgen.pi.toFixed(5)],
  ];
  if (r.manifest.tree.lnL != null) cards.push(['Log-likelihood', r.manifest.tree.lnL.toFixed(2)]);
  if (r.support?.meanSupport != null) cards.push(['Mean bootstrap', `${r.support.meanSupport.toFixed(0)}%`]);

  $('#statCards').innerHTML = cards
    .map(([k, v]) => `<div class="statcard"><div class="v">${escapeHtml(String(v))}</div><div class="k">${escapeHtml(k)}</div></div>`)
    .join('');

  const interspecific = r.popgen.pi > 0.05;
  $('#scopeNote').className = interspecific ? 'note warn' : 'note';
  $('#scopeNote').innerHTML = interspecific
    ? `Nucleotide diversity is <strong>${(r.popgen.pi * 100).toFixed(1)}% per site</strong>. This is between-species divergence.
       The alignment, model selection, distances and tree are valid at this level; the population-genetic statistics and the
       haplotype network are defined for a sample from one interbreeding population and should not be read as population
       parameters here.`
    : `Nucleotide diversity is <strong>${(r.popgen.pi * 100).toFixed(2)}% per site</strong>, consistent with variation within a
       single species. Both the phylogenetic and the population-genetic panels apply.`;

  $('#exportAll').innerHTML = '';
  const exports = [
    ['newick', 'Tree (Newick)'], ['aln-fasta', 'Alignment (FASTA)'],
    ['dist-phylip', 'Distances (PHYLIP)'], ['popgen-tsv', 'Statistics (TSV)'],
    ['manifest-json', 'Run manifest (JSON)'], ['summary-txt', 'Summary (TXT)'],
  ];
  if (r.modelSelection) exports.splice(3, 0, ['models-tsv', 'Model selection (TSV)']);
  for (const [key, label] of exports) {
    const btn = document.createElement('button');
    btn.className = 'ghost';
    btn.dataset.export = key;
    btn.textContent = label;
    $('#exportAll').appendChild(btn);
  }
}

// ---- Alignment ------------------------------------------------------------

$('#showOnlyVariable').addEventListener('change', renderAlignment);
$('#alnZoom').addEventListener('input', renderAlignment);

function renderAlignment() {
  const r = state.result;
  if (!r) return;
  const onlyVariable = $('#showOnlyVariable').checked;
  const fontSize = Number($('#alnZoom').value);
  const variable = new Set(r.summary.variablePositions.map((p) => p - 1));
  const columns = onlyVariable
    ? r.summary.variablePositions.map((p) => p - 1)
    : Array.from({ length: r.alignment.length }, (_, i) => i);

  $('#alnMeta').textContent =
    `${r.alignment.names.length} sequences x ${r.alignment.length} columns · `
    + `${r.summary.variableSites} variable, ${r.summary.parsimonyInformativeSites} parsimony-informative · `
    + `showing ${columns.length} column${columns.length === 1 ? '' : 's'}`
    + (r.manifest.alignment.performed ? ` · sum-of-pairs score ${Math.round(r.manifest.alignment.spScore)}` : ' · input was pre-aligned');

  // Cap the rendered width; the DOM cost of 20 000 spans is not worth paying.
  const limit = 4000;
  const shown = columns.slice(0, limit);
  const truncated = columns.length > limit;

  const rows = [`<div class="alnrow"><span class="alnname"></span><span class="alnseq alnruler" style="font-size:${fontSize}px">${
    shown.map((c, i) => (i % 10 === 0 ? '|' : ' ')).join('')}</span></div>`];

  r.alignment.names.forEach((name, rowIndex) => {
    const seq = r.alignment.seqs[rowIndex];
    let html = '';
    for (const c of shown) {
      const ch = seq[c];
      const cls = ch === '-' ? 'b-gap' : (ch === 'A' || ch === 'C' || ch === 'G' || ch === 'T') ? `b-${ch}` : 'b-N';
      const varClass = variable.has(c) ? ' alnvar' : '';
      html += `<span class="${cls}${varClass}">${ch}</span>`;
    }
    rows.push(`<div class="alnrow"><span class="alnname" title="${escapeHtml(name)}">${escapeHtml(name)}</span><span class="alnseq" style="font-size:${fontSize}px">${html}</span></div>`);
  });

  if (truncated) {
    rows.push(`<p class="muted small">Showing the first ${limit} of ${columns.length} columns. Export the alignment to inspect all of it, or tick "variable sites only".</p>`);
  }
  $('#alnView').innerHTML = rows.join('');
}

// ---- Models ---------------------------------------------------------------

function renderModels(r) {
  const table = $('#modelTable');
  if (!r.modelSelection) {
    $('#modelChosen').textContent = `Model fixed by the user: ${r.modelChosen.label}`;
    table.innerHTML = `<tbody><tr><td class="muted">Model selection was switched off. Parameters were still estimated by maximum likelihood: ${
      escapeHtml(Object.entries(r.modelChosen).filter(([k]) => !['model', 'label'].includes(k))
        .map(([k, v]) => `${k} = ${Array.isArray(v) ? v.join(', ') : v}`).join(' · '))}</td></tr></tbody>`;
    return;
  }
  const ms = r.modelSelection;
  $('#modelChosen').textContent = `Selected by ${ms.criterion}: ${ms.chosen}  ·  best AIC: ${ms.bestAIC}  ·  best AICc: ${ms.bestAICc}  ·  best BIC: ${ms.bestBIC}`;

  const head = ['Model', 'lnL', 'Params', 'AIC', 'ΔAIC', 'AICc', 'ΔAICc', 'BIC', 'ΔBIC', 'Akaike weight', 'Estimates'];
  const rows = ms.results.map((m) => {
    const best = m.label === ms.chosen;
    const estimates = Object.entries(m.parameters)
      .filter(([k]) => !['model', 'label', 'freeParameters', 'freqs'].includes(k))
      .map(([k, v]) => `${k}=${Array.isArray(v) ? v.map((x) => (+x).toFixed(2)).join('/') : v}`)
      .join(' ');
    return `<tr class="${best ? 'best' : ''}">
      <td>${escapeHtml(m.label)}${m.collapsed?.length ? ` <span class="muted small">(${m.collapsed.join(', ')})</span>` : ''}</td>
      <td class="num">${m.lnL.toFixed(3)}</td>
      <td class="num">${m.freeParameters}</td>
      <td class="num">${m.AIC.toFixed(2)}</td>
      <td class="num">${m.dAIC.toFixed(2)}</td>
      <td class="num">${Number.isFinite(m.AICc) ? m.AICc.toFixed(2) : '—'}</td>
      <td class="num">${Number.isFinite(m.dAICc) ? m.dAICc.toFixed(2) : '—'}</td>
      <td class="num">${m.BIC.toFixed(2)}</td>
      <td class="num">${m.dBIC.toFixed(2)}</td>
      <td class="num">${m.akaikeWeight < 1e-4 ? m.akaikeWeight.toExponential(1) : m.akaikeWeight.toFixed(4)}</td>
      <td class="muted small">${escapeHtml(estimates)}</td>
    </tr>`;
  });
  table.innerHTML = `<thead><tr>${head.map((h, i) => `<th class="${i > 0 && i < 10 ? 'num' : ''}">${h}</th>`).join('')}</tr></thead><tbody>${rows.join('')}</tbody>`;
}

// ---- Tree -----------------------------------------------------------------

['#treeLayout', '#treeFont', '#treeWidth', '#showSupport', '#showLengths', '#supportCutoff']
  .forEach((sel) => $(sel).addEventListener('input', drawTree));

function drawTree() {
  const r = state.result;
  if (!r || !state.tree) return;
  const svg = renderTree(state.tree, {
    layout: $('#treeLayout').value,
    width: Number($('#treeWidth').value),
    fontSize: Number($('#treeFont').value),
    showSupport: $('#showSupport').checked,
    showLengths: $('#showLengths').checked,
    supportCutoff: Number($('#supportCutoff').value),
  });
  state.treeSvg = svg;
  $('#treeView').replaceChildren(svg);

  const bits = [`${r.manifest.tree.method} tree`, `${r.taxa.length} taxa`, `model ${r.modelChosen.label}`];
  if (r.manifest.tree.lnL != null) bits.push(`lnL = ${r.manifest.tree.lnL.toFixed(3)}`);
  if (r.manifest.tree.nniMovesApplied != null) bits.push(`${r.manifest.tree.nniMovesApplied} NNI move(s) accepted`);
  if (r.support?.method) bits.push(`support: ${r.support.method}`);
  if (r.support?.effectiveReplicates) bits.push(`${r.support.effectiveReplicates} replicates, seed ${r.manifest.run.randomSeed}`);
  bits.push(`rooting: ${r.manifest.rooting.method}`);
  $('#treeMeta').textContent = bits.join(' · ');
}

// ---- Heatmap ---------------------------------------------------------------

['#heatPalette', '#heatOrderTree'].forEach((sel) => $(sel).addEventListener('change', drawHeatmap));

function drawHeatmap() {
  const r = state.result;
  if (!r) return;
  const canvas = $('#heatCanvas');
  const names = r.distances.names;
  let order = names.map((_, i) => i);
  if ($('#heatOrderTree').checked && state.tree) {
    const tipOrder = postorder(state.tree).filter(isLeaf).map((n) => n.name);
    const index = new Map(names.map((n, i) => [n, i]));
    const ordered = tipOrder.map((n) => index.get(n)).filter((i) => i !== undefined);
    if (ordered.length === names.length) order = ordered;
  }
  state.heatOrder = order;
  const info = renderHeatmap(canvas, names, r.distances.matrix, {
    palette: $('#heatPalette').value, order,
  });
  $('#heatMeta').textContent =
    `${r.distances.model} distances · maximum ${info.max.toFixed(5)} substitutions/site`
    + (r.distances.undefinedPairs ? ` · ${r.distances.undefinedPairs} saturated pair(s) replaced by a placeholder` : '');

  const tip = $('#heatTip');
  canvas.onmousemove = (event) => {
    const rect = canvas.getBoundingClientRect();
    const x = event.clientX - rect.left - info.labelWidth;
    const y = event.clientY - rect.top - info.labelWidth;
    const col = Math.floor(x / info.cell);
    const row = Math.floor(y / info.cell);
    if (row < 0 || col < 0 || row >= order.length || col >= order.length) { tip.hidden = true; return; }
    const a = order[row]; const b = order[col];
    tip.textContent = `${names[a]} vs ${names[b]}: ${r.distances.matrix[a][b].toFixed(5)}`;
    tip.style.left = `${event.clientX + 12}px`;
    tip.style.top = `${event.clientY + 12}px`;
    tip.hidden = false;
  };
  canvas.onmouseleave = () => { tip.hidden = true; };
}

// ---- Haplotypes -------------------------------------------------------------

['#netLabels', '#netTicks'].forEach((sel) => $(sel).addEventListener('change', () => renderHaplotypes(state.result)));

function renderHaplotypes(r) {
  if (!r) return;
  const svg = renderNetwork(r.network, {
    showLabels: $('#netLabels').checked,
    showTicks: $('#netTicks').checked,
    width: Math.max(560, Math.min(1100, $('#netView').clientWidth - 20)),
  });
  state.netSvg = svg;
  $('#netView').replaceChildren(svg);

  const meta = Object.entries(r.network.meta).map(([k, v]) => `${k}: ${v}`).join(' · ');
  $('#netMeta').textContent =
    `${networkName(r.network.type)} · ${r.network.haplotypes.length} haplotypes · ${r.network.edges.length} connections`
    + (meta ? ` · ${meta}` : '');

  const total = r.network.haplotypes.reduce((a, h) => a + h.count, 0);
  $('#hapTable').innerHTML =
    '<thead><tr><th>Haplotype</th><th class="num">n</th><th class="num">Frequency</th><th>Sequences</th></tr></thead><tbody>'
    + r.network.haplotypes.map((h) => `<tr><td>${h.id}</td><td class="num">${h.count}</td><td class="num">${(h.count / total).toFixed(3)}</td><td>${escapeHtml(h.names.join(', '))}</td></tr>`).join('')
    + '</tbody>';
}

function networkName(type) {
  return { MJ: 'Median-joining network', MSN: 'Minimum spanning network', PARSIMONY: 'Statistical-parsimony network' }[type] || type;
}

// ---- Population genetics ------------------------------------------------------

function renderPopgen(r) {
  const p = r.popgen;
  const fmt = (x, d = 4) => (x == null || !Number.isFinite(x) ? '—' : x.toFixed(d));
  const rows = [
    ['Sequences (n)', p.n, ''],
    ['Sites analysed', p.sites, 'columns with at least two resolved nucleotides'],
    ['Segregating sites (S)', p.S, ''],
    ['Total mutations (η)', p.eta, ''],
    ['Singleton mutations', p.singletonMutations, ''],
    ['Haplotypes (h)', p.h, ''],
    ['Haplotype diversity (Hd)', `${fmt(p.Hd)} ± ${fmt(p.HdSD)}`, 'Nei (1987)'],
    ['Nucleotide diversity (π)', `${fmt(p.pi, 6)} ± ${fmt(p.piSD, 6)}`, 'Nei (1987)'],
    ['Mean pairwise differences (k)', fmt(p.k), ''],
    ['Watterson\'s θ', fmt(p.thetaW), 'per locus'],
    ['Watterson\'s θ per site', fmt(p.thetaWPerSite, 6), ''],
    ['Tajima\'s D', fmt(p.tajimaD), `p ≈ ${fmt(p.tajimaP, 3)} (beta approximation)`],
    ['Fu & Li\'s D*', fmt(p.fuLiDStar), 'no outgroup'],
    ['Fu & Li\'s F*', fmt(p.fuLiFStar), 'no outgroup'],
    ['Fu\'s Fs', fmt(p.fuFs), 'Ewens sampling formula'],
    ['R₂', fmt(p.r2), 'Ramos-Onsins & Rozas (2002)'],
    ['Mismatch raggedness', fmt(p.mismatch?.raggedness), 'Harpending (1994)'],
  ];
  $('#popgenTable').innerHTML =
    '<thead><tr><th>Statistic</th><th class="num">Value</th><th>Note</th></tr></thead><tbody>'
    + rows.map(([k, v, note]) => `<tr><td>${k}</td><td class="num">${escapeHtml(String(v))}</td><td class="muted small">${escapeHtml(note)}</td></tr>`).join('')
    + '</tbody>';

  const scope = $('#popgenScope');
  if (p.pi > 0.05) {
    scope.className = 'note warn';
    scope.hidden = false;
    scope.innerHTML = `<strong>These statistics assume a single interbreeding population.</strong>
      Nucleotide diversity here is ${(p.pi * 100).toFixed(1)}% per site, which is between-species divergence.
      The values below are computable but are not population parameters, and the neutrality tests do not test demography
      at this level of divergence.`;
  } else {
    scope.hidden = true;
  }

  $('#mismatchChart').replaceChildren(renderMismatch(p.mismatch?.distribution || []));
}

// ---------------------------------------------------------------------------
// Validation panel
// ---------------------------------------------------------------------------

$('#btnLoadTree').addEventListener('click', async () => {
  if (window.phyloquick?.openFile) {
    const file = await window.phyloquick.openFile([{ name: 'Newick tree', extensions: ['nwk', 'newick', 'tre', 'tree', 'txt'] }]);
    if (!file) return;
    $('#cmpNewick').value = file.content;
    $('#cmpFileLabel').textContent = file.name;
  } else {
    const input = document.createElement('input');
    input.type = 'file';
    input.accept = '.nwk,.newick,.tre,.tree,.txt';
    input.onchange = async () => {
      const f = input.files[0];
      if (!f) return;
      $('#cmpNewick').value = await f.text();
      $('#cmpFileLabel').textContent = f.name;
    };
    input.click();
  }
});

$('#btnCompare').addEventListener('click', async () => {
  const other = $('#cmpNewick').value.trim();
  if (!state.result) { showError('Run an analysis first, so there is something to compare against.'); return; }
  if (!other) { showError('Load or paste a Newick tree to compare with.'); return; }
  const box = $('#cmpResult');
  box.textContent = 'Comparing…';
  try {
    const cmp = await ask('compare', { newickA: state.result.unrootedNewick, newickB: other });
    box.innerHTML = `
      <table>
        <tbody>
          <tr><td>Taxa</td><td class="num">${cmp.taxa}</td></tr>
          <tr><td>Robinson–Foulds distance</td><td class="num"><strong>${cmp.rf}</strong></td></tr>
          <tr><td>Normalised RF (0 = identical)</td><td class="num">${cmp.normalised.toFixed(4)}</td></tr>
          <tr><td>Shared splits</td><td class="num">${cmp.sharedSplits} of ${cmp.splitsA} / ${cmp.splitsB}</td></tr>
          <tr><td>Split recall</td><td class="num">${cmp.recall.toFixed(4)}</td></tr>
          <tr><td>Branch-score distance</td><td class="num">${cmp.branchScore.toFixed(5)}</td></tr>
          <tr><td>Both fully resolved</td><td class="num">${cmp.fullyResolved ? 'yes' : 'no'}</td></tr>
        </tbody>
      </table>
      <p class="muted small">${cmp.rf === 0
        ? 'The two trees are topologically identical.'
        : `The trees differ in ${cmp.rf} split${cmp.rf === 1 ? '' : 's'} out of a possible ${cmp.maxRF}.`}
        ${!cmp.fullyResolved ? ' At least one tree contains a polytomy, which lowers RF for reasons unrelated to agreement.' : ''}</p>`;
  } catch (err) {
    box.innerHTML = `<div class="error">${escapeHtml(err.message)}</div>`;
  }
});

$('#btnSimulate').addEventListener('click', async () => {
  const methods = Array.from($('#simMethods').selectedOptions).map((o) => o.value);
  if (!methods.length) { showError('Select at least one reconstruction method.'); return; }
  const bar = $('#simProgress');
  bar.hidden = false;
  bar.firstElementChild.style.width = '0%';
  $('#simResult').textContent = '';
  try {
    const out = await ask('simulate', {
      taxa: Number($('#simTaxa').value),
      sites: Number($('#simSites').value),
      replicates: Number($('#simReps').value),
      meanBranch: Number($('#simBranch').value),
      rateVariation: Number($('#simRateVar').value),
      model: $('#simModel').value,
      methods,
      seed: Number($('#simSeed').value),
    }, (p) => { bar.firstElementChild.style.width = `${Math.round(p.fraction * 100)}%`; });
    bar.firstElementChild.style.width = '100%';
    renderSimulationResult(out);
  } catch (err) {
    $('#simResult').innerHTML = `<div class="error">${escapeHtml(err.message)}</div>`;
  } finally {
    setTimeout(() => { bar.hidden = true; }, 400);
  }
});

function renderSimulationResult(out) {
  const s = out.settings;
  const rows = Object.entries(out.summary).map(([method, v]) => `
    <tr>
      <td>${method}</td>
      <td class="num">${v.meanRF.toFixed(2)}</td>
      <td class="num">${v.meanNormalisedRF.toFixed(4)} ± ${v.sdNormalisedRF.toFixed(4)}</td>
      <td class="num">${(v.meanRecall * 100).toFixed(1)}%</td>
      <td class="num">${v.perfectReconstructions}/${v.replicates}</td>
      <td class="num">${v.meanBranchScore.toFixed(4)}</td>
      <td class="num">${v.meanMs.toFixed(0)} ms</td>
    </tr>`).join('');

  $('#simResult').innerHTML = `
    <p class="muted small">${s.replicates} replicates · ${s.taxa} taxa · ${s.sites} sites · generating model ${s.model}+G ·
      mean branch length ${s.meanBranch} · rate variation CV ${s.rateVariation} · seed ${s.seed}</p>
    <div class="tablewrap"><table>
      <thead><tr><th>Method</th><th class="num">Mean RF</th><th class="num">Normalised RF</th>
        <th class="num">Split recall</th><th class="num">Exact</th><th class="num">Branch score</th><th class="num">Mean time</th></tr></thead>
      <tbody>${rows}</tbody>
    </table></div>
    <p class="muted small">Normalised Robinson–Foulds runs from 0 (the true topology recovered exactly) to 1.
      "Exact" counts replicates in which the true tree was recovered without a single wrong split.</p>`;
}

$('#btnBenchmark').addEventListener('click', async () => {
  const sizes = $('#benchSizes').value.split(',').map((s) => Number(s.trim())).filter((n) => n >= 4);
  if (!sizes.length) { showError('Give at least one taxon count, e.g. 10,25,50.'); return; }
  const bar = $('#benchProgress');
  bar.hidden = false;
  bar.firstElementChild.style.width = '0%';
  $('#benchResult').textContent = '';
  try {
    const out = await ask('benchmark', {
      sizes, sites: Number($('#benchSites').value),
      replicates: Number($('#benchReps').value), seed: Number($('#benchSeed').value),
    }, (p) => { bar.firstElementChild.style.width = `${Math.round(p.fraction * 100)}%`; });
    bar.firstElementChild.style.width = '100%';
    renderBenchmarkResult(out);
  } catch (err) {
    $('#benchResult').innerHTML = `<div class="error">${escapeHtml(err.message)}</div>`;
  } finally {
    setTimeout(() => { bar.hidden = true; }, 400);
  }
});

function renderBenchmarkResult(out) {
  const stages = Object.keys(out.rows[0].timings);
  const header = ['Taxa', 'Patterns', ...stages.map(prettyStage), 'Total'];
  const body = out.rows.map((r) => `<tr>
      <td class="num">${r.taxa}</td><td class="num">${r.patterns}</td>
      ${stages.map((s) => `<td class="num">${fmtTime(r.timings[s])}</td>`).join('')}
      <td class="num"><strong>${fmtTime(r.total)}</strong></td>
    </tr>`).join('');

  const scalingRow = ['', '', ...stages.map((s) => (out.scaling[s] == null ? '—' : `n^${out.scaling[s].toFixed(2)}`)),
    out.scaling.total == null ? '—' : `n^${out.scaling.total.toFixed(2)}`];

  const chart = renderLineChart(
    [...stages, 'total'].map((s) => ({
      label: s === 'total' ? 'total' : prettyStage(s),
      points: out.rows.map((r) => [r.taxa, s === 'total' ? r.total : r.timings[s]]),
    })).filter((s) => s.points.some((p) => p[1] > 0)),
    { xLabel: 'number of taxa', yLabel: 'time (ms, log scale)', width: 620, height: 320 },
  );

  const box = $('#benchResult');
  box.innerHTML = `
    <p class="muted small">${out.settings.sites} simulated sites per dataset · ${out.settings.replicates} bootstrap replicates ·
      seed ${out.settings.seed} · measured on this machine</p>
    <div class="tablewrap"><table>
      <thead><tr>${header.map((h, i) => `<th class="${i ? 'num' : 'num'}">${escapeHtml(h)}</th>`).join('')}</tr></thead>
      <tbody>${body}
        <tr><td colspan="${header.length}" class="muted small">Empirical scaling, from a least-squares fit of log(time) on log(taxa):</td></tr>
        <tr class="best">${scalingRow.map((c) => `<td class="num">${escapeHtml(c)}</td>`).join('')}</tr>
      </tbody>
    </table></div>`;
  box.appendChild(chart);
}

function prettyStage(s) {
  return s.replace(/([A-Z])/g, ' $1').replace(/^./, (c) => c.toUpperCase());
}
function fmtTime(ms) {
  if (ms == null) return '—';
  if (ms >= 10000) return `${(ms / 1000).toFixed(1)} s`;
  if (ms >= 1000) return `${(ms / 1000).toFixed(2)} s`;
  return `${ms.toFixed(0)} ms`;
}

// ---------------------------------------------------------------------------
// Exports
// ---------------------------------------------------------------------------

document.addEventListener('click', async (event) => {
  const btn = event.target.closest('[data-export]');
  if (!btn) return;
  if (!state.result) { showError('Run an analysis first.'); return; }
  try {
    await doExport(btn.dataset.export);
  } catch (err) {
    showError(err.message);
  }
});

async function doExport(kind) {
  const r = state.result;
  const base = (state.fileName || 'phyloquick').replace(/\.[^.]+$/, '').replace(/[^\w.-]+/g, '_').slice(0, 40) || 'phyloquick';
  const aln = r.alignment;

  switch (kind) {
    case 'newick': return save(`${base}.nwk`, r.newick + '\n', 'text/plain');
    case 'aln-fasta': return save(`${base}.aln.fasta`, toFasta(aln.names, aln.seqs), 'text/plain');
    case 'aln-phylip': return save(`${base}.aln.phy`, toPhylip(aln.names, aln.seqs), 'text/plain');
    case 'aln-nexus': return save(`${base}.aln.nex`, toNexus(aln.names, aln.seqs), 'text/plain');
    case 'consensus': {
      const seq = consensus(toAlignment(aln.names.map((n, i) => ({ name: n, seq: aln.seqs[i] }))), 1);
      return save(`${base}.consensus.fasta`, `>${base}_consensus\n${seq}\n`, 'text/plain');
    }
    case 'dist-phylip': return save(`${base}.dist.phy`, toPhylipMatrix(r.distances), 'text/plain');
    case 'dist-tsv': return save(`${base}.dist.tsv`, toTsvMatrix(r.distances), 'text/tab-separated-values');
    case 'models-tsv': return save(`${base}.models.tsv`, modelsTsv(r), 'text/tab-separated-values');
    case 'popgen-tsv': return save(`${base}.popgen.tsv`, popgenTsv(r.popgen), 'text/tab-separated-values');
    case 'haplotypes-tsv': return save(`${base}.haplotypes.tsv`, haplotypesTsv(r.network), 'text/tab-separated-values');
    case 'manifest-json': return save(`${base}-run-manifest.json`, JSON.stringify(r.manifest, null, 2) + '\n', 'application/json');
    case 'summary-txt': return save(`${base}.summary.txt`, summaryText(r), 'text/plain');
    case 'tree-svg': return save(`${base}.tree.svg`, svgToString(state.treeSvg), 'image/svg+xml');
    case 'network-svg': return save(`${base}.network.svg`, svgToString(state.netSvg), 'image/svg+xml');
    case 'tree-png': return saveBlob(`${base}.tree.png`, await svgToPng(state.treeSvg, 2));
    case 'heat-png': return saveBlob(`${base}.heatmap.png`, await canvasBlob($('#heatCanvas')));
    case 'cli-command': return copyToClipboard(cliCommand(r));
    default: throw new Error(`unknown export: ${kind}`);
  }
}

function modelsTsv(r) {
  if (!r.modelSelection) return 'model selection was not run\n';
  const head = ['Model', 'lnL', 'FreeParams', 'AIC', 'dAIC', 'AICc', 'dAICc', 'BIC', 'dBIC', 'AkaikeWeight', 'Estimates'];
  const lines = [head.join('\t')];
  for (const m of r.modelSelection.results) {
    const est = Object.entries(m.parameters)
      .filter(([k]) => !['model', 'label', 'freeParameters'].includes(k))
      .map(([k, v]) => `${k}=${Array.isArray(v) ? v.join('/') : v}`).join('; ');
    lines.push([m.label, m.lnL.toFixed(4), m.freeParameters, m.AIC.toFixed(4), m.dAIC.toFixed(4),
      Number.isFinite(m.AICc) ? m.AICc.toFixed(4) : 'NA', Number.isFinite(m.dAICc) ? m.dAICc.toFixed(4) : 'NA',
      m.BIC.toFixed(4), m.dBIC.toFixed(4), m.akaikeWeight.toExponential(4), est].join('\t'));
  }
  return lines.join('\n') + '\n';
}

function popgenTsv(p) {
  const num = (x, d) => (x == null || !Number.isFinite(x) ? 'NA' : x.toFixed(d));
  const rows = [
    ['sequences', p.n], ['analysed_sites', p.sites], ['segregating_sites_S', p.S],
    ['total_mutations_eta', p.eta], ['singleton_mutations', p.singletonMutations],
    ['haplotypes_h', p.h], ['haplotype_diversity_Hd', num(p.Hd, 6)], ['haplotype_diversity_SD', num(p.HdSD, 6)],
    ['nucleotide_diversity_pi', num(p.pi, 8)], ['nucleotide_diversity_SD', num(p.piSD, 8)],
    ['mean_pairwise_differences_k', num(p.k, 6)], ['wattersons_theta', num(p.thetaW, 6)],
    ['wattersons_theta_per_site', num(p.thetaWPerSite, 8)], ['tajimas_D', num(p.tajimaD, 6)],
    ['tajimas_D_p_approx', num(p.tajimaP, 4)], ['fu_li_D_star', num(p.fuLiDStar, 6)],
    ['fu_li_F_star', num(p.fuLiFStar, 6)], ['fu_Fs', num(p.fuFs, 6)],
    ['ramos_onsins_rozas_R2', num(p.r2, 6)], ['mismatch_raggedness', num(p.mismatch?.raggedness, 6)],
  ];
  return 'statistic\tvalue\n' + rows.map(([k, v]) => `${k}\t${v}`).join('\n') + '\n';
}

function haplotypesTsv(network) {
  const total = network.haplotypes.reduce((a, h) => a + h.count, 0);
  return 'haplotype\tcount\tfrequency\tsequences\n'
    + network.haplotypes.map((h) => `${h.id}\t${h.count}\t${(h.count / total).toFixed(6)}\t${h.names.join(',')}`).join('\n') + '\n';
}

function summaryText(r) {
  const m = r.manifest;
  return [
    `PhyloQuick ${m.software.version} — analysis summary`,
    `Generated ${m.run.finishedAt}`,
    '',
    `Input SHA-256           ${m.input.sha256}`,
    `Sequences               ${r.summary.sequences}`,
    `Aligned length          ${r.summary.alignedLength}`,
    `Variable sites          ${r.summary.variableSites}`,
    `Parsimony-informative   ${r.summary.parsimonyInformativeSites}`,
    `Model                   ${r.modelChosen.label}${m.model.selectionPerformed ? ` (selected by ${m.model.criterion})` : ' (fixed by user)'}`,
    `Tree method             ${m.tree.method}`,
    ...(m.tree.lnL != null ? [`Log-likelihood          ${m.tree.lnL.toFixed(4)}`] : []),
    `Support                 ${r.support?.method || 'none'}`,
    `Random seed             ${m.run.randomSeed}`,
    '',
    `Haplotypes (h)          ${r.popgen.h}`,
    `Haplotype diversity     ${r.popgen.Hd.toFixed(4)}`,
    `Nucleotide diversity    ${r.popgen.pi.toFixed(6)}`,
    `Tajima's D              ${r.popgen.tajimaD == null ? 'NA' : r.popgen.tajimaD.toFixed(4)}`,
    `Fu's Fs                 ${r.popgen.fuFs == null ? 'NA' : r.popgen.fuFs.toFixed(4)}`,
    '',
    ...(r.warnings.length ? ['Notes:', ...r.warnings.map((w) => `  - ${w}`), ''] : []),
    'Tree (Newick):',
    r.newick,
    '',
  ].join('\n');
}

/** The CLI invocation that reproduces the run currently on screen. */
function cliCommand(r) {
  const o = r.options;
  const parts = ['phyloquick', '-i', state.fileName || 'input.fasta', '-o', 'results'];
  parts.push('--method', o.treeMethod);
  if (!o.runModelSelection) parts.push('--no-model-selection', '--model', o.substitutionModel);
  else parts.push('--criterion', o.modelSelectionCriterion);
  parts.push('--distance', o.distanceModel);
  parts.push('--support', o.support);
  if (o.bootstrapReplicates) parts.push('-b', String(o.bootstrapReplicates));
  parts.push('-s', String(o.seed));
  parts.push('--root', o.rooting);
  if (o.gapThreshold < 1) parts.push('--gap-threshold', String(o.gapThreshold));
  parts.push('--network', o.networkType);
  return parts.join(' ');
}

async function copyToClipboard(text) {
  await navigator.clipboard.writeText(text);
  const chip = $('#statusChip');
  const previous = chip.textContent;
  chip.textContent = 'Command copied';
  setTimeout(() => { chip.textContent = previous; }, 1800);
}

function canvasBlob(canvas) {
  return new Promise((resolve, reject) => {
    canvas.toBlob((b) => (b ? resolve(b) : reject(new Error('PNG conversion failed'))), 'image/png');
  });
}

async function save(filename, content, mime) {
  if (window.phyloquick?.saveFile) {
    const ok = await window.phyloquick.saveFile(filename, content);
    if (ok) flashSaved(filename);
    return;
  }
  saveBlob(filename, new Blob([content], { type: mime }));
}

function saveBlob(filename, blob) {
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a');
  a.href = url;
  a.download = filename;
  a.click();
  setTimeout(() => URL.revokeObjectURL(url), 2000);
  flashSaved(filename);
}

function flashSaved(filename) {
  const chip = $('#statusChip');
  const previous = chip.textContent;
  chip.textContent = `Saved ${filename}`;
  setTimeout(() => { chip.textContent = previous; }, 1800);
}

// ---------------------------------------------------------------------------
// Startup
// ---------------------------------------------------------------------------

$('#helpBody').innerHTML = HELP_HTML;
void leafNames;
