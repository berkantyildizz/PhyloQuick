/**
 * In-application help text.
 */

export const HELP_HTML = `
<h2>What PhyloQuick is for</h2>
<p>
  PhyloQuick is a desktop workbench for nucleotide sequence datasets of the size
  a single laboratory generates: tens to a few hundred sequences of a gene, a
  barcode region or an organellar locus. It carries one dataset through the whole
  chain — quality control, multiple alignment, model selection, distance and
  likelihood tree inference, branch support, and intraspecific summary statistics
  — inside one program, on one computer, with one random seed.
</p>
<p>
  It is <em>not</em> a replacement for RAxML, IQ-TREE, BEAST or MrBayes on
  genome-scale or partitioned data, and it does not try to be. Where the two
  overlap, PhyloQuick's numbers are meant to match theirs; where they do not
  overlap, PhyloQuick says so rather than producing a number anyway.
</p>

<h2>Scope: intraspecific and interspecific analyses are not the same</h2>
<p>
  The analyses in this program fall into two groups with different domains of
  validity, and the distinction matters more than it might appear.
</p>
<table>
  <thead><tr><th>Applies to any level of divergence</th><th>Applies within one interbreeding population</th></tr></thead>
  <tbody>
    <tr>
      <td>
        Multiple alignment · substitution-model selection · pairwise distances ·
        NJ, BIONJ, UPGMA · maximum-likelihood tree search · bootstrap and SH-aLRT
        support · Robinson–Foulds tree comparison
      </td>
      <td>
        Haplotype diversity (H<sub>d</sub>) · nucleotide diversity (&pi;) ·
        Watterson's &theta; · Tajima's <em>D</em> · Fu &amp; Li's <em>D*</em>,
        <em>F*</em> · Fu's <em>Fs</em> · <em>R</em><sub>2</sub> · mismatch
        distribution · haplotype networks (MSN, median-joining, statistical parsimony)
      </td>
    </tr>
  </tbody>
</table>
<p>
  Haplotype networks and neutrality tests are derived from coalescent theory for a
  <em>sample from a single population</em>. Applied across species they still
  return numbers, but those numbers are not population parameters: &pi; between
  species measures divergence, not diversity, and Tajima's <em>D</em> across
  species tests nothing about demography. PhyloQuick therefore inspects the data
  and issues a warning when the observed divergence is characteristic of a
  between-species sample. The alignment, model selection and tree remain valid in
  that case — only the population-genetic panel does not.
</p>

<h2>Methods implemented</h2>

<h3>Alignment</h3>
<p>
  Three-stage progressive alignment: a <em>k</em>-mer distance matrix computed
  without alignment, a UPGMA guide tree on those distances, and profile–profile
  alignment with affine (Gotoh) gap costs along the guide tree. Two rounds of
  tree-dependent iterative refinement follow: the alignment is split on each
  guide-tree branch, the halves are realigned, and the result is kept only if the
  sum-of-pairs score improves.
</p>

<h3>Substitution models</h3>
<p>
  JC69, F81, K80, HKY85, TN93 and GTR, each optionally with a proportion of
  invariable sites (+I) and/or discrete-gamma rate heterogeneity (+G, Yang's
  mean-rate discretisation, 4 categories by default). Transition probabilities are
  obtained exactly, by eigen-decomposition of the rate matrix, not by
  approximation. Model selection fits all 24 combinations by maximum likelihood on
  a fixed starting topology and ranks them by AIC, AICc and BIC; branch lengths are
  counted as free parameters so the criteria are comparable across models.
</p>

<h3>Tree inference</h3>
<p>
  Distance methods: Neighbor-Joining, BIONJ and UPGMA. Likelihood: Felsenstein
  pruning on compressed site patterns, branch lengths optimised by Brent's method
  in log space, model parameters by coordinate ascent with a dedicated joint
  search over the (&alpha;, p<sub>inv</sub>) ridge, and topology by nearest-neighbour
  interchange hill climbing from the NJ starting tree.
</p>

<h3>Branch support</h3>
<ul>
  <li><strong>Nonparametric bootstrap</strong> — alignment columns are resampled
      with replacement and the entire inference is repeated; support is the
      percentage of replicates recovering each bipartition. With a likelihood tree
      this re-searches the topology on every replicate and is correspondingly slow.</li>
  <li><strong>SH-aLRT</strong> — for likelihood trees, the Shimodaira–Hasegawa-like
      approximate likelihood-ratio test of Guindon <em>et al.</em> (2010). Roughly
      two extra likelihood evaluations per branch, so it is the default for ML.
      Values &ge; 80 are conventionally read as strong support; the scale is not
      the same as a bootstrap percentage.</li>
</ul>

<h3>Population genetics</h3>
<p>
  Segregating sites, haplotype and nucleotide diversity with their standard
  deviations, Watterson's &theta;, Tajima's <em>D</em> (with the beta
  approximation to its significance), Fu &amp; Li's <em>D*</em> and <em>F*</em>,
  Fu's <em>Fs</em> computed from the Ewens sampling formula in log space, the
  <em>R</em><sub>2</sub> statistic, and the mismatch distribution with
  Harpending's raggedness index.
</p>

<h2>Reproducibility</h2>
<p>
  Every stochastic step — bootstrap resampling, SH-aLRT replicates, simulation —
  draws from an explicit seeded generator (xoshiro128**). The same seed produces
  byte-identical output on any platform. Each run writes a <strong>manifest</strong>
  recording the software version, a SHA-256 fingerprint of the input file, every
  parameter actually used, the seed and per-stage timings. The manifest plus the
  input file is enough to reproduce the analysis exactly; the command-line tool
  shipped with the application accepts a manifest directly with
  <code>--replay</code>.
</p>

<h2>Checking the results rather than trusting them</h2>
<p>The <strong>Validation</strong> tab provides three independent checks:</p>
<ol>
  <li><strong>Compare with another program.</strong> Load a Newick tree from MEGA,
      IQ-TREE, RAxML or PhyML over the same taxa and obtain the Robinson–Foulds
      distance, the shared-split count and the branch-score distance.</li>
  <li><strong>Accuracy on simulated data.</strong> Sequences are simulated down a
      randomly generated tree under a known model and then reconstructed. Because
      the true tree is known by construction, accuracy is measured, not inferred.</li>
  <li><strong>Runtime and scalability.</strong> Each stage is timed over increasing
      dataset sizes on the machine in front of you, and the empirical scaling
      exponent is estimated by regressing log(time) on log(number of taxa).</li>
</ol>

<h2>Known limitations</h2>
<ul>
  <li>Nucleotide data only. Amino-acid and codon models are not implemented.</li>
  <li>No partitioned analysis: one model is applied to the whole alignment.</li>
  <li>No Bayesian inference and no divergence-time estimation.</li>
  <li>Topology search is NNI only. NNI can be trapped in a local optimum that an
      SPR or TBR search would escape; on datasets where topology is contentious,
      confirm with a dedicated ML program.</li>
  <li>+I and +G together are close to unidentifiable on most datasets. PhyloQuick
      fits the combination and searches the ridge deliberately, but a very small
      &alpha; alongside a large p<sub>inv</sub> should be read as "many nearly
      invariable sites", not as two separate estimates.</li>
  <li>The statistical-parsimony connection limit is a documented approximation and
      an explicitly reported parameter; it is not a reimplementation of the TCS
      derivation, and it can be overridden.</li>
  <li>The alignment is progressive with refinement. On sequences with substantial
      length heterogeneity or low similarity, a consistency-based aligner such as
      MAFFT L-INS-i or PRANK will do better; PhyloQuick accepts a pre-aligned file
      and will leave it untouched.</li>
  <li>Practical size: comfortable to a few hundred sequences of a few thousand
      sites. Beyond that, use a compiled program.</li>
</ul>

<h2>Citing</h2>
<p>
  If PhyloQuick contributed to a published analysis, please report the version
  number and the random seed shown in the Run log, and cite the accompanying
  article. Reporting the seed is what allows a reader to reproduce your support
  values exactly.
</p>
`;

export default HELP_HTML;
